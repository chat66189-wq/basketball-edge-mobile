# Changelog

## 16.0.0 — 2026-11-20

- Added mandatory deep-research workflow for each candidate: fixture/rules, season and recent statistics, home/away splits, opponent strength, advanced metrics, roster/injuries/minutes, schedule/travel, tactical matchup, odds/line movement and adversarial review.
- Added competition-coverage playbook for NBA, WNBA, NCAA men's/women's, FIBA/national leagues, women's/youth and regional leagues, with explicit low-data abstention rules.
- Added standardized research packet template with point-in-time evidence lineage, source independence groups, contradictions, red-team conditions and model/market separation.
- Added `research-audit` CLI and research packet validator for source timestamps, URL/provenance, look-ahead, category coverage, critical evidence and quote-field completeness.
- Added decision-quality/red-team guidance. Research score is explicitly not a win probability, model validation, recommendation approval or ROI claim.
- Preserved the v15 quantitative engine and its limitations; no model is promoted to validated by this documentation/audit release.
- Expanded active tests from 30 to 36; tests validate software behavior, not prediction accuracy.

## 15.0.0 — 2026-11-19

- Reconstructed the active runtime in `scripts/edge_v15/`, isolated from legacy imports.
- Added source freshness, licensing-state and point-in-time checks with payload hashes.
- Added recency-weighted/shrunk team pace and PPP estimates, regularized opponent-adjusted ratings, possession and Four Factors helpers.
- Added reproducible shared-pace Monte Carlo game simulation and explicit regulation-only settlement guard.
- Added uncertain-minute player count simulation and shared game/player scenario generation.
- Added market probability, push/loss accounting for supported game markets, EV and no-vig helpers.
- Added joint-combo optimizer using common scenarios, exact joint-price requirement for same-event parlays, stress batches, Monte Carlo Wilson lower bound and leave-one-out.
- Added Brier, Log Loss, ECE, chronology/look-ahead checks, expanding-window evaluation, paired champion/challenger bootstrap and degradation monitoring.
- Added append-only SQLite ledger and provider contracts without fabricated APIs or embedded credentials.
- Archived the previous v14 scripts/tests/references under `legacy_archive/`.
- Active test suite initially contained 30 tests. Passing software tests do not establish forecast accuracy.

## 14.0.0 and earlier

Original files retained under `legacy_archive/` for reference.

## 17.0.0 — 2026-11-20

- Added default `MAXIMIZE_HIT_RATE_STRICT` policy: target odds are secondary, and missing evidence leads to abstention instead of forced picks.
- Added executable `pick-audit` gate requiring exact market-scope walk-forward validation, minimum out-of-sample sample sizes, untouched holdout/leakage checks, calibration diagnostics, conservative probability bounds, independent sources, resolved material availability, fresh exact-operator prices and supported markets.
- Added executable `combo-audit` gate requiring every leg to pass the individual gate, exact same-operator combo price, refreshed settlement rules, shared dependency-aware scenarios, model/data/parameter/lineup uncertainty and stress lower bounds.
- Added strict combination floor `max(0.30, 1 / actual_odds + 0.05)` and minimum conservative leg probability of 0.80 by default. These are explicit user-policy thresholds, not claims about true probabilities or guaranteed outcomes.
- Added deliberately incomplete v17 templates, policy reference and 10 new unit tests.
- Expanded test discovery to include v17: 46/46 pass under both `unittest` and `pytest`.
- Explicitly retained predictive limitations: gates inspect supplied evidence and metrics; they do not create missing historical data, estimate calibrated probabilities automatically, connect to GanamosVIP, or guarantee results.


## 18.0.0 — 2026-11-20

- Added executable model laboratory for exact competition × season × market_scope training and evaluation.
- Enforced point-in-time history schema, timezone-aware chronology, unique event IDs, explicit numeric features, forbidden post-event/target feature tokens, source bundle hash, independent source group count, official-source presence, fresh paired market odds and a minimum three-operator market baseline.
- Added chronological expanding-window walk-forward comparison for logistic regression, ExtraTrees, HistGradientBoosting, Random Forest and optional XGBoost/LightGBM/CatBoost challengers.
- Added development-only champion selection, optional inverse-Brier weighted soft-voting ensemble and Platt calibration fitted to walk-forward out-of-sample predictions.
- Reserved untouched chronological final holdout; promotion requires superiority to no-vig market Brier, non-degraded Log Loss, calibration thresholds, minimum sample/splits, positive lower bootstrap Brier-skill interval, feature PSI drift check and a dedicated high-confidence holdout gate (≥100 predictions at P≥0.80, with Wilson lower hit-rate bound ≥0.80).
- Added holdout metrics: accuracy, Brier, Log Loss, ECE, AUC, reliability bins, empirical high-confidence subset hit rate/interval, optional closing-line value and flat-stake ROI.
- Added optional bootstrap model ensemble for per-event training-sample variation intervals, with explicit warnings that these intervals do not cover full predictive/data/lineup/regime uncertainty.
- Integrated v18 model-card verification into `pick-audit`: reads the actual card file, recalculates SHA-256, checks exact market scope, and derives holdout metrics/high-confidence subset gates directly from the card instead of trusting manually entered model metrics. Requires ≥100 high-confidence holdout predictions and a Wilson lower bound ≥0.80.
- Added `model-lab`, `predict-model`, `model-card-audit`, `candidate-log`, `candidate-settle`, `model-evaluation-log` and `ledger-report` CLI commands.
- Extended SQLite append-only ledger with candidate decisions (accepted/rejected/conditional/no-pick), candidate settlements and model evaluation records; rejected candidates can be followed through results to measure counterfactual decision quality.
- Added ML extras requirements and blank CSV/JSON templates; no historical match data are bundled and no competition model is automatically validated.
- Expanded active test suite to 60/60 passing tests under both `unittest` and `pytest`. Software tests do not measure sports-prediction accuracy.

## 19.0.0 — 2026-11-20

- Added a configurable, auditable HTTP/JSON ingestion client with explicit license/terms opt-in, host allowlisting, HTTPS enforcement (loopback exception for tests), environment-based auth, bounded retries/timeouts/response size, SQLite cache, capture timestamps and payload SHA-256. No vendor endpoints or credentials are invented.
- Added point-in-time rolling feature generation for pace, offensive/defensive/net PPP, optional Four Factors, home/away splits, rest, back-to-back, 7/14-day schedule density and verified-coordinate travel distance.
- Added availability/minute scenario simulation using adjusted RAPM/EPM/DARKO/validated lineup impact inputs, shrinkage and explicit uncertainty; raw plus/minus and unknown status are rejected. Outputs remain sensitivity-only.
- Added a nested possession/efficiency scenario simulator with correlated pace/efficiency noise, Student-t parameter perturbations, batch sensitivity ranges, explicit overtime convention and supported full-game markets. Outputs remain exploratory until exact-scope validation.
- Added multi-operator two-way market audit with freshness, event/scope identity, per-book no-vig prices, median consensus, dispersion, overround, best price and optional opening-to-current movement.
- Added canonical market-scope builder isolating competition, season, sex/category, level, market family, period, settlement rule and pregame/live state.
- Added prospective/rolling performance monitor retaining accepted and rejected decisions, reporting hit-rate/Wilson, Brier, Log Loss, ECE, market baseline, high-confidence bucket and model degradation/suspension alerts.
- Added separate v19 CLI, templates, detailed operating references and 21 new unit tests. No live provider credentials, historical sports data, bookmaker integration or prevalidated v19 models are bundled.
- Hardened the possession simulator to report unconditional full-win probability and separate push/half-settlement distributions; added two-way and quarter-line settlement handling, repeated five-minute overtime periods and expected net return when decimal odds are supplied.
- Corrected lineup minute allocation to redistribute court time under per-player game-minute caps and report team player-minute totals; rejected invalid opening-to-current quote chronology.
- Added pytest root-path configuration so both `pytest -q` and `python -m pytest -q` collect the package consistently. Final suite: 81/81 tests pass under pytest and unittest; this is software verification, not predictive validation.


## 20.0.0 — 2026-11-20

- Añadida capa offline-first con SQLite local y sin proveedores/API preconfigurados.
- Añadido registro de fuentes/licencias y trazabilidad SHA-256 de imports.
- Añadida importación manual CSV de juegos, estadísticas por equipo-partido y cuotas.
- Añadido ledger prospectivo append-only para picks aceptados/rechazados y liquidaciones.
- Añadidos controles timezone-aware y bloqueos de look-ahead.
- Añadidos tests unitarios específicos de almacenamiento, importación, timestamps, odds y append-only.
- Se preservan motores v15-v19 y sus restricciones; no se declara validación predictiva nueva.
