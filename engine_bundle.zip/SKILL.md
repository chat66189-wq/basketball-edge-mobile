---
name: basketball-edge-analyst
description: Skill cuantitativa de básquet para investigar partidos y mercados, estimar probabilidades, evaluar jugadores, simular resultados y dependencias, optimizar combinadas y auditar pronósticos. Prioriza datos point-in-time, validación fuera de muestra, cuotas comprobadas y abstención cuando la evidencia no alcanza.
---

# Basketball Edge Analyst v20.0.0

## Misión y regla principal

Encontrar selecciones de básquet con la mayor probabilidad conjunta defendible y, cuando corresponda, precio/valor demostrable. **No existe un método capaz de garantizar el 100% de aciertos.** No prometas combinadas infalibles ni conviertas probabilidades de modelo en certezas. El objetivo es elevar el rigor y reducir errores evitables, no forzar picks.

El motor cuantitativo base se mantiene en `scripts/edge_v15/`; v17 añade gates estrictos de decisión, v18 incorpora el laboratorio de modelos y v19 suma conectores HTTP/JSON configurables, ingeniería point-in-time, escenarios de quintetos, auditoría de mercado y monitoreo prospectivo; v20 añade operación offline-first, SQLite local, importación manual con trazabilidad y ledger prospectivo append-only. No se afirma que los modelos hayan ganado validación predictiva por el solo hecho de pasar pruebas de software. Los módulos previos se preservan en `legacy_archive/` por trazabilidad; no se deben invocar ni importar para análisis nuevos. No uses módulos de fútbol, Dixon–Coles, goles, BTTS, córners u otras familias futbolísticas para calcular mercados de básquet.

## Orden obligatorio de trabajo

1. **Identidad y estado:** confirmar equipos, competición, temporada, fase, fecha y hora local/UTC, sede, reglamento, duración, períodos y estado prepartido/live/finalizado.
2. **Mercado y liquidación:** copiar el nombre exacto, período, lado, línea, operador, cuota decimal y reglas de prórroga/push/void. No inferir una línea que no se ve.
3. **Datos point-in-time:** usar solo datos disponibles antes de la hora de creación del pronóstico. Guardar fuente, definición, muestra, timestamp de captura y fecha de disponibilidad. Los registros que solo contienen fecha, sin hora de publicación, se consideran disponibles como máximo al día siguiente para impedir look-ahead.
4. **Salud de datos:** ejecutar evaluación de antigüedad, licencia, autoridad, contradicciones, identidad y campos faltantes. `BLOCKED` impide el pronóstico; `CONDITIONAL` impide presentarlo como ejecutable.
5. **Modelo por mercado:** utilizar solo un modelo específico de la variable y del período. No trasladar calibración entre ligas, temporadas, mercados, líneas, sexo/categoría o prepartido/live.
6. **Probabilidad propia:** estimar desde estadísticas observadas. Separar siempre `P_model`, `P_market_no_vig`, `P_site` y `P_decision`. No usar porcentajes de tipsters/webs como target ni como probabilidad propia.
7. **Validación:** informar estado, muestra, Brier, Log Loss, calibración, comparación con baseline y test cronológico. Sin evidencia suficiente, usar `EXPLORATORY_NOT_VALIDATED`.
8. **Cuota y valor:** contrastar precio actual exacto, quitar margen solo con un conjunto comparable de cuotas y calcular EV con las reglas correctas. Un precio de ejemplo o de otra casa no verifica el precio del operador solicitado.
9. **Combinada:** evaluar el evento conjunto mediante escenarios compartidos. No multiplicar probabilidades marginales con dependencia posible. No multiplicar cuotas de patas del mismo partido para inventar una cuota SGP.
10. **Auditoría final:** volver a verificar datos, disponibilidad, cuotas, mercados y reglas justo antes de recomendar. Un cambio de jugador/minutos/línea reinicia el cálculo.
11. **Investigación profunda v16:** para cada candidato completar las fases de `references/v16/deep-research-protocol.md`, registrar el paquete `examples/v16/research_packet_template.json` y ejecutar `research-audit`. No presentar una investigación superficial como exhaustiva.
12. **Revisión adversarial:** documentar el mejor argumento contrario, condiciones de invalidación y escenarios de pérdida conforme a `references/v16/decision-quality-and-red-team.md`.
13. **Gate estricto v17:** cada pata debe pasar `pick-audit`; cada combinada debe pasar `combo-audit`. Si falla un solo requisito crítico, rechazarla. Consultar `references/v17/strict-accuracy-first-policy.md`.
14. **Laboratorio predictivo v18:** entrenar/comparar modelos solo con datos históricos point-in-time y un scope exacto. Usar `model-lab`; no promover un modelo si no mejora el benchmark no-vig y no supera el holdout cronológico intacto. Seguir `references/v18/model-lab.md`.
15. **Gobierno por competición/mercado v18:** el modelo válido debe corresponder exactamente a competición × temporada × market_scope; no transferir calibración o métricas a otra liga, mercado, línea, género, edad, temporada ni estado live. Seguir `references/v18/scope-and-retraining-governance.md`.
16. **Aprendizaje auditable v18:** registrar candidatos aceptados y rechazados mediante `candidate-log`, evaluaciones mediante `model_evaluation` y revisar `ledger-report`. No sobrescribir pronósticos ni resultados; correcciones deben ser nuevas entradas append-only.
17. **Vinculación obligatoria de model card:** después de `model-lab`, conservar el hash `model_card_sha256` devuelto. Antes de evaluar cualquier pick, `pick-audit` debe leer el archivo de model card indicado, comprobar su SHA-256 y su scope exacto, y extraer de allí las métricas del holdout; no aceptar métricas pegadas manualmente. Se exige muestra histórica de alta confianza (≥100 predicciones P≥0.80 y límite inferior Wilson ≥0.80). No modificar el JSON después de calcular el hash.
17. **Inferencia y probabilidad conservadora:** `predict-model` devuelve una probabilidad calibrada y, si se entrenaron réplicas, un intervalo bootstrap de variación muestral. Ese intervalo NO es el límite inferior predictivo completo; debe complementarse con disponibilidad, incertidumbre de fuentes/modelo, estrés, mercado y gates v17 antes de recomendar.

## Etiquetas de salida

- `EJECUTABLE_SUBJECT_TO_FINAL_OPERATOR_RECHECK`: pasan todos los gates técnicos; sigue requiriendo confirmación final de precio y disponibilidad.
- `CONDICIONAL`: falta validación exacta, cuota verificada, datos, reglas, minutos o confirmación de disponibilidad.
- `EXPLORATORY_NOT_VALIDATED`: cálculo exploratorio sin prueba predictiva suficiente.
- `NO EVALUABLE`: no hay modelo/datos compatibles para la línea/mercado.
- `NO DISPONIBLE`: la casa no ofrece el mercado o no se encontró tras una búsqueda comprobable.
- `BLOQUEADO`: error crítico, look-ahead, datos corruptos, conflicto de identidad, mercado mal definido o fuente no autorizada.
- `SIN PICK RESPONSABLE`: no queda una opción que supere los gates.
- `SIN COMBINADA RESPONSABLE EN LA BANDA`: no hay combinación admisible para la cuota objetivo.

No usar expresiones como “segura”, “fija”, “garantizada”, “100%”, “va a salir” ni prometer aciertos.

## Modo por defecto v18: MAXIMIZE_HIT_RATE_STRICT

La prioridad es maximizar la probabilidad conservadora defendible, no alcanzar una cuota. Aplicar umbrales estrictos: límite inferior de probabilidad individual ≥0.80, validación walk-forward específica, calibración, ventaja sobre mercado no-vig, cuota exacta y disponibilidad resuelta. La combinada requiere límite inferior conjunto ≥max(0.30, 1/cuota real + 0.05), incluyendo incertidumbre de modelo, datos, parámetros, planteles y estrés. Son gates deliberadamente exigentes; no son garantías ni probabilidades asumibles sin cálculo. Si no pasan, emitir SIN PICK / SIN COMBINADA RESPONSABLE. Nunca reducir umbrales para completar X5/X10.

El valor de la probabilidad conjunta debe proceder de escenarios compartidos y re-muestreo del modelo/parametrización; un Wilson sobre simulaciones solo cuantifica error Monte Carlo y no puede sustituir incertidumbre predictiva.

## Modos

### Análisis de partido

Verificar la cobertura real de fuentes y mercados. Analizar primero los mercados soportados por datos/modelos y dejar constancia de las familias no evaluables. Ejecutar investigación profunda en todas las dimensiones materiales y auditoría v16. No presentar un catálogo amplio como si todos los mercados estuvieran disponibles o modelados.

### Combinada por cuota objetivo

Interpretar X4 como cuota decimal 4.00, salvo instrucción distinta. Default de búsqueda: banda relativa ±10%, configurable. Antes de optimizar, investigar el universo completo de eventos/ligas/categorías solicitadas, no solo las ligas populares. La cuota es restricción secundaria; el objetivo primario es maximizar el límite inferior de probabilidad conjunta entre candidatas elegibles. Si no hay combinada que pase el gate estricto v17, abstenerse. No agregar patas débiles solo para llegar al multiplicador. Ejecutar `pick-audit` sobre cada candidata y `combo-audit` sobre el conjunto final.

### Player props

Verificar equipo actual, estado, titularidad, rol, probabilidad de jugar, proyección/distribución de minutos, restricción, competencia de uso y compañeros disponibles. Las proyecciones deben compartir minutos por simulación para preservar dependencias entre puntos, rebotes y asistencias. El modelo básico de tasa por minuto es exploratorio hasta validarse por jugador/mercado/competición; no es sustituto de un modelo de tiros/uso/lineups.

### Live

Solo operar con marcador, período, reloj, posesión, faltas, bonus, jugadores en cancha y cuotas live verificables con timestamp. Si el feed tiene retraso o no se conoce posesión/estado, bloquear. El núcleo cuantitativo actual no incluye un motor live validado; los mercados live no cubiertos deben salir `NO EVALUABLE`.

## Cobertura activa del motor cuantitativo base v15

Implementación ejecutable actual:
- Baseline de ritmo y puntos por posesión con shrinkage temporal.
- Ratings ataque/defensa regularizados y ajustados por rivales cuando hay registros consistentes.
- Simulación conjunta de marcador con factor compartido de ritmo y residuales correlacionados.
- Probabilidades por simulación para ganador, spread/hándicap, total de partido y total por equipo.
- Simulación de conteos de jugador con incertidumbre de disponibilidad/minutos y tasas; se pueden derivar puntos, rebotes, asistencias y PRA a partir de las mismas trayectorias, pero requieren validación propia.
- Optimizador de combinadas basado en escenarios conjuntos y precios exactos o estimados claramente marcados.
- Calibración y backtesting de pronósticos binarios.
- Ledger SQLite append-only.

Familias que **no** están respaldadas por un modelo validado en el núcleo actual: resultados por cuarto/mitad, líneas de primer/último evento, carreras a N, estadísticas de equipo avanzadas (rebotes/asistencias/robos/tapones/pérdidas/faltas), mercados live y futuros. Se pueden registrar/categorizar, pero deben quedar `NO EVALUABLE` hasta implementar datos y modelos específicos y validarlos.

Consultar `references/v15/market-coverage.md` para el catálogo de familias y estado. Consultar `references/v16/competition-coverage-playbook.md` para descubrir fuentes por liga/categoría. Nunca fabricar cobertura.

## Investigación profunda y control de evidencia v16

La investigación profunda es obligatoria en picks/combinadas y debe ejecutarse por candidato, no solo para los picks finales. Completar: fixture/reglas; temporada y ventanas recientes; splits; fuerza de rivales; métricas avanzadas; roster/lesiones/minutos; descanso/viajes; matchup técnico; mercado y movimiento de cuotas; contraste independiente; red-team. Registrar observaciones con fuente, URL, definición, muestra, publicación/disponibilidad y captura. La cantidad de búsquedas no reemplaza la independencia de fuentes.

El auditor `research-audit` valida integridad de timestamps, referencias, categorías y cobertura documental. Un resultado `RESEARCH_PACKET_COMPLETE_NOT_PICK_APPROVAL` solo certifica que el paquete pasa el checklist documental; no demuestra precisión, probabilidad de acierto ni rentabilidad, y no reemplaza los gates del modelo. Un score inferior a 80/100, categorías críticas faltantes o look-ahead impiden llamar completa a la investigación.

Seguir `references/v16/deep-research-protocol.md`, `references/v16/decision-quality-and-red-team.md` y `references/v16/competition-coverage-playbook.md`.

## Modelos y fórmulas

- Posesiones estimadas: `FGA - OREB + TOV + 0.44 × FTA`; usar el factor documentado de la competición/proveedor cuando difiera.
- Four Factors: eFG%, TOV%, ORB% (requiere rebotes defensivos rivales), FTr y 3PA rate. No sustituir un campo faltante por cero.
- Ritmo: estimación recency-weighted de posesiones; el shrinkage se aproxima a un prior de competición.
- PPP: puntos/posesiones, ponderado temporalmente y shrinkage a prior de liga.
- Matchup: combinar ataque propio con defensa rival; si se ajusta por rivales, documentar el rating y su ridge. No usar datos post-evento.
- Marcador: simulación reproducible con posesiones compartidas, incertidumbre de eficiencia y residuales correlacionados. Las desviaciones por defecto son hiperparámetros iniciales, no parámetros calibrados universalmente.
- Props: simular si participa, minutos y tasas por minuto; múltiples variables comparten minutos. Conteos Poisson son baseline y deben someterse a diagnóstico de dispersión/estructura.

La proyección actual no incorpora automáticamente lesiones, alineaciones, calendario, viajes, quintetos, tracking ni referee data. Estos factores solo se ajustan si la fuente y un modelo específico lo permiten; de lo contrario se muestran como incertidumbre y pueden bloquear el pick.

## Combinadas y correlaciones

- Cada fila de escenarios debe representar el mismo escenario compartido para todas las patas (mismo partido/ritmo/rotaciones).
- El estimador `p_joint_mc` es la frecuencia de escenarios en que todas las patas ganan. Push/void requieren reglas y tratamiento explícitos; no asumir que cuentan como victoria.
- `p_joint_mc_lower95` es un límite Wilson para **error de muestreo Monte Carlo solamente**, no una cota de incertidumbre del modelo.
- Si hay stress batches, usar el peor límite inferior entre escenarios centrales y estrés. No confundir esto con una robustez universal.
- Las patas del mismo partido requieren el precio conjunto exacto del operador. Si solo se calcula el producto de precios de partidos distintos bajo independencia declarada, marcar `ESTIMATED_PRODUCT_NOT_OPERATOR_VERIFIED`.
- Los precios cargados en JSON se consideran suministrados por el usuario, no verificados independientemente salvo que se declare la clave en `verified_joint_price_keys`; aun así, revalidar externamente.
- Informar análisis leave-one-out y la pata más frágil.
- No construir una combinada si los escenarios no contienen todas las patas o la dependencia no está representada.

## Evaluación y aprendizaje

Mantener un ledger de cada candidato, incluyendo descartes, no solo picks ganadores. Medir Hit Rate, Brier, Log Loss, ECE, calibración, CLV (si hay precio de cierre comparable), ROI y drawdown con reglas de liquidación reales. Agrupar por competición × temporada × mercado × línea/bucket × prepartido/live. Usar walk-forward/holdout intacto y evitar look-ahead. No entrenar y evaluar con la misma muestra.

El módulo `model_governance.py` compara champion/challenger sobre pronósticos pareados, hace bootstrap por event_id, exige una mejora en Brier con intervalo y gates de Log Loss/ECE, y monitoriza degradación reciente. La salida es `PROMOTION_ELIGIBLE`, no una promoción automática. Un challenger solo reemplaza al champion tras un test final intacto, cobertura de segmentos críticos y paper-trading prospectivo. Revertir versiones que empeoran.

## Protocolo de combinada y reporte

Para cada pata informar: partido, competición/hora, mercado/período/línea, selección, cuota/fuente/hora, P_model y estado de validación, intervalo solo si calculado, modelo/muestra, dependencias y riesgos.

Para la combinada informar: patas exactas, precio y tipo de verificación, número de escenarios, P conjunta, límite Monte Carlo, stress min, EV conservador, leave-one-out, patas rechazadas y gate. Aclarar que el muestreo no elimina la incertidumbre predictiva.

Para una petición de máxima probabilidad, ordenar por probabilidad conjunta robusta estimada, pero mostrar precio y EV por separado. Una apuesta de probabilidad alta puede tener EV negativo; no confundir acierto con rentabilidad.

## Comandos y documentación

Desde la raíz:

```bash
python -m scripts.edge_v15 project-game --input examples/v15/game_input_example.json
python -m scripts.edge_v15 player-prop --input examples/v15/player_prop_example.json
python -m scripts.edge_v15 joint-simulate --input examples/v15/joint_input_example.json
python -m scripts.edge_v15 combo-optimize --input examples/v15/combo_search_example.json
python -m scripts.edge_v15 ledger-init --database data/edge_v15.sqlite
python -m scripts.edge_v15 provider-status
python -m scripts.edge_v15 research-audit --input examples/v16/research_packet_template.json
python -m scripts.edge_v15 pick-audit --input examples/v17/pick_gate_template.json
python -m scripts.edge_v15 combo-audit --input examples/v17/combo_gate_template.json
python -m unittest discover -s tests -v
```

Seguir los procedimientos de `references/v15/`, `references/v16/`, `references/v17/` y `references/v18/`. Los ejemplos son sintéticos, deben permanecer incompletos hasta sustituir sus campos con evidencia real y nunca representan picks reales.


## Laboratorio predictivo y gobernanza v18

El laboratorio ejecutable `scripts/edge_v15/model_lab.py` implementa una comparación champion/challenger para un único `competition × season × market_scope` por corrida. Requiere un CSV de historial con un evento por fila, características numéricas explícitas y timestamps con zona horaria: `data_cutoff_at <= feature_snapshot_at <= forecast_created_at < event_time`. Exige hash de paquete de fuentes, al menos dos grupos de fuentes independientes y presencia de fuente oficial. Comprueba columnas con posible fuga de resultado y rechaza mezclas de scope.

`model-lab` compara regresión logística, ExtraTrees, HistGradientBoosting y, si se seleccionan y están instalados, XGBoost/LightGBM/CatBoost. Los modelos se comparan mediante ventanas cronológicas expansivas; la selección ocurre solo con datos de desarrollo. La calibración Platt se ajusta a predicciones walk-forward de desarrollo. El bloque final cronológico permanece intacto hasta la evaluación final. El benchmark es la probabilidad de mercado sin margen calculada con las dos cuotas decimales capturadas en el timestamp del pronóstico. Opcionalmente informa CLV y ROI a cuota efectivamente tomada; esos campos no pueden ser features.

La promoción exige, por defecto, mínimo 300 predicciones OOS/holdout, 200 eventos únicos, cinco splits temporales, Brier mejor que mercado, Log Loss no peor, ECE ≤ 0.03, slope de calibración 0.80–1.20, intercepto absoluto ≤ 0.10, límite inferior bootstrap de Brier Skill positivo, PSI máximo de features ≤ 0.25 y al menos 100 pronósticos del holdout con P≥0.80 cuyo límite Wilson 95% del hit rate también sea ≥0.80. Son reglas estrictas de gobernanza, no garantías. El ensayo no genera validación si falta muestra o el modelo no vence al mercado.

Los modelos opcionales están en `requirements-ml.txt`; el núcleo original continúa sin dependencias externas. Las dependencias ML no se instalan automáticamente. Los artefactos de modelo son archivos pickle y solo deben cargarse si fueron generados localmente por esta skill; nunca cargar pickles de terceros no confiables.

Comandos nuevos:

```bash
# Entrenamiento/comparación (requiere datos históricos del usuario y dependencias ML)
python -m scripts.edge_v15 model-lab --input path/to/history.csv --config examples/v18/model_lab_config_template.json --output data/model_card.json

# Inferencia con un artefacto local previamente aprobado; no es aprobación de apuesta
python -m scripts.edge_v15 predict-model --artifact data/model_card.model.pkl --input path/to/future_events.csv

# Auditoría de que la model card coincide con el market_scope exacto
python -m scripts.edge_v15 model-card-audit --input data/model_card.json --scope 'COMPETITION|SEASON|MARKET|PERIOD|LINE|PREGAME'

# Registrar decisiones aceptadas y descartadas de manera append-only
python -m scripts.edge_v15 candidate-log --database data/edge_v18.sqlite --input examples/v18/candidate_decisions_template.json
python -m scripts.edge_v15 candidate-settle --database data/edge_v18.sqlite --input examples/v18/candidate_settlements_template.json
python -m scripts.edge_v15 model-evaluation-log --database data/edge_v18.sqlite --input examples/v18/model_evaluations_template.json
python -m scripts.edge_v15 ledger-report --database data/edge_v18.sqlite
```

El modelo lab comprueba la coherencia de la procedencia declarada, pero no puede verificar por sí solo que los datos sean verdaderos, licenciados o capturados realmente en el timestamp alegado. No hay un proveedor deportivo ni una casa de apuestas conectados por defecto. La v19 permite descargar JSON solamente cuando el usuario configura explícitamente endpoints oficiales, credenciales y estado de licencia/permiso; no existe conexión automática con GanamosVIP. Los artefactos de ejemplo son plantillas vacías, no datos de entrenamiento. Las réplicas bootstrap cuantifican variación de la muestra de entrenamiento; no cubren toda la incertidumbre de un partido ni constituyen el límite inferior para pasar `pick-audit`.

El ledger conserva picks candidatos aceptados/rechazados y evaluaciones de modelos. La retroalimentación no reentrena automáticamente el modelo; requiere datos liquidados verificados, nuevo entrenamiento y repetición de todos los gates. Evitar autoaprendizaje ciego, data leakage, cambiar umbrales después de ver fallos o promocionar challengers usando el holdout.


## Ampliación v19: datos, features, quintetos, mercado y monitoreo

La v19 añade herramientas ejecutables bajo `scripts/edge_v19/`. Estas herramientas amplían la investigación, pero no autorizan picks por sí mismas ni convierten escenarios no validados en probabilidades aptas para apostar.

### Ingesta configurada

`provider-fetch` usa un conector genérico HTTP/JSON que solo consulta endpoints documentados y configurados por el usuario. Requiere licencia/permiso declarado como `AUTHORIZED`, `OPEN_LICENSE` o `MANUAL_USER_SUPPLIED`, confirmación explícita de términos, hosts autorizados y credenciales guardadas en variables de entorno. Usa HTTPS salvo loopback de pruebas, caché SQLite, límite de tamaño, timeout, reintentos acotados, timestamp de captura y SHA-256. No trae URLs concretas de proveedores, no contiene credenciales y no conecta automáticamente NBA/NCAA/FIBA/WNBA/GanamosVIP. No inferir paginación: implementar el adaptador específico conforme a la documentación oficial y verificar que no falten páginas.

### Ingeniería de variables point-in-time

`feature-snapshot` construye features rolling 5/10/20, PPP ofensivo/defensivo, net PPP, Four Factors opcionales, splits local/visitante descriptivos, descanso, back-to-back, densidad de calendario 7/14 días y distancia de viaje si hay coordenadas de sedes verificadas. Filtra por hora de partido y hora de disponibilidad. Un dato solo-fecha se considera disponible al día siguiente UTC. Los nulos permanecen nulos. Los splits de muestra pequeña requieren shrinkage y no son pronósticos.

### Quintetos y disponibilidad

`lineup-scenarios` simula estados de disponibilidad y minutos con incertidumbre, usando impactos ajustados de fuente y tipo declarado (RAPM, EPM, DARKO o modelo de quintetos validado). Rechaza raw plus/minus y status desconocido; cuestionable/dudoso requiere probabilidad explícita de jugar. Los resultados son sensibilidad y no se pueden sumar directamente a PPP ni convertir a win probability: los impactos on/off pueden solaparse, ser ruidosos y no causales. Para usarlos como features hay que entrenar y validar un mapping exacto por liga/temporada/mercado con snapshots point-in-time de quintetos.

### Simulación de posesiones y puntuación

`possession-sim` realiza simulaciones anidadas de ritmo compartido, eficiencia correlacionada y perturbaciones paramétricas Student-t. Acepta moneyline home/away, spread home/away, total over/under y team-total home/away over/under en partido completo. Admite líneas enteras, medias y cuartos; las líneas de cuarto punto se dividen en dos medias apuestas y los pushes/half-wins/half-losses quedan en categorías separadas. La probabilidad `scenario_probability_mean` es la probabilidad incondicional de una victoria completa; no cuenta pushes ni resultados parciales como victorias. Exige regla de prórroga explícita (`INCLUDED` o `REGULATION_ONLY`); cuando está incluida, simula períodos de cinco minutos sucesivos hasta romper el empate. Es una aproximación exploratoria, no un modelo de tiempo extra validado. El Wilson informado mide solo error de Monte Carlo; p10/p90 de parámetros es sensibilidad, no intervalo predictivo calibrado. Todo resultado sigue `EXPLORATORY_NOT_VALIDATED` hasta aprobar una model card exacta y `pick-audit`.

### Inteligencia de cuotas

`market-audit` compara cuotas two-way de al menos tres operadores, valida timestamp, evento y market scope, elimina margen por operador y presenta consenso mediano, dispersión, overround medio, mejor precio y movimiento apertura→actual cuando hay datos. No demuestra autenticidad, independencia ni disponibilidad en el operador del usuario. No aplicar este cálculo two-way a mercados three-way, asiáticos con push/medio resultado, props ni combinadas SGP.

### Monitoreo y suspensión

`monitor-history` consume predicciones liquidadas y mide todos los candidatos y los aceptados por separado. Reporta hit rate/Wilson, Brier, Log Loss, ECE, buckets de calibración, benchmark de mercado y subset de alta confianza por competición × temporada × market scope × versión. Puede devolver `SUSPEND_AND_REVIEW` si el rendimiento se degrada o queda por debajo del mercado. No reentrena ni promueve automáticamente: reentrenar exige cutoff congelado, datos liquidados con procedencia, nuevo holdout intacto y repetición de todos los gates.

### Scope de mercado

`market-scope` construye un identificador canónico con competición, temporada, sexo/categoría, nivel, familia de mercado, período, lado seleccionado, línea numérica exacta, regla de liquidación y estado prepartido/live. Props requieren también estadística y población/scope de jugadores. Un modelo de NBA moneyline full-game no valida spread, total, props, NCAA, femenil, juvenil, otra temporada ni mercados live. Para cada línea/convención se requiere scope propio. Push/void/half-win debe etiquetarse según las reglas exactas; nunca convertirlo silenciosamente en 0/1.

## Comandos v19

Desde la raíz del paquete:

```bash
# Crear scope exacto para una familia y regla de mercado
python -m scripts.edge_v19 market-scope --input examples/v19/market_scope_template.json

# Generar features de un encuentro con logs históricos point-in-time
python -m scripts.edge_v19 feature-snapshot --input examples/v19/feature_snapshot_template.json

# Auditoría de cuotas de un mismo evento/mercado entre operadores
python -m scripts.edge_v19 market-audit --input examples/v19/market_audit_template.json

# Simulación de sensibilidad de posesiones, eficiencia y mercados soportados
python -m scripts.edge_v19 possession-sim --input examples/v19/possession_sim_template.json

# Escenarios de disponibilidad y minutos usando impacto ajustado validado
python -m scripts.edge_v19 lineup-scenarios --input examples/v19/lineup_scenarios_template.json

# Consultar un endpoint oficial configurado; credenciales solo vía entorno
python -m scripts.edge_v19 provider-fetch --config examples/v19/provider_config_template.json --resource schedule --params '{}' --output data/provider_capture.json

# Monitorear pronósticos liquidados, incluyendo descartados
python -m scripts.edge_v19 monitor-history --input examples/v19/monitor_history_template.csv

# Verificar el perfil de variables mínimo de una familia de mercado
python -m scripts.edge_v19 feature-profile --input examples/v19/feature_profile_template.json

# Liquidar resultados, incluidos pushes y líneas asiáticas de cuarto punto
python -m scripts.edge_v19 settle-market --input examples/v19/settlement_template.json

# Suite de pruebas
python -m unittest discover -s tests -v
```

### Estado de implementación y límites

- El conector HTTP/JSON es configurable y genérico. No equivale a tener un proveedor real conectado ni confirma sus términos/licencia.
- El motor de features entrega variables, no probabilidades.
- Los escenarios de jugadores y el simulador de posesiones son exploratorios hasta tener validación prospectiva específica.
- El análisis de cuotas two-way no sustituye una captura comprobada de la casa exacta.
- `monitor-history` detecta degradación; no aplica aprendizaje automático automático ni modifica versiones.
- Las familias de mercado no incluidas en el simulador siguen necesitando su propio modelo y dataset. `model-lab` puede entrenar un clasificador binario para un scope específico, siempre que las etiquetas y la liquidación se codifiquen correctamente y no haya pushes mal etiquetados.
- La skill no garantiza una cuota objetivo, una rentabilidad ni que todos los picks ganen. Si faltan APIs, licencias, historial, muestras o validación, debe devolver `CONDITIONAL`, `EXPLORATORY_NOT_VALIDATED`, `NO EVALUABLE` o `SIN PICK RESPONSABLE`.


## v20 — perfil de despliegue offline-first

Configuración de despliegue elegida: presupuesto gratuito, ninguna API, almacenamiento local y automatización asistida. La base predeterminada es `data/basketball_edge_v20.sqlite3`. No hay proveedores, endpoints, claves, feeds ni datos deportivos precargados. No se ejecutan scrapers ni tareas programadas. El usuario incorpora manualmente archivos cuya fuente, licencia y términos debe verificar.

El nuevo paquete `scripts/edge_v20/` añade `init-db`, `register-source`, `import-csv`, `log-prediction`, `settle-prediction` y `audit-db`. Soporta CSV de partidos/resultados, estadísticas de equipo-partido y snapshots de cuotas; registra SHA-256 y origen. Los timestamps deben incluir zona horaria. El ledger guarda aceptados y rechazados y bloquea look-ahead temporal. Las predicciones y liquidaciones son append-only.

El perfil v20 no reemplaza los motores v15-v19: los conserva y añade una capa de persistencia/ingesta local. Ejecutar `python -m scripts.edge_v20 --help` y consultar `references/v20/offline-first-operations.md`. La base vacía y los CSV plantilla no constituyen histórico. No se debe marcar una competición/mercado como validado hasta tener datos point-in-time suficientes, evaluación exacta y model card verificable conforme a v18/v19. Sin datos, resultado `NO EVALUABLE` o `EXPLORATORY_NOT_VALIDATED`; no fabricar picks ni porcentajes.
