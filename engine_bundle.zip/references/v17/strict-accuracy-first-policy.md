# Política v17 — precisión primero y abstención estricta

## Lo que la skill no puede prometer

Ningún modelo ni investigación puede hacer que todos los picks ganen. El resultado de un partido conserva incertidumbre, incluso si el favorito, los datos y el precio están correctamente analizados. No se debe afirmar ni insinuar que la skill garantiza todos los aciertos. No inventar porcentajes ni presentar una explicación convincente como prueba de precisión.

## Cambio de objetivo

Modo por defecto: `MAXIMIZE_HIT_RATE_STRICT`. La prioridad es seleccionar pocas patas con la mayor probabilidad conservadora defendible. La cuota objetivo es secundaria. Si no hay picks admisibles, la salida correcta es `SIN PICK` o `SIN COMBINADA RESPONSABLE`; jamás rebajar los criterios para completar X5/X10.

## Gate individual obligatorio

Cada selección debe pasar `pick-audit` y todos los requisitos siguientes:

1. Partido futuro, identidad/competición/reglas confirmadas y mercado exacto soportado por el modelo.
2. Calidad de datos `PASS`, integridad point-in-time aprobada y sin look-ahead.
3. Mínimo dos grupos de fuentes independientes y al menos una fuente oficial de competición/club. Fechas de disponibilidad y consulta anteriores al pronóstico.
4. Mercado, liquidación, operador y cuota exacta verificados; cotización de hasta 10 minutos, salvo TTL configurado de forma explícita.
5. Estado de disponibilidad `CONFIRMED` o `NOT_MATERIAL`; ninguna incertidumbre material pendiente.
6. Validación walk-forward intacta y específica al `market_scope` exacto. Por defecto, al menos 300 predicciones OOS, 200 eventos únicos agrupados y 5 bloques walk-forward.
7. Brier mejor que el baseline de mercado; log loss no materialmente peor; ECE ≤ 0.03; slope de calibración 0.80–1.20 e intercepto absoluto ≤ 0.10. Informar siempre todos los métricos y la ventana de evaluación.
8. Límite inferior 95% de la probabilidad predictiva ≥ 0.80, calculado con incertidumbre de parámetros/modelo/datos, disponibilidad y estrés de escenarios; no sirve un Wilson de Monte Carlo como sustituto.
9. El límite inferior conservador supera la probabilidad de mercado no-vig por al menos 1 punto porcentual. Si el baseline no puede calcularse con precios comparables, abstenerse.
10. Revisión adversarial sin contraindicación crítica.

Los umbrales son un filtro operativo deliberadamente estricto para el modo de alta tasa de acierto. No son constantes universales ni demuestran que una selección vaya a ganar. Se pueden endurecer; no se deben relajar después de ver el candidato. Una competición o mercado sin muestra suficiente no pasa.

## Gate de combinada obligatorio

Cada pata debe haber superado el gate individual. La combinada requiere:

- 2–6 patas como máximo en modo estricto.
- Precio real conjunto verificado en el mismo operador, mismas líneas y reglas revalidadas.
- Escenarios compartidos que incluyan todas las patas y sus dependencias; no multiplicar probabilidades marginales ni asumir independencia sin evidencia.
- Al menos 100.000 escenarios, además de bootstrap/reajuste del modelo y perturbación de parámetros/datos/lesiones/minutos.
- Límite inferior 95% de la probabilidad conjunta que incluya incertidumbre de modelo/datos/parámetros/plantel y pruebas de estrés.
- Probabilidad conjunta inferior mínima = `max(0.30, 1/cuota_real + 0.05)`. Si no se alcanza, no publicar la combinada como apta, aunque la cuota coincida con X5.
- El peor escenario de estrés también debe superar ese umbral.

Este suelo del 30% en torno a cuota X5 es un criterio estricto de política, no una probabilidad que deba suponerse. La mayoría de combinadas X5 no lo superará. Si los datos no permiten calcularlo, no es cero ni un número estimable: es desconocido y la combinación queda rechazada.

## Prácticas explícitamente prohibidas

- Elegir un equipo por su récord bruto, localía, racha o cuota baja sin ajustar nivel de rivales y métricas por posesión.
- Tratar derrotas recientes del rival como prueba de debilidad sin analizar márgenes, rivales, disponibilidad y calidad de juego.
- Usar H2H viejo como evidencia principal.
- Copiar picks de tipsters o tomar la cuota como predicción propia.
- Transferir un modelo NBA a NCAA, ligas regionales, femeninas o juveniles.
- Confundir la completitud del paquete de investigación con aprobación del pick.
- Reutilizar un pronóstico anterior sin nueva verificación de fixture, disponibilidad, mercados y precio.
- Seleccionar primero los nombres y luego buscar evidencia que los apoye.
- Omitir fallos, descartes, fallos de predicción o mercados donde el modelo tuvo mal desempeño.

## Postmortem obligatorio

Registrar cada candidato, incluido el descartado, su predicción congelada, cuota de captura, mercado, límites de probabilidad, evidencia, motivo de aceptación/rechazo, resultado/liquidación, CLV cuando sea comparable y causas del error. Etiquetar error de datos, disponibilidad, modelo, mercado, ejecución o varianza. Nunca reescribir retroactivamente la predicción ni ajustar los umbrales para justificar el último resultado.

## Comunicación al usuario

Mostrar para cada pick: probabilidad puntual y límite inferior, nivel de validación, cuotas/fuente/horario, tres razones cuantificadas, mayor argumento contrario, condiciones que lo invalidan y estado del gate. Para combinadas: probabilidad conjunta robusta, suelo exigido, estrés, cuota verificada y patas más frágiles. Si no se dispone de estos datos, decirlo y abstenerse. No usar las palabras “segura”, “fija”, “garantizada” ni “va a salir”.
