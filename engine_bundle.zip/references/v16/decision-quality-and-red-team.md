# Calidad de decisión y revisión adversarial — v16

## Cuatro conceptos distintos

1. **Probabilidad de acierto:** probabilidad de que la selección se liquide ganadora.
2. **Valor esperado:** depende de probabilidad, cuota y reglas; un pick probable puede tener EV negativo.
3. **Calidad de evidencia:** actualidad, precisión, independencia y relevancia de datos.
4. **Calidad del proceso:** cobertura del universo, gates y prevención de sesgo/look-ahead.

Nunca presentar un score de investigación como probabilidad de acierto.

## Orden obligatorio

1. Formar el universo completo de eventos elegibles.
2. Investigar candidatos de todas las ligas/categorías solicitadas; no detenerse en NBA ni en los primeros resultados.
3. Eliminar eventos mal identificados, suspendidos, live no soportados o con reglas desconocidas.
4. Eliminar mercados no cubiertos por un modelo específico.
5. Eliminar picks con datos críticos ausentes, precios no comparables o alineación decisiva no resuelta.
6. Comparar P_model validada, P_market_no_vig, edge, EV, incertidumbre y robustez.
7. En combinadas, optimizar probabilidad conjunta robusta primero y cuota después. No agregar patas débiles para cumplir X5/X10.

## Robustez obligatoria

Evaluar escenario base; conservador (ventaja reducida y varianza acorde al error histórico); escenarios de bajas/minutos; ritmo/eficiencia adversos; sensibilidad a variación razonable de línea; contraste con fuente estadística independiente. Escenarios deben salir del modelo/datos, no de porcentajes arbitrarios.

## Red-team por pata

Cada pick debe incluir el mejor argumento contrario, condición de invalidación y riesgo dominante. La evidencia a favor y en contra debe tener igual profundidad. No ocultar información negativa.

## Abstención

Abstenerse si no existe modelo compatible, la muestra es insuficiente, existe contradicción crítica de fixture/plantel/cuota, el precio o liquidación no están confirmados, o la ventaja desaparece en escenarios plausibles. Abstenerse de toda la combinada cuando ninguna opción pasa los gates. Ofrecer cuota menor solo como alternativa explícita, nunca degradando el estándar.

## Informe por selección

Fixture/competición/categoría/hora/estado; mercado/período/línea/regla; cuota y timestamp; evidencia positiva/negativa; temporada, últimos 10/5, splits y ajuste por rivales separados; disponibilidad/minutos/rol; calendario; matchup; P_model/P_market_no_vig/edge/EV y validación solo si existen; sensibilidad, riesgo dominante y gate.

## Informe conjunto

Cuota conjunta real o producto estimado entre eventos con independencia declarada; P conjunta desde escenarios compartidos; correlaciones; número de escenarios; stress; leave-one-out; pata más frágil; descartes y motivos. Diferenciar cuota, probabilidad y EV.
