# Playbook de cobertura por competición — v16

La siguiente matriz orienta la búsqueda; no garantiza cobertura, API pública ni disponibilidad de cada campo.

| Entorno | Fuente primaria a localizar | Contraste | Variables a confirmar |
|---|---|---|---|
| NBA | NBA.com, NBA Stats, informes oficiales de equipos | ESPN, Basketball-Reference, proveedores licenciados | injury report, starters, minutos, pace, ORtg/DRtg, lineups, play-by-play |
| WNBA | WNBA.com, boxscores y noticias oficiales | ESPN y proveedores con cobertura documentada | roster/lesiones, minutos, viajes, Four Factors |
| NCAA M/W | NCAA.com, universidades, boxscores oficiales | ESPN, Sports-Reference CBB/WBB, proveedores | elegibilidad, cancha neutral, rotación, calendario, pace, strength of schedule |
| Ligas nacionales/FIBA | Liga/club/federación, FIBA Game Center cuando aplique | proveedor regional, medios locales, SofaScore/Flashscore como contraste | plantilla/importados, reglas, fase, boxscore, sede, descanso |
| Femenino/juvenil | Organizador y clubes/canales oficiales de categoría | medios/proveedores específicos | edad/categoría, reglamento, roster, minutos, disponibilidad |
| Puerto Rico/Caribe/Centroamérica | Liga/club/federación y organizadores | medios locales, proveedores regionales | extranjeros, viajes, sedes, calendario, boxscores |
| Argentina/Chile/Uruguay/Colombia/México | Liga/federación y clubes oficiales | prensa local especializada y proveedor regional | roster, extranjeros, fase/serie, estadísticas, descanso y sede |

## Reglas para datos limitados

- Buscar nombre oficial, abreviaturas, idioma local, nombres anteriores y canales sociales oficiales.
- No confundir ligas de nombre parecido, reservas, juveniles, ramas femeninas/masculinas o amistosos.
- Con boxscores básicos, derivar únicamente métricas sustentadas por campos observados. No declarar pace/Four Factors si faltan FGA, FTA, pérdidas o rebotes necesarios.
- Si solo hay puntos y récord, no inferir eficiencia ni fuerza de calendario sin rivales/posesiones.
- Identificar fase, rondas, series y cancha neutral.
- Noticias locales son evidencia secundaria; corroborar cambios críticos con club/organizador.
- Si los datos no alcanzan, `NO EVALUABLE` es la conclusión correcta.

## Independencia y automatización

Dos webs que reproducen el mismo boxscore/comunicado no son dos fuentes independientes. Registrar `independence_group` según origen real. Respetar licencias, robots, términos y límites; no evadir login, paywall, captcha ni controles; nunca guardar credenciales en el ZIP.
