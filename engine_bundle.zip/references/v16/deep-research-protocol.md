# Protocolo de investigación profunda — Basketball Edge Analyst v16

## Principio

La profundidad no se mide por la cantidad de búsquedas ni por el volumen de texto: se mide por la cobertura de las variables que pueden cambiar el pronóstico, calidad e independencia de fuentes, vigencia, coherencia de definiciones y reproducibilidad. Investigar más no garantiza acertar; permite descubrir errores y abstenerse mejor. Este protocolo es obligatorio en solicitudes de picks y combinadas. No se permite escoger primero un favorito y buscar después datos que lo justifiquen.

## Fase 0 — Congelar el marco

Registrar antes de buscar: `as_of` ISO-8601 con zona horaria; ventana y hora local de cada partido; países, ligas y categorías (masculino/femenino/U21/U23); restricciones; universo completo de eventos elegibles; mercado, cuota objetivo, operador y reglas de liquidación. Toda noticia o dato posterior a `as_of` se excluye del pronóstico prepartido.

## Fase 1 — Confirmar partido y mercado

Para cada fixture, contrastar organizador/club con un proveedor independiente. Verificar nombres alternativos, sede, cancha neutral, hora y zona horaria, fase/serie, localía real, duración de cuartos, reglas de prórroga, aplazamiento y estado. Para cada mercado copiar literalmente operador, evento, período, tipo, lado, línea, cuota decimal, hora de captura, estado abierto/suspendido, overtime, push/void y límites. No inferir el mercado por un nombre abreviado. Cuota externa es referencia, nunca precio confirmado en la casa del usuario.

## Fase 2 — Evidencia estadística

Conservar por separado las ventanas de temporada actual, últimos 10 y últimos 5 partidos. Los tramos recientes reciben shrinkage y no reemplazan automáticamente la temporada. Medir, según disponibilidad: rendimiento y márgenes; ritmo/posesiones; puntos por posesión; ratings ofensivo/defensivo; Four Factors (eFG%, TOV%, ORB%, FTr); frecuencia y eficiencia de triples; distribución/variabilidad de márgenes y totales; split local/visitante y cancha neutral; fuerza y nivel de rivales; rendimiento contra estilos comparables. Ajustar por calendario y rivales cuando haya datos suficientes. H2H es contexto de bajo peso y se reduce si cambiaron plantillas, técnicos, categoría o temporada.

Cada observación debe guardar valor, unidad, definición, período, tamaño de muestra, competición/temporada, condición local/visitante, proveedor y timestamp de disponibilidad. Nunca convertir faltantes a cero ni combinar definiciones incompatibles.

## Fase 3 — Planteles, lesiones y minutos

Buscar roster vigente, lesiones, suspensiones, jugadores extranjeros/importados, bajas por selección, restricciones de minutos, descansos, cambios de entrenador, transferencias y quintetos probables. Prioridad: informe oficial de club/competición; después periodista local fiable o proveedor especializado; agregadores solo como pista. Por jugador registrar estado exacto, fuente, hora de publicación/actualización, rol, minutos recientes/esperados, incertidumbre y posible reemplazo. No llamar confirmado a un rumor ni a una noticia vieja.

Cuando una disponibilidad sea material, simular al menos escenarios de titular disponible, baja y minutos limitados. Recalcular la distribución en cada escenario. Si una baja relevante no se resuelve y domina el pick, degradar o abstenerse.

## Fase 4 — Calendario y entorno

Verificar descanso, back-to-back, tres partidos en cuatro noches, viajes, distancia, cambios de huso, altitud, secuencias fuera de casa, retorno de viaje largo, congestión, importancia de serie y posibilidad de rotación. No asumir efectos fijos: estimar con comparables o tratarlos como incertidumbre. Árbitros/reglas solo si existe dato oficial y evidencia pertinente. No sobreponderar narrativas de motivación sin respaldo.

## Fase 5 — Matchup técnico

Evaluar las interacciones relacionadas con el mercado: tamaño y rebote, protección del aro, perímetro, volumen/eficiencia de triples, pérdidas/presión, transición, tiros libres, emparejamientos, banca, defensa de pick-and-roll/poste, ritmo probable y capacidad de limitar fortalezas rivales. Usar lineup/on-off/play-by-play solo con muestra y fuente fiable. Separar hechos observados, inferencias y especulación; no aplicar ajustes numéricos arbitrarios por “ventaja táctica”.

## Fase 6 — Cuotas y mercado

Para moneyline/spread/total, intentar 3–5 operadores independientes y/o comparador fiable. En ligas pequeñas puede haber menos: declarar cuántos se verificaron, no completar con precios inventados. Comparar misma línea, período, lado, reglas y moneda. Registrar timestamp. Calcular probabilidad implícita y no-vig solo con ambos lados del mismo mercado comparable. No promediar líneas distintas. Guardar apertura, actual y cierre si están disponibles; distinguir movimiento observado de su causa desconocida. Comparar P_model con P_market_no_vig y EV al precio realmente disponible. Una cuota más alta que otra web no demuestra value.

## Fase 7 — Modelado y contrafactuales

Elegir modelo específico al mercado y competición. El baseline v15 solo es exploratorio hasta validación. Comparar baseline de liga, ratings ajustados por rivales, modelo propio y mercado no-vig; no elegir el modelo que casualmente favorece el pick. En datos escasos, usar shrinkage a priors de misma competición/categoría. No transferir tasas NBA directamente a NCAA, femenino, juvenil o ligas regionales. Muestras pequeñas amplían incertidumbre y elevan la abstención.

Ejecutar sensibilidad por ritmo lento/rápido, eficiencia alta/baja, titulares ausentes/disponibles, varianza aumentada, fuente estadística alternativa y cambio de línea. Reportar probabilidades y rangos solo si se calcularon. El Wilson de Monte Carlo mide error de simulación, no incertidumbre del modelo.

## Fase 8 — Red team y falsación

Antes de aceptar cada pick, buscar activamente el mejor argumento contrario: dato que contradice; si el precio ya incorpora la ventaja; racha causada por calendario fácil o varianza; lesiones ya descontadas; dependencia de split pequeño/H2H/jugador incierto; escenario realista de derrota; dato faltante que cambiaría la decisión. Si no sobrevive la revisión adversarial, se descarta.

## Fase 9 — Auditoría y decisión

Completar `examples/v16/research_packet_template.json` y ejecutar `research-audit`. Investigación documental completa exige ≥80/100, categorías críticas con evidencia, ausencia de errores de procedencia/look-ahead y contraste independiente de estadísticas cuando exista cobertura. El score es cobertura de investigación, nunca probabilidad de acierto ni aprobación.

La auditoría no aprueba apuestas. Para recomendar deben pasar también los gates de modelo/mercado/validación: línea y reglas exactas, modelo compatible, datos point-in-time, validación específica, calibración, dependencia conjunta y precio verificado. Si falta algo, etiquetar `CONDICIONAL`, `EXPLORATORY_NOT_VALIDATED`, `NO EVALUABLE` o abstenerse.

## Profundidad adaptativa

- Ligas con proveedor profundo: explotar play-by-play, lineups, posesiones y perfiles avanzados.
- Ligas con boxscores básicos: derivar solo métricas posibles y conservar incertidumbre.
- Ligas con resultados escasos o planteles poco documentados: buscar fuentes oficiales y locales; no simular precisión. `NO EVALUABLE` es una salida válida.
- Juveniles y femeninos: confirmar calendario, edad/categoría, reglas, roster y datos específicos; no asumir cobertura adulta/masculina.

No detenerse por alcanzar un número fijo de búsquedas. Detenerse cuando variables materiales estén cubiertas, conflictos resueltos o documentados y la incertidumbre residual esté reflejada en el gate.
