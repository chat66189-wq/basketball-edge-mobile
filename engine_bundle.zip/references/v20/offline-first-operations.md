# v20 — operación offline-first (free / sin API / local / asistida)

## Alcance implementado

- Base SQLite local, creada automáticamente en `data/basketball_edge_v20.sqlite3`.
- Registro explícito de fuentes, estado de licencia/permiso, confirmación de términos y atribución.
- Importación manual CSV para fixtures/resultados, estadísticas por equipo-partido y jugador-partido y snapshots de cuotas.
- Tablas locales para competiciones, temporadas, equipos, jugadores, planteles, lesiones, definiciones de mercado y evaluaciones de modelos; entidades de equipo/jugador/competición se registran manualmente.
- Hash SHA-256 por archivo importado y trazabilidad en `import_log`.
- Registro prospectivo de predicciones con timestamps timezone-aware y controles point-in-time/look-ahead.
- Liquidación append-only con WIN/LOSS/PUSH/VOID/HALF_WIN/HALF_LOSS/PENDING.
- Registro de cobertura por competición × temporada × market_scope y de ejecuciones/model cards.
- Auditoría del estado de almacenamiento y conteos.

## Límites deliberados

No hay APIs, scrapers, feeds, cuotas en vivo, resultados precargados, credenciales ni proveedores configurados. El motor v19 `provider-fetch` se conserva, pero no se configura ni ejecuta con esta instalación. No se garantiza que los CSV manuales sean completos, correctos o licenciados: el operador debe comprobar su procedencia, permisos, definiciones y calidad. La etiqueta `VALIDATED` solo debe asignarse cuando exista model card verificable y se hayan superado los gates exactos de v18/v19; el importador no valida modelos.

No hay automatización programada. El flujo asistido es: obtener/descargar datos manualmente desde una fuente autorizada → registrar fuente → importar → auditar → ejecutar análisis/model-lab existentes → revisar gates → registrar candidatos aceptados y rechazados → liquidar → monitorizar. Nunca completar huecos con ceros ni datos sintéticos.

## Esquemas CSV

- `games`: event_id, competition, season, event_time (ISO-8601 con zona), home_team, away_team, status; scores opcionales.
- `team_stats`: event_id, team, possessions, points; Four Factors opcionales. Importar después de `games`.
- `player_stats`: event_id, player_id, team, minutes, points; otras estadísticas opcionales. Registrar antes el jugador con `register-entity` e importar después de `games`.
- `odds`: event_id, market_scope exacto, operator, selection, decimal_odds (>1), captured_at con zona; line/rules opcionales.

Todos los IDs de eventos deben coincidir exactamente entre archivos. Para importar con `--source-id`, registrar primero esa fuente. Los registros se insertan sin sobrescribir; duplicados generan error para preservar trazabilidad. En las odds, la captura debe ser anterior al pronóstico para ser elegible como información point-in-time.

## CLI

Ejecutar desde la raíz del proyecto con Python 3.10+:

```bash
python -m scripts.edge_v20 init-db
python -m scripts.edge_v20 register-source --source-id manual_stats_01 --name "Nombre de fuente" --license MANUAL_USER_SUPPLIED --terms-confirmed --attribution "URL o referencia"
python -m scripts.edge_v20 register-entity --kind competition --id league_01 --name "Competición"
python -m scripts.edge_v20 register-entity --kind team --id team_01 --name "Equipo" --competition-id league_01
python -m scripts.edge_v20 register-entity --kind player --id player_01 --name "Jugador"
python -m scripts.edge_v20 import-csv --dataset games --file examples/v20/games_template.csv --source-id manual_stats_01
python -m scripts.edge_v20 import-csv --dataset team_stats --file examples/v20/team_stats_template.csv --source-id manual_stats_01
python -m scripts.edge_v20 import-csv --dataset player_stats --file examples/v20/player_stats_template.csv --source-id manual_stats_01
python -m scripts.edge_v20 import-csv --dataset odds --file examples/v20/odds_template.csv --source-id manual_stats_01
python -m scripts.edge_v20 log-prediction --input examples/v20/prediction_template.json
python -m scripts.edge_v20 settle-prediction --prediction-id ID --outcome WIN --net-units 0.9 --evidence "Referencia de liquidación"
python -m scripts.edge_v20 audit-db
```

Los CSV de ejemplo son solo encabezados y no contienen datos. El JSON de predicción contiene placeholders y debe reemplazarse completamente.

## Seguridad y operación

- Mantener el directorio `data/` en almacenamiento local con backup manual cifrado si contiene información sensible o licencias restringidas.
- No guardar API keys ni credenciales; no son necesarias en este perfil.
- No activar un proveedor externo sin revisar endpoint oficial, autorización, términos, rate limits y política de retención.
- La base usa SQLite y WAL; copiarla con la aplicación cerrada o usar la API de backup de SQLite para una copia consistente.
- Un backup no reemplaza la validación de datos ni del modelo.
