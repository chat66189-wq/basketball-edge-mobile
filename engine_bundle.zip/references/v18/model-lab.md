# v18 model laboratory

## Objective

Build evidence that a model improves probability estimates on a future-like sample, not that code executes or that a narrative sounds plausible. The lab works on one exact scope per run: competition, season, market, period, line/settlement rule and pregame/live state. Separate runs are required for moneyline, spread, total, team total, player prop, each competition, season and live state.

## Dataset contract

One row per unique event × selected side × market scope. Required columns:

- `event_id`, `event_time`, `forecast_created_at`, `data_cutoff_at`, `feature_snapshot_at` (ISO-8601 with timezone)
- `competition`, `season`, `market_scope`
- `outcome` (1 if the selected event occurred, 0 otherwise)
- `market_odds_selected`, `market_odds_opposite` (decimal odds captured by forecast time), `market_quote_captured_at` and `market_quote_operator_count` (default minimum: 3 independent operators)
- `source_bundle_sha256`, `independent_source_count` (at least 2), `official_source_present`
- Explicit numeric feature columns configured in `feature_columns`

Required temporal order: `data_cutoff_at <= feature_snapshot_at <= forecast_created_at < event_time`. Market scope/competition/season must be homogeneous within one CSV. Duplicate event IDs, bad source hashes, missing official source, fewer than two independent source groups, invalid time order, missing feature provenance or target/post-event feature names cause rejection.

The feature-column denylist detects common leakage names (outcome/result/winner/final/score/margin/postgame/settlement/closing odds/CLV/profit, etc.). This is not a complete causal audit: the user must ensure every feature was truly known at the declared snapshot time. The lab cannot independently authenticate source claims or licenses.

## Baseline and candidate models

Market baseline is the two-way no-vig probability `inverse odds selected / (inverse selected + inverse opposite)`. Do not substitute a one-sided price or a tipster's probability. Candidate list can include logistic regression, ExtraTrees, HistGradientBoosting, Random Forest, XGBoost, LightGBM and CatBoost. Optional packages must be installed separately. Use feature transformations inside sklearn pipelines so each fit estimates imputation/scaling only on its training fold.

The dev segment uses expanding-window walk-forward folds, never random shuffling. Candidate selection and inverse-Brier soft-voting weights are set using development OOS predictions only. Platt calibration is fit to those development OOS predictions. The final chronological holdout is not used for model choice, hyperparameter choice, ensemble weights or calibration.

## Promotion gates (defaults)

- At least 300 untouched holdout/OOS forecasts, 200 unique events, and five expanding walk-forward blocks.
- Brier score strictly better than the same-event no-vig market baseline.
- Log Loss no worse than the market baseline (configurable only before the run).
- ECE ≤0.03; calibration slope 0.80–1.20; absolute intercept ≤0.10.
- Bootstrap 95% lower bound for Brier Skill versus market >0.
- Maximum feature PSI ≤0.25 between development and holdout.
- At least 100 holdout predictions with calibrated `p_model` ≥0.80; the Wilson 95% lower bound of observed hit rate in that predeclared subset must also be ≥0.80.
- Exact scope match, temporal integrity and complete evidence metadata.

Failure of any gate returns `NOT_VALIDATED_HOLDOUT_GATES_FAILED`, `NO_MODEL_BEATS_MARKET_IN_WALK_FORWARD` or `INSUFFICIENT_DATA_FOR_STRICT_VALIDATION`. No pick may inherit validation from a failed card.

## Outputs

Model card JSON contains each candidate's walk-forward folds, champion and calibration details, untouched holdout metrics, confidence intervals for aggregate metrics, drift statistics and gate results. A locally trusted pickle is emitted only when all promotion gates pass. Never load pickle artifacts from an unknown party. The card's validation is historical evidence for that exact scope, not a guarantee of future accuracy or profitability. The `model-lab` CLI response also emits `model_card_sha256` for the exact JSON bytes written to disk. Preserve that hash with the card; do not edit/reformat the file afterward.

## Binding the model card to `pick-audit`

In the pick packet's `model_validation` object, set `model_card_path` to the saved card and `model_card_sha256` to the hash printed by the `model-lab` command. `pick-audit` opens that exact file, recomputes SHA-256, verifies the exact market scope and all model-card gates, and extracts the untouched-holdout sample size, Brier/Log Loss/ECE/calibration metrics and high-confidence subset statistics. Manually entered model metrics are overwritten by the values read from the card. Missing files, hash mismatches, scope mismatches or failed card gates block the pick. The high-confidence subset gate is independently rechecked at ≥100 holdout predictions with a Wilson lower hit-rate bound ≥0.80.

`predict-model` emits calibrated `p_model`. If bootstrap estimators were trained, it also emits a training-sample bootstrap interval. This is not a full individual-pick predictive interval: it omits at least future lineup uncertainty, provider error, model-family uncertainty, dependence/time-block effects, distribution shifts and market execution risk. Do not feed it directly into a strict pick gate as `p_model_lower95`.

## CLV and ROI

If present, `closing_odds_selected`, `closing_odds_opposite` and `closing_quote_captured_at` are evaluation-only; closing timestamp must be after forecast creation and before tip-off. They estimate movement in no-vig market probability from captured forecast-time price to closing price. They are forbidden as model features. `odds_taken`, `odds_taken_operator` and `odds_taken_captured_at` support a flat-stake historical ROI diagnostic and must refer to a fresh price available at forecast time. ROI is secondary; a high hit rate can still lose at poor prices.

## Retraining

No automatic retraining. Add new, settled, provenance-complete forecasts, freeze the training cutoff, reserve a new latest holdout, rerun all folds/gates and compare champion/challenger with paired event-level tests. A model must not promote itself using its own holdout. Retain historical model cards and model artifacts by version.
