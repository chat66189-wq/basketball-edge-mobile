# v18 scope isolation and retraining governance

## Exact-scope identity

The validation key is `competition × season × market_scope`; `market_scope` must encode market family, period, line/settlement rule and pregame/live. A model validated for NBA full-game moneyline cannot be treated as validated for NCAA, regional leagues, handicaps, totals, props, live, other seasons or another selection convention. Women's, youth and reserve competitions are distinct scopes.

## Data policy

Use source records only when their publication/availability time is no later than the feature snapshot. Every event row must retain event time, forecast creation time, data cutoff, feature snapshot time, source packet hash, source independence count and official-source indicator. If any feature was updated after the forecast time, drop it or block the row. Do not use final box scores, closing odds, settled outcomes, injury news published after forecast creation or post-game summaries as predictors.

## Champion/challenger lifecycle

1. Freeze a dataset snapshot and config (feature columns, scope, models, thresholds, seed).
2. Run expanding-window walk-forward folds on the development history.
3. Select challenger / ensemble only within development OOS results.
4. Calibrate on development OOS predictions only.
5. Evaluate once on the untouched latest holdout.
6. Promote only if every predeclared gate passes and the scope is exact.
7. Run prospective paper tracking after historical promotion; retain model version and prediction timestamp.
8. Monitor Brier, Log Loss, ECE, calibration, hit rate by probability bucket, CLV (where comparable), ROI, drift and data freshness.
9. Suspend the model when drift, calibration degradation, data failure or material roster/competition rule changes exceed limits.
10. Retrain with an immutable new version and a new holdout; never overwrite old cards or predictions.

## No automatic self-learning

Settlements do not silently modify model weights or thresholds. They enter the append-only ledger. Retraining is an explicit, reproducible operation. Corrections are appended with reason and provenance; the original forecast and settlement remain intact. Preserve rejected candidates to avoid survivorship bias.

## Decision separation

Model card validation is not a pick recommendation. A future event additionally requires new point-in-time data, availability confirmation, market support, exact operator price and settlement verification, research audit, red-team review, full uncertainty and the v17 individual gate. A combination then requires the v17 joint gate. `p_model` or a bootstrap training-sample interval must never be presented as guaranteed probability.
