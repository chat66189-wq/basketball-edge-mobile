# Riesgo y gobernanza

## Bloqueos

Bloquear si falta identidad inequívoca, horario, estado, line/market, definición, regla de liquidación, licencia/derecho de uso, fecha de captura, datos esenciales, o si hay look-ahead. Bloquear también si la fuente contradice una noticia crítica sin resolución o si el jugador ya no pertenece al equipo.

## Incertidumbres

Separar incertidumbre de muestreo, parámetros, especificación, datos, disponibilidad, minutos, roles, lesiones, matchup, correlaciones, proveedor y mercado. Un intervalo de Monte Carlo condicionado a parámetros no cubre todas estas fuentes.

## Principios de publicación

- No fabricar un porcentaje, una lesión, un titular, una cuota ni un resultado.
- No ocultar la muestra ni el estado exploratorio.
- No extrapolar calibración de NBA a FIBA, WNBA, NCAA o ligas nacionales.
- No atribuir capacidad live sin feed confiable.
- No elevar stake para recuperar pérdidas ni sugerir martingalas.
- No priorizar EV o cuota por encima de hit rate cuando el usuario pidió máximo hit rate; mostrar por separado valor y probabilidad.
- Nunca recomendar apuesta por obligación de completar un número de picks.

## Revisión final de pick

Antes de publicar, volver a consultar fuente oficial sobre lesión/disponibilidad y confirmar precio abierto, operador, mercado, período, línea y liquidación. Una recomendación técnica no ejecuta una apuesta y no constituye garantía de resultado.
