# Metodología de modelado v15

## 1. Integridad temporal

La hora de creación del pronóstico y la fecha de corte deben ser anteriores al inicio del evento. Las observaciones tienen que estar disponibles antes del corte. Un registro con solo `YYYY-MM-DD` carece de hora de publicación y, para seguridad, se considera disponible recién al día UTC siguiente. No usar correcciones de box score, noticias ni datos publicados después del partido en el pronóstico histórico.

## 2. Posesiones y Four Factors

La estimación básica de posesiones es:

`Poss = FGA - OREB + TOV + 0.44 × FTA`.

El factor 0.44 es una aproximación de posesiones consumidas por tiros libres; se debe documentar/validar el factor específico cuando el proveedor o la competición use otra definición.

- `eFG% = (FGM + 0.5 × 3PM) / FGA`
- `TOV% proxy = TOV / (FGA - OREB + TOV + 0.44 × FTA)`
- `ORB% = OREB / (OREB + Opponent DREB)`; requiere rebotes defensivos del rival.
- `FTr = FTA / FGA`
- `3PAr = 3PA / FGA`

Las tasas no definidas por denominador cero permanecen `null`, nunca cero.

## 3. Ritmo y PPP

Para cada equipo, el motor usa una media ponderada por recencia de posesiones, puntos anotados por posesión y puntos permitidos por posesión. Ponderación exponencial por semivida:

`w_i = exp(-ln(2) × edad_i / half_life_days)`.

El tamaño muestral efectivo se calcula con `(Σw)^2 / Σ(w²)`. Cada tasa se contrae hacia el prior de liga:

`rate_shrunk = (n_eff × rate_observed + k × league_prior) / (n_eff + k)`.

El valor `k` y la semivida son hiperparámetros, no verdades universales. Deben seleccionarse solo con entrenamiento/validación cronológica.

## 4. Splits local/visitante y ratings ajustados por rivales

Los ritmos y eficiencias de localía se estiman por separado y se contraen hacia el promedio completo del equipo para reducir ruido en splits pequeños. La proyección combina el split local del anfitrión con el split visitante del rival, y viceversa. Si falta el split, se usa la tasa general contraída. La semivida y el prior de split también deben validarse temporalmente.

Los ratings ajustados por rivales

`fit_opponent_adjusted_ratings` estima deltas de ataque y defensa mediante coordinate descent regularizado, usando `observed_PPP - league_PPP ≈ attack_team - defense_opponent`. La penalización ridge evita que muestras pequeñas generen deltas extremos. Requiere identificadores consistentes y registros de ambos lados de los enfrentamientos; si la red de equipos está desconectada o falta muestra, conservar el baseline y declarar el límite.

## 5. Proyección y simulación de marcador

El pace de partido parte del promedio del split local y del split visitante. El PPP de cada lado combina ataque propio, defensa rival y una ventaja de localía configurada. Si hay al menos ocho partidos point-in-time por equipo para el rating, mezcla el baseline split con ataque/defensa ajustados por rivales; la ponderación 50/50 es un punto de partida que debe calibrarse, no un peso universal. La simulación samplea un ritmo compartido para ambos equipos y residuales de eficiencia correlacionados. Ello genera escenarios conjuntos donde marcador, ganador, margen y total son derivados del mismo partido simulado.

Este proceso no es un motor de posesión-evento completo: no simula explícitamente cada tiro, lineup, falta, rebote, turnover ni tiempo muerto. Sus desviaciones iniciales son parámetros de baseline. Para considerarlo calibrado necesita comparación fuera de muestra de totales, márgenes y resultados.

## 6. Props de jugadores

El motor samplea primero si el jugador participa, luego minutos con distribución normal truncada [0, max_minutes], y tasas por minuto. Si se informa coeficiente de variación positivo, la tasa se samplea mediante Gamma. Cada estadística usa una muestra de minutos común, capturando parte de la dependencia de exposición.

Los conteos usan Poisson exacto por inversión/Knuth. Es una aproximación simple: no modela de forma explícita tiros de 2/3, tiros libres, uso, potenciales asistencias, oportunidades de rebote, rival, alineaciones, faltas, blowout ni sobredispersión de cada variable. No debe etiquetarse `VALIDATED` hasta superar pruebas específicas de jugador/mercado/competición. PRA se calcula desde las mismas filas simuladas, no sumando probabilidades marginales.

## 7. Mercado y liquidación

Se admite hoy: moneyline (home/away), spread (handicap aplicado al lado seleccionado), total, home total y away total. La línea entera puede generar push. El motor devuelve `p_win`, `p_push`, `p_loss`; EV por unidad:

`EV = p_win × (odds - 1) - p_loss`.

No inferir reglas de prórroga. Verificar para cada operador y mercado si OT cuenta. La simulación actual es marcada como `regulation_only`; no extender sus resultados a mercados con overtime sin modelar y simular el tramo extra.


## 8. Simulación conjunta partido + jugadores

`joint_simulation.py` simula en el mismo índice de escenario el pace, los PPP/marcadores de ambos equipos, la participación/minutos de cada jugador y sus conteos. El pace compartido crea una dependencia explícita entre el entorno del partido y las estadísticas de jugadores; la eficiencia del equipo ajusta parcialmente las tasas de puntos/asistencias según un factor de sensibilidad. No representa lineups, uso ni rotaciones completas y no captura todas las dependencias de props.

`build_joint_scenarios` convierte esos draws en eventos booleanos de patas para el optimizador. Actualmente exige líneas no enteras (por ejemplo, 15.5) para no manejar push incorrectamente. Los mercados de spread/totales/moneyline deben declarar `overtime_rule=excluded`; el modelo no añade prórroga. Si la casa liquida el mercado incluyendo OT, abstenerse con este simulador.
