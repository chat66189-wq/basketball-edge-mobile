# Optimizador de combinadas v15

## Entradas obligatorias

- Candidatas con ID único, event_id, mercado, selección, cuota, `quote_verified`, `data_ready`, `model_validated` y estado.
- Matriz de escenarios compartidos: cada fila contiene el resultado booleano de cada pata para una misma simulación/escenario.
- Cotizaciones conjuntas exactas para SGP (mismo evento) en clave `legA|legB|...`.
- Stress batches opcionales con los mismos IDs de pata.
- Banda de cuota, cantidad mínima/máxima de patas y límites de búsqueda.

## Selección

1. Excluir patas con cuota no verificada, datos no listos, modelo no validado o estado distinto de aprobado.
2. Enumerar combinaciones sin exceder `max_combinations`.
3. Calcular `p_joint` como fracción de escenarios completos donde todas las patas ganan.
4. Calcular Wilson 95% inferior para el error de muestreo Monte Carlo.
5. Si existen stress batches, usar como cota de selección el mínimo entre el lower bound central y los lower bounds de estrés.
6. Exigir precio conjunto exacto si hay más de una pata del mismo evento. No multiplicar precios de patas SGP.
7. Para distintos eventos, la multiplicación de cuotas solo está disponible con `assume_independent_cross_event=true`; el precio se marca como estimado y no verificado en el operador.
8. Ranking: límite inferior MC/estrés, probabilidad conjunta central, EV robusto, menos patas y cercanía a cuota objetivo.
9. Informar leave-one-out de cada pata.

## Límites

- Wilson no representa incertidumbre del modelo ni de datos.
- La matriz de escenarios tiene que representar dependencias reales; una matriz armada multiplicando Bernoullis independientes no soluciona correlaciones omitidas.
- `joint_prices` es un dato suministrado. Solo `verified_joint_price_keys` lo etiqueta como cotización exacta declarada verificada por el usuario; no hay verificación automática contra operador.
- Las reglas de push/void/half win/half loss deben simularse antes de usar el motor. Actualmente cada outcome de escenario es bool, así que el motor no liquida pushes/void de forma nativa. Si los hay, traducirlos a un módulo de liquidación probado o abstenerse.
- La cuota objetivo no justifica agregar selecciones frágiles.
