# Arquitectura v15.0

## Capas

1. `data_quality.py`: provenance, freshness, estado de licencia, hashes y control point-in-time.
2. `team_model.py`: validación de logs, ritmo, PPP, shrinkage, coordinate descent de ratings ajustados por rivales, fórmula de posesiones y Four Factors.
3. `player_model.py`: escenarios de disponibilidad, minutos y tasas por minuto; una misma trayectoria de minutos se comparte entre estadísticas.
4. `market_pricing.py`: liquidación probabilística por simulación para moneyline, spread, total y team totals.
5. `combo_optimizer.py`: búsqueda de combinadas sobre escenarios conjuntos, gates de elegibilidad, precio conjunto SGP, escenarios de estrés y leave-one-out.
6. `calibration.py`, `backtesting.py` y `model_governance.py`: Brier, Log Loss, ECE, Wilson, evaluación cronológica, paired champion/challenger bootstrap y monitor de degradación.
7. `ledger.py`: persistencia SQLite, registros append-only para fuentes, cuotas, pronósticos y liquidaciones.
8. `prediction_gate.py`: gate temporal, de datos, modelo, calibración, cuota y reglas.
9. `provider_contracts.py`: contratos/estado de adaptadores; no hace scraping ni inventa API keys.
10. `cli.py`: interfaz reproducible de ejecución.

## Aislamiento

El código histórico v14 se preserva en `legacy_archive/`. No se importa desde v15. Esto evita que dependencias de fútbol, tests de goles/corners u otros módulos incompatibles entren silenciosamente en el cálculo de básquet.

## Reproducibilidad

Cada simulación acepta semilla. Guardar con cada predicción: versión, semilla, corte de datos, fuente, timestamp de creación, parámetros, mercado exacto y reglas. Cambiar cualquier parámetro material obliga a versionar el modelo.

## Estado del modelo

El baseline de v15 es funcional pero no está entrenado con la base histórica del usuario y no está validado por todas las competiciones/mercados. El estado inicial es `EXPLORATORY_NOT_VALIDATED`. La versión del paquete no es un certificado de precisión.
