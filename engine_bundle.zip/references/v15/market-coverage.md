# Catálogo de mercados de básquet y cobertura real

El catálogo sirve para clasificar mercados observados; no afirma que un operador los ofrezca ni que todos estén modelados. El motor de pricing activo solo aprueba los mercados indicados como **implementado baseline**.

| Familia | Ejemplos | Estado v15 |
|---|---|---|
| Ganador partido | Moneyline local/visitante, incluye/excluye OT | Implementado baseline; confirmar regla OT |
| Hándicap partido | Spread principal y alternativo, handicap europeo | Spread numérico implementado baseline; reglas exactas por casa |
| Total partido | Over/Under, alternativos | Implementado baseline |
| Total por equipo | Total local/visitante, alternativos | Implementado baseline |
| Puntos por equipo | Puntos totales derivados de simulación | Implementado como team total |
| Primera mitad | Ganador, spread, total, team total | No evaluable: falta simulador/modelo por mitad validado |
| Segunda mitad | Ganador, spread, total, team total | No evaluable |
| Cuartos | Ganador, spread, total, total por equipo | No evaluable |
| Intervalos | Ganador al descanso/final, margen por segmento | No evaluable |
| Estadísticas de equipo | Rebotes, asistencias, pérdidas, robos, tapones, faltas, triples, tiros libres | No evaluable en motor actual |
| Props puntos jugador | Puntos over/under | Simulador de tasa/minutos experimental; no validado |
| Props rebotes jugador | Rebotes over/under | Simulador de tasa/minutos experimental; no validado |
| Props asistencias jugador | Asistencias over/under | Simulador de tasa/minutos experimental; no validado |
| Props triples | Triples anotados/intentos | No evaluable con el esquema actual; añadir modelo de intentos y conversión |
| Props defensivos | Robos, tapones | No evaluable en motor actual |
| Combos jugador | P+R, P+A, R+A, PRA, DD, TD | Draws compartidos disponibles a nivel prototipo; no validado |
| Duelos de jugadores | Más puntos/rebotes/asistencias | No evaluable sin modelos de ambos y reglas exactas |
| Secuencias | Primero en llegar a N, primera/última canasta, próxima anotación | No evaluable sin play-by-play y modelo de estado |
| Carreras y margen exacto | Race to N, bandas de margen | No evaluable |
| Live | Moneyline, spread, total, props, siguiente evento | No hay feed ni modelo live validado; no publicar |
| Futuros | Campeonato, clasificación, premios, récords | No evaluable: necesita modelo de temporada y cuotas futuras |
| Especiales | Cuarto de mayor puntuación, ambos superan umbral | No evaluable sin distribución conjunta por segmento |

## Regla de apertura de cobertura

Para habilitar cualquier familia nueva deben existir: definición de mercado y liquidación, proveedor/datos suficientes, modelo específico, simulación de dependencias si corresponde, validación temporal fuera de muestra, calibración, pruebas de software y gate de publicación. No se habilita por agregar solo el nombre al catálogo.
