# Validación y calibración

## Métricas

- **Brier:** media de `(p-y)^2`, menor es mejor.
- **Log Loss:** castiga probabilidades extremas incorrectas.
- **ECE:** diferencia ponderada entre probabilidad media y frecuencia observada por bins; informar los tamaños de bins.
- **Wilson:** intervalo de frecuencia con tamaño de muestra explícito; es apropiado para proporciones binarias, no una garantía predictiva.
- **CLV:** comparar precio tomado con precio de cierre comparable, incluyendo operador/mercado/linea/reglas.
- **ROI/drawdown:** liquidar todas las apuestas con las reglas reales; no excluir pushes, voids ni pérdidas.
- **CRPS:** incorporar cuando se evalúen distribuciones completas de puntos/márgenes, no solo probabilidades binarias.

## Diseño de pruebas

1. Fijar por anticipado el universo de mercados, el horizonte, reglas y benchmarks.
2. Construir features point-in-time, no features corregidas/publicadas después del evento.
3. Crear ventanas de entrenamiento, calibración y test cronológico intacto.
4. Usar expanding/rolling window y comparar en el mismo conjunto contra baseline simple y mercado sin margen.
5. Evaluar por competición × temporada × mercado × línea/bucket × prepartido/live.
6. Calcular intervalos por bootstrap agrupado por partido/jornada para no tratar patas correlacionadas como observaciones independientes.
7. Ajustar parámetros solo en el pasado de cada split.
8. No promover challenger por una mejora mínima aislada; exigir mejora reproducible, calibración y muestras suficientes.
9. Mantener ledger completo de pronósticos, incluidos descartes.
10. Ejecutar paper trading prospectivo antes de usar stake real.

## Estado inicial de v15

El paquete trae implementación funcional y tests unitarios, pero no trae un dataset real de la competición, resultados históricos licenciados, closing odds ni validación prospectiva propia. Por tanto, todas las probabilidades del baseline deben quedar exploratorias hasta pasar el proceso anterior.


## Gobierno de modelos

`model_governance.py` compara champion y challenger sobre la misma lista de pronósticos y resultados, en un único scope exacto. Hace bootstrap pareado agrupado por `event_id`, no por patas independientes. La elegibilidad exige tamaño mínimo, límite superior del intervalo bootstrap de delta Brier menor que cero, no inferioridad de Log Loss y ECE dentro de tolerancia. La salida `PROMOTION_ELIGIBLE` no cambia automáticamente el modelo en producción: requiere un holdout final intacto y paper-trading. `detect_degradation` es un monitor de umbrales, no un detector causal de drift.
