# Datos, fuentes y conectores

## Jerarquía de fuentes

1. Fuente oficial de la competición/equipo: schedule, boxscore, play-by-play, injury report, acta, roster y reglas.
2. Proveedor estadístico autorizado o licenciado, con definiciones, cobertura y timestamps documentados.
3. Proveedor secundario de referencia para contraste, nunca sustituye un dato crítico no confirmado.
4. Dato manual suministrado por el usuario: conservar captura, timestamp, operador/fuente y estado de verificación.

Ejemplos de portales oficiales que pueden investigarse según la competición: NBA Stats/NBA.com, WNBA, FIBA Game Center/LiveStats, NCAA y Euroleague Basketball. La existencia de un portal no demuestra que tenga API pública, acceso automatizable ni permiso de extracción. Revisar términos/licencia y límites vigentes antes de escribir un adaptador.

## Contrato de proveedor

Implementar un cliente que cumpla `BasketballProvider` con `get_schedule`, `get_boxscore`, `get_player_status` y `get_odds`. Cada respuesta normalizada debe incluir:

- `provider_id`, `source_url` o endpoint oficial documentado;
- `captured_at`, `retrieved_at`, `available_at` y timezone;
- competición, temporada, event_id y player_id canónicos;
- unidad/definición del campo;
- licencia/permiso de uso y restricciones;
- versión/schema y hash del payload original.

No raspar páginas que prohíban automatización. No evadir login, paywalls, captchas, cuotas ni controles. No inventar datos cuando un proveedor no responda.

## Credenciales

Las claves se configuran fuera del ZIP, mediante variables de entorno o gestor de secretos del usuario. No escribirlas en código, ZIP, logs, ejemplos o ledger. El paquete inicial no realiza peticiones de red; los conectores oficiales se implementan por separado y su cobertura se prueba.

## Esquema de datos mínimo

- Partido: event ID, competición, temporada, sede, local/visitante, fecha/hora, estado, duración y reglas.
- Equipo-partido: puntos, FGA/FGM/3PA/3PM/FTA/FTM, OREB/DREB, turnovers, posesiones, faltas, robos y tapones, con definitions.
- Jugador-partido: player ID, equipo, DNP/activo, titularidad, minutos, puntos, rebotes, asistencias, triples, tiros, pérdidas, faltas, robos, tapones.
- Contexto: injury/status, restricciones, roster, lineup, descanso, viaje y coach changes con available_at.
- Mercado: operador, event ID, período, línea, lado, cuota decimal, estado, captura, vencimiento y reglas.

No combinar temporadas, categorías, reglas, definiciones ni fuentes sin armonización documentada.
