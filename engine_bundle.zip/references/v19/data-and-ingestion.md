# v19 — Data ingestion, provenance and point-in-time features

## Provider connection policy

`JsonProviderClient` is a generic configured HTTP/JSON connector, not a pre-integrated provider catalog. It does not invent provider URLs or claim that NBA, NCAA, FIBA, WNBA, national leagues or an odds operator are connected. To use a provider, the operator must configure its documented official base URL, paths, allowed hosts, authentication environment variables, rate limits/TTL and license state. `license_status` must be `AUTHORIZED`, `OPEN_LICENSE` or `MANUAL_USER_SUPPLIED`, and `terms_confirmed` must be explicitly true. `UNKNOWN` or unconfirmed terms block requests.

Only HTTPS is accepted by default; loopback HTTP is allowed solely for local testing. Hosts are allowlisted, credentials are read from environment variables, raw API keys are never logged, timeouts and response-size caps apply, transient 429/5xx/transport errors are retried with bounded delay and per-client minimum request spacing, and responses are cached in SQLite with capture time and SHA-256. Every network response is also stored in an append-only `source_capture` table; updates/deletes are blocked by SQLite triggers. Sensitive query parameters are redacted from the stored provenance URL. No provider-specific pagination is assumed; if an API paginates, implement and test its documented pagination contract in a provider adapter rather than treating the first page as complete.

The connector returns a provenance envelope: provider ID, resource, request/retrieval times, status code, exact URL, payload, cache flag, license state and canonical payload hash. It cannot independently prove that the provider payload is accurate or that the declared license is valid. Preserve the provider contract and terms outside the skill.

## Feature snapshots

`feature-snapshot` creates one feature vector for one future event. It filters rows by both event time and availability time. A date-only historical record is conservatively treated as published on the next UTC day. The active feature builder includes rolling 5/10/20-game pace and PPP, net PPP, optional Four Factors, home/away descriptive splits, rest, back-to-back, 7/14-day schedule density and optional verified venue-distance estimates.

Home/away splits with small counts are not standalone evidence. Missing values remain null; never fill unknown with zero. These generated features must be captured in a point-in-time feature snapshot and used to create the model-lab training rows. All transformations, opponent adjustments, normalization and imputation must be fitted within each training fold, not across the full dataset.

## Data requirements

The source should retain: provider/source ID, license status, endpoint or document ID, fetched_at, published_at/available_at, event identity, competition/season/sex/level, team/player IDs, timezone-aware tipoff, venue, schedule status, box-score definitions, possession estimate method and correction history. Normalize team/player identifiers across aliases before modeling. Keep raw payloads immutable; normalized records should reference raw hashes.
