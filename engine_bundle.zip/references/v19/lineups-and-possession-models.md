# v19 — Lineup and possession-based scenario engines

## Possession simulator

`possession-sim` simulates a supplied expected pace and offensive efficiencies with shared pace, correlated efficiency residuals, Student-t parameter perturbations and multiple parameter batches. Supported event types are full-game home/away moneyline, home/away spread, game total over/under and home/away team total over/under. Integer, half-point and quarter-point lines are supported. Quarter-point lines are split into two equal half-stakes and reported as `HALF_WIN`, `HALF_LOSS` or `HALF_WIN_LOSS_SPLIT` when appropriate. Pushes are a separate category. `scenario_probability_mean` is the unconditional probability of a full win, not a conditional win rate after discarding pushes; outcome categories sum to 1.

The user must declare overtime handling as `INCLUDED` or `REGULATION_ONLY`. When included, the simulator draws repeated five-minute overtime segments until the tie is broken; this is still an exploratory approximation and must be backtested for the exact competition/market. Do not resolve tied games with a coin flip.

The reported Wilson interval is Monte Carlo sampling error only, computed against all executed simulations; it is not a predictive interval. The p10/median/p90 across parameter batches is a sensitivity range under supplied assumptions, not a calibrated confidence interval. Neither can pass `pick-audit` as a full predictive lower bound. The simulator remains `EXPLORATORY_NOT_VALIDATED` until an exact scope has independent historical validation.

## Availability and player impact

`lineup-scenarios` requires a complete rotation, availability status, expected minutes distribution, point-in-time adjusted impact metric (RAPM, EPM, DARKO or a validated lineup model), replacement impact, sample size and capture timestamp. Raw plus/minus is rejected. QUESTIONABLE/DOUBTFUL requires an explicit availability probability. Unknown availability blocks.

Impact is shrunk toward replacement according to sample minutes and then used in minute/availability scenarios. Player-minutes are reallocated to exactly five players on court while respecting the per-player game-minute cap; scenarios with fewer than five available rotation players are discarded. The output is sensitivity-only: on/off impact metrics can be noisy, overlapping, non-causal and double-count correlated teammates. Never directly add the reported impact to team PPP or win probability. Train an exact-scope mapping using historical lineup snapshots and evaluate it walk-forward before use as a predictive model feature.

## Rotation and status validation

Capture official injury report/status timestamps, projected starting lineup, source identity, player ID/team ID, expected minutes, minute restrictions, return-from-injury status, depth-chart replacement, role and usage/assist/rebound opportunity changes. A material status update after forecast creation invalidates the earlier prediction and requires a new immutable forecast rather than overwriting it.
