# v19 — Market intelligence and continuous monitoring

## Exact scope registry

`market-scope` builds a canonical scope token from competition, season, sex/category, level, market family, period, settlement/line rule, selected side, exact numeric line and pregame/live status. Player props additionally require stat and a player population/player-scope label. Player props must include the exact stat. Model cards and historical rows must use this exact token. A change in competition, season, sex/age class, period, market family, line convention or live state requires a distinct model scope.

The generic v18 model laboratory can train a separate binary classifier for a fixed two-way event definition, e.g. one moneyline scope or a specific total line rule. It does not make every market family operational automatically; the feature set, settlement labels and historical sample must be correct for each scope. Push/void/half-win settlement requires explicit target construction; do not coerce pushes to wins or losses.

## Two-way market audit

`market-audit` validates fresh, exact-event/exact-scope operator quotes and strips each two-way quote's overround. It reports median no-vig consensus, range, dispersion, best selected price, average overround and opening-to-current movement when a separate opening snapshot is supplied. It requires unique operators and freshness; where current and opening quotes are both present for an operator, the opening capture must precede that operator's current capture. This helper does not independently establish bookmaker authenticity, operator independence, sharpness, or exact user-site availability.

For three-way markets, Asian lines with push/half-settlement, correlated same-game markets or player props, use a settlement-specific market model and pricing implementation. Do not apply the two-way no-vig function blindly.

## Monitoring

`monitor-history` consumes settled, immutable forecast exports, retaining ACCEPTED, REJECTED, CONDITIONAL and NO_PICK decisions. It reports all-candidate performance and accepted-only performance separately, by competition × season × exact scope × model version. Metrics include hit rate and Wilson interval, Brier, Log Loss, ECE/reliability buckets, market baselines, high-confidence subset diagnostics, flat-stake ROI when an odds-taken quote has a timestamp, and mean CLV when both taken and closing no-vig probabilities have timestamps that fall before and after forecast creation respectively. It can return `SUSPEND_AND_REVIEW` when performance degrades or remains worse than market.

Monitoring is not automatic learning. It does not change weights, thresholds or model cards. Retraining is a separate controlled run on new, settled, point-in-time data with a new untouched holdout. Keep original predictions, model artifacts, model cards, source hashes and outcomes immutable. Never tune on the final holdout or hide rejected candidates.

CLV and ROI are useful secondary diagnostics when the taken price and closing price are exact, timestamped and settlement-comparable. Hit rate alone is not a measure of value or profitability.
