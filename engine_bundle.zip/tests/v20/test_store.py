import csv, tempfile, unittest
from pathlib import Path
from scripts.edge_v20.store import connect, import_csv, log_prediction, audit
class StoreTests(unittest.TestCase):
 def setUp(self): self.tmp=tempfile.TemporaryDirectory(); self.db=connect(Path(self.tmp.name)/'test.sqlite3')
 def tearDown(self): self.db.close(); self.tmp.cleanup()
 def csvfile(self,name,header,rows):
  p=Path(self.tmp.name)/name
  with p.open('w',newline='',encoding='utf8') as f: w=csv.writer(f); w.writerow(header); w.writerows(rows)
  return p
 def games(self):
  p=self.csvfile('games.csv',['event_id','competition','season','event_time','home_team','away_team','status'],[['g1','NBA','2026','2026-01-02T19:00:00Z','A','B','SCHEDULED']]); import_csv(self.db,'games',str(p))
 def test_empty_database_audit_and_offline(self): self.assertFalse(audit(self.db)['network_enabled'])
 def test_manual_games_import(self): self.games(); self.assertEqual(audit(self.db)['counts']['games'],1)
 def test_bad_timestamp_rejected(self):
  p=self.csvfile('g.csv',['event_id','competition','season','event_time','home_team','away_team','status'],[['g1','NBA','2026','2026-01-01 19:00','A','B','FINAL']])
  with self.assertRaisesRegex(ValueError,'timezone_required'): import_csv(self.db,'games',str(p))
 def test_lookahead_rejected(self):
  self.games(); x={'prediction_id':'p1','event_id':'g1','scope_token':'NBA|2026|ML','market':'ML','selection':'A','validation_status':'EXPLORATORY_NOT_VALIDATED','decision':'REJECTED','created_at':'2026-01-01T18:00:00Z','feature_snapshot_at':'2026-01-01T18:01:00Z'}
  with self.assertRaisesRegex(ValueError,'lookahead_blocked'): log_prediction(self.db,x)
 def test_prediction_append_only(self):
  self.games(); x={'prediction_id':'p1','event_id':'g1','scope_token':'NBA|2026|ML','market':'ML','selection':'A','validation_status':'EXPLORATORY_NOT_VALIDATED','decision':'REJECTED','created_at':'2026-01-01T18:00:00Z','feature_snapshot_at':'2026-01-01T17:59:00Z'}; log_prediction(self.db,x)
  with self.assertRaisesRegex(Exception,'append_only_predictions'): self.db.execute("UPDATE predictions SET decision='ACCEPTED' WHERE prediction_id='p1'")
 def test_odds_validation(self):
  self.games(); q=self.csvfile('o.csv',['event_id','market_scope','operator','selection','decimal_odds','captured_at'],[['g1','ML','manual','A','1.0','2026-01-01T17:00:00Z']])
  with self.assertRaisesRegex(ValueError,'decimal_odds_must_be_gt_1'): import_csv(self.db,'odds',str(q))
if __name__=='__main__': unittest.main()
