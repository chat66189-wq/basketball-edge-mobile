import csv
import hashlib
import importlib.util
import json
import math
import random
import sys
import tempfile
import unittest
import warnings
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "scripts"))

from edge_v15.model_lab import load_dataset, no_vig_probability, train_model_lab, predict_from_bundle, _make_model


class ModelLabTests(unittest.TestCase):
    def _make_dataset(self, path: Path, n=1000):
        rng = random.Random(77)
        fields = ["event_id", "event_time", "forecast_created_at", "data_cutoff_at", "feature_snapshot_at",
                  "competition", "season", "market_scope", "outcome", "market_odds_selected",
                  "market_odds_opposite", "market_quote_captured_at", "market_quote_operator_count", "source_bundle_sha256", "independent_source_count",
                  "official_source_present", "feature_net_rating", "feature_rest_days", "closing_odds_selected",
                  "closing_odds_opposite", "closing_quote_captured_at", "odds_taken", "odds_taken_operator", "odds_taken_captured_at"]
        with open(path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fields)
            writer.writeheader()
            for i in range(n):
                latent = rng.gauss(0, 1)
                p = 1 / (1 + math.exp(-2.4 * latent))
                y = int(rng.random() < p)
                day = i + 1
                event = f"2025-01-{1 + (i % 28):02d}T20:00:00+00:00" if i < 28 else f"2025-{1 + (i // 28) // 12:02d}-{1 + (i // 28) % 28:02d}T20:00:00+00:00"
                # Monotone ISO event time is required for chronological partition.
                from datetime import datetime, timedelta, timezone
                ev = datetime(2024, 1, 1, tzinfo=timezone.utc) + timedelta(hours=i * 6)
                created = ev - timedelta(minutes=30)
                cutoff = ev - timedelta(hours=1)
                row = {
                    "event_id": f"E{i}", "event_time": ev.isoformat(),
                    "forecast_created_at": created.isoformat(), "data_cutoff_at": cutoff.isoformat(),
                    "feature_snapshot_at": (ev - timedelta(minutes=45)).isoformat(),
                    "competition": "Test League", "season": "2024-25",
                    "market_scope": "Test League|2024-25|moneyline|full_game|pregame",
                    "outcome": y, "market_odds_selected": 2.0, "market_odds_opposite": 2.0,
                    "market_quote_captured_at": (created - timedelta(minutes=1)).isoformat(), "market_quote_operator_count": 3,
                    "source_bundle_sha256": "a" * 64, "independent_source_count": 2,
                    "official_source_present": "true", "feature_net_rating": latent,
                    "feature_rest_days": rng.choice([0, 1, 2, 3]),
                    "closing_odds_selected": 1.9 if y else 2.1, "closing_odds_opposite": 2.1 if y else 1.9,
                    "closing_quote_captured_at": (ev - timedelta(minutes=1)).isoformat(),
                    "odds_taken": 2.0, "odds_taken_operator": "Test Book", "odds_taken_captured_at": (created - timedelta(minutes=1)).isoformat(),
                }
                writer.writerow(row)
        return fields

    def test_market_no_vig(self):
        self.assertAlmostEqual(no_vig_probability(2.0, 2.0), 0.5)
        self.assertAlmostEqual(no_vig_probability(1.5, 3.0), 2 / 3)

    def test_forbidden_leakage_feature_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            csv_path = Path(d) / "history.csv"
            self._make_dataset(csv_path, 30)
            with self.assertRaisesRegex(ValueError, "forbidden_post_event"):
                load_dataset(csv_path, {"feature_columns": ["feature_net_rating", "final_score"]})

    def test_requires_point_in_time_and_source_provenance(self):
        with tempfile.TemporaryDirectory() as d:
            csv_path = Path(d) / "history.csv"
            self._make_dataset(csv_path, 30)
            with csv_path.open(encoding="utf-8") as source:
                rows = list(csv.DictReader(source))
            rows[0]["feature_snapshot_at"] = rows[0]["event_time"]
            with csv_path.open("w", newline="", encoding="utf-8") as f:
                writer = csv.DictWriter(f, fieldnames=rows[0].keys()); writer.writeheader(); writer.writerows(rows)
            with self.assertRaisesRegex(ValueError, "point_in_time_order"):
                load_dataset(csv_path, {"feature_columns": ["feature_net_rating"]})

    def test_stale_market_quote_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            csv_path = Path(d) / "history.csv"
            self._make_dataset(csv_path, 30)
            with csv_path.open(encoding="utf-8") as source:
                rows = list(csv.DictReader(source))
            rows[0]["market_quote_captured_at"] = "2023-12-31T00:00:00+00:00"
            with csv_path.open("w", newline="", encoding="utf-8") as f:
                writer = csv.DictWriter(f, fieldnames=rows[0].keys()); writer.writeheader(); writer.writerows(rows)
            with self.assertRaisesRegex(ValueError, "market_quote_not_fresh"):
                load_dataset(csv_path, {"feature_columns": ["feature_net_rating"]})

    def test_market_baseline_requires_multiple_operators(self):
        with tempfile.TemporaryDirectory() as d:
            csv_path = Path(d) / "history.csv"
            self._make_dataset(csv_path, 30)
            with csv_path.open(encoding="utf-8") as source:
                rows = list(csv.DictReader(source))
            rows[0]["market_quote_operator_count"] = "1"
            with csv_path.open("w", newline="", encoding="utf-8") as f:
                writer = csv.DictWriter(f, fieldnames=rows[0].keys()); writer.writeheader(); writer.writerows(rows)
            with self.assertRaisesRegex(ValueError, "too_few_independent_operators"):
                load_dataset(csv_path, {"feature_columns": ["feature_net_rating"]})

    def test_installed_model_challengers_fit_and_predict(self):
        rng = random.Random(140)
        X = [[rng.gauss(0, 1), rng.random(), (None if i % 19 == 0 else rng.randint(0, 3))] for i in range(160)]
        y = [int(row[0] + 0.35 * row[1] > 0) for row in X]
        packages = {"xgboost": "xgboost", "lightgbm": "lightgbm", "catboost": "catboost"}
        names = ["logistic", "extra_trees", "hist_gradient_boosting", "random_forest"]
        names.extend(name for name, package in packages.items() if importlib.util.find_spec(package) is not None)
        for index, name in enumerate(names):
            with self.subTest(model=name):
                model = _make_model(name, 400 + index)
                with warnings.catch_warnings():
                    warnings.filterwarnings("ignore", message="X does not have valid feature names")
                    model.fit(X, y)
                    predictions = model.predict_proba(X[:5])
                self.assertEqual(len(predictions), 5)
                for row in predictions:
                    self.assertTrue(0.0 <= float(row[1]) <= 1.0)

    def test_model_lab_produces_holdout_report_or_abstains_cleanly(self):
        try:
            import sklearn  # noqa
        except Exception:
            self.skipTest("scikit-learn optional dependency not installed")
        with tempfile.TemporaryDirectory() as d:
            csv_path = Path(d) / "history.csv"
            card_path = Path(d) / "card.json"
            self._make_dataset(csv_path, 1000)
            config = {
                "competition": "Test League", "season": "2024-25",
                "market_scope": "Test League|2024-25|moneyline|full_game|pregame",
                "feature_columns": ["feature_net_rating", "feature_rest_days"],
                "models": ["logistic"], "holdout_fraction": 0.20, "min_holdout_rows": 100,
                "min_oos_predictions": 100, "min_unique_test_events": 100,
                "walk_forward_splits": 5, "min_walk_forward_splits": 5,
                "min_calibration_rows": 100, "bootstrap_metric_replicates": 100,
                "bootstrap_model_replicates": 2, "max_ece": 1.0,
                "calibration_slope_min": 0.0, "calibration_slope_max": 5.0,
                "max_abs_calibration_intercept": 5.0, "max_feature_psi": 5.0,
                "min_high_confidence_rows": 50, "min_high_confidence_hit_rate_lower95": 0.70,
            }
            report = train_model_lab(csv_path, config, card_path)
            self.assertIn(report["status"], {
                "VALIDATED_ON_UNTOUCHED_HOLDOUT_FOR_THIS_EXACT_SCOPE",
                "NOT_VALIDATED_HOLDOUT_GATES_FAILED", "NO_MODEL_BEATS_MARKET_IN_WALK_FORWARD",
            })
            self.assertTrue(card_path.exists())
            self.assertEqual(report["model_card_sha256"], hashlib.sha256(card_path.read_bytes()).hexdigest())
            if report["status"] == "VALIDATED_ON_UNTOUCHED_HOLDOUT_FOR_THIS_EXACT_SCOPE":
                artifact = Path(report["model_artifact"])
                self.assertTrue(artifact.exists())
                pred_path = Path(d) / "future.csv"
                with pred_path.open("w", newline="", encoding="utf-8") as f:
                    writer = csv.DictWriter(f, fieldnames=["event_id", "event_time", "forecast_created_at", "data_cutoff_at",
                                                           "feature_snapshot_at", "competition", "season", "market_scope",
                                                           "feature_net_rating", "feature_rest_days"])
                    writer.writeheader()
                    from datetime import datetime, timedelta, timezone
                    ev = datetime(2028, 1, 1, tzinfo=timezone.utc)
                    writer.writerow({"event_id": "FUTURE1", "event_time": ev.isoformat(),
                                     "forecast_created_at": (ev-timedelta(minutes=30)).isoformat(),
                                     "data_cutoff_at": (ev-timedelta(hours=1)).isoformat(),
                                     "feature_snapshot_at": (ev-timedelta(minutes=45)).isoformat(),
                                     "competition": "Test League", "season": "2024-25",
                                     "market_scope": "Test League|2024-25|moneyline|full_game|pregame",
                                     "feature_net_rating": 0.7, "feature_rest_days": 2})
                predictions = predict_from_bundle(artifact, pred_path)
                self.assertEqual(predictions["status"], "MODEL_INFERENCE_ONLY_NOT_PICK_APPROVAL")
                self.assertIn("p_model", predictions["predictions"][0])


if __name__ == "__main__":
    unittest.main()
