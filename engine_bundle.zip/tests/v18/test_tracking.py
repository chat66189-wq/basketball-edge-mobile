import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "scripts"))
from edge_v15.ledger import ForecastLedger


class TrackingTests(unittest.TestCase):
    def test_candidate_decisions_are_append_only_and_counted(self):
        with tempfile.TemporaryDirectory() as d:
            ledger = ForecastLedger(Path(d) / "ledger.sqlite")
            ledger.add_candidate_decision(
                decision_id="D1", event_id="E1", event_at="2026-12-01T20:00:00+00:00",
                decision_at="2026-12-01T18:00:00+00:00", competition="League", season="2026",
                market_scope="League|2026|moneyline|full_game|pregame", candidate_status="REJECTED",
                model_version="18.0.0", evidence_sha256="b"*64, reason_codes=["edge_not_proven"],
                payload={"note": "candidate rejected"}, probability=0.62, lower_probability=0.51, decimal_odds=1.8)
            self.assertEqual(ledger.counts()["candidate_decision"], 1)
            with ledger.connect() as db:
                with self.assertRaises(sqlite3.IntegrityError):
                    db.execute("UPDATE candidate_decision SET candidate_status='ACCEPTED' WHERE decision_id='D1'")
                with self.assertRaises(sqlite3.IntegrityError):
                    db.execute("DELETE FROM candidate_decision WHERE decision_id='D1'")

    def test_rejected_candidate_outcome_is_retained_and_measured(self):
        with tempfile.TemporaryDirectory() as d:
            ledger = ForecastLedger(Path(d) / "ledger.sqlite")
            ledger.add_candidate_decision(
                decision_id="D2", event_id="E2", event_at="2026-12-02T20:00:00+00:00",
                decision_at="2026-12-02T18:00:00+00:00", competition="League", season="2026",
                market_scope="League|2026|moneyline|full_game|pregame", candidate_status="REJECTED",
                model_version="18.0.0", evidence_sha256="c"*64, reason_codes=["model_disagreed_with_market"],
                payload={"candidate": "kept for hindsight audit"}, probability=0.65)
            ledger.settle_candidate(decision_id="D2", settled_at="2026-12-03T00:00:00+00:00",
                                    outcome=0, settlement_status="SETTLED", result={"source": "official"})
            report = ledger.performance_report()
            self.assertEqual(report["settled_candidate_performance"][0]["candidate_status"], "REJECTED")
            self.assertEqual(report["settled_candidate_performance"][0]["hit_rate"], 0.0)

    def test_model_evaluation_log_and_report(self):
        with tempfile.TemporaryDirectory() as d:
            ledger = ForecastLedger(Path(d) / "ledger.sqlite")
            ledger.add_model_evaluation(evaluation_id="M1", evaluated_at="2026-12-01T12:00:00+00:00",
                                        model_version="18.0.0", competition="League", season="2026",
                                        market_scope="League|2026|moneyline|full_game|pregame",
                                        status="NOT_VALIDATED", sample_size=300, metrics={"brier": 0.20})
            self.assertEqual(ledger.counts()["model_evaluation"], 1)
            self.assertIn("candidate_decisions", ledger.performance_report())


if __name__ == "__main__":
    unittest.main()
