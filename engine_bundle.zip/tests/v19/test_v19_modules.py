import json
import os
import tempfile
import threading
import unittest
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from scripts.edge_v19.features import build_feature_snapshot
from scripts.edge_v19.ingestion import JsonProviderClient
from scripts.edge_v19.lineup_scenarios import simulate_lineup_scenarios
from scripts.edge_v19.market_intelligence import audit_market_quotes
from scripts.edge_v19.market_scope import build_market_scope
from scripts.edge_v19.performance_monitor import audit_forecast_history
from scripts.edge_v19.possession_simulator import simulate_market_scenarios
from scripts.edge_v19.settlement import settle_market


class Handler(BaseHTTPRequestHandler):
    hits = 0
    def do_GET(self):
        Handler.hits += 1
        payload = json.dumps({"games": [{"id": "g1"}]}).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers(); self.wfile.write(payload)
    def log_message(self, *args):
        pass


class V19Tests(unittest.TestCase):
    def test_market_scope_is_exact_and_requires_prop_type(self):
        base = {"competition":"NCAA","season":"2026-27","sex_category":"M","level":"UNIVERSITY",
                "market_family":"MONEYLINE","period":"FULL_GAME","line_rule":"includes_ot","game_state":"PREMATCH","selection":"HOME"}
        one = build_market_scope(base)
        two = build_market_scope({**base,"sex_category":"F"})
        self.assertNotEqual(one["market_scope"], two["market_scope"])
        with self.assertRaises(ValueError):
            build_market_scope({**base,"market_family":"PLAYER_PROP"})
        prop = {**base,"market_family":"PLAYER_PROP","selection":"OVER","line_value":18.5,
                "prop_stat":"points","player_scope":"POOLED_GUARDS"}
        self.assertIn("POOLED_GUARDS", build_market_scope(prop)["market_scope"])
        spread = {**base,"market_family":"SPREAD","selection":"HOME","line_value":5.5}
        self.assertNotEqual(build_market_scope(spread)["market_scope"],
                            build_market_scope({**spread,"line_value":4.5})["market_scope"])
        with self.assertRaises(ValueError):
            build_market_scope({**spread,"line_value":None})

    def test_feature_snapshot_point_in_time_and_rolling(self):
        hist=[]
        for team, opp, home in (("H","A",True),("A","H",False)):
            for i in range(12):
                day=f"2026-10-{i+1:02d}"
                hist.append({"team":team,"opponent":opp,"game_date":day,"available_at":f"2026-10-{i+2:02d}T12:00:00Z",
                             "points_for":80+i,"points_against":75,"possessions":70+i*.1,
                             "is_home":home,"efg_pct":.51,"turnover_rate":.13,
                             "offensive_rebound_rate":.25,"free_throw_rate":.2})
        out=build_feature_snapshot({"as_of":"2026-10-12T00:00:00Z","event_time":"2026-10-12T21:00:00Z",
                                    "home_team":"H","away_team":"A","history":hist,
                                    "target_venue_coordinates":[-34.6,-58.4],
                                    "team_last_venue_coordinates":{"H":[-34.6,-58.4],"A":[-31.4,-64.2]}})
        self.assertEqual(out["status"],"FEATURE_SNAPSHOT_READY")
        self.assertEqual(out["home_history_n"],10)  # final rows unavailable at cutoff
        self.assertIn("home_off_ppp_last_10",out["features"])
        self.assertGreater(out["features"]["away_travel_km"],0)

    def test_feature_snapshot_rejects_cutoff_after_game(self):
        with self.assertRaises(ValueError):
            build_feature_snapshot({"as_of":"2026-11-20T00:00:00Z","event_time":"2026-11-19T00:00:00Z",
                                    "home_team":"H","away_team":"A","history":[]})


    def test_lineup_scenarios_reject_future_status_capture(self):
        players=[]
        for i in range(5):
            players.append({"player_id":f"p{i}","status":"AVAILABLE","expected_minutes":48,
                           "minute_sd":0,"impact_per_100":1,"impact_metric_type":"RAPM",
                           "impact_sample_minutes":8000,"replacement_impact_per_100":0,
                           "impact_captured_at":"2026-11-19T18:00:00Z", "status_captured_at":"2026-11-19T23:00:00Z",
                           "minutes_captured_at":"2026-11-19T18:00:00Z", "impact_source_id":"stats-source",
                           "impact_metric_scope":"NBA::2026::RAPM", "impact_model_version":"v1",
                           "status_source_id":"official-injury-report", "minutes_source_id":"rotation-model-v1"})
        with self.assertRaises(ValueError):
            simulate_lineup_scenarios({"team":"T","competition":"NBA","event_time":"2026-11-20T00:00:00Z",
                                       "forecast_created_at":"2026-11-19T20:00:00Z","game_minutes":48,
                                       "players":players,"simulations":1000})

    def test_market_quote_audit_vig_and_freshness(self):
        now="2026-11-20T00:00:00Z"
        quotes=[]
        for op, odds in (("a",1.8),("b",1.83),("c",1.79)):
            quotes.append({"operator":op,"captured_at":"2026-11-19T23:59:00Z","selected_odds":odds,
                           "opposite_odds":2.1,"market_scope":"NBA::moneyline","event_id":"x",
                           "market_scope":"NBA::moneyline"})
        out=audit_market_quotes({"market_scope":"NBA::moneyline","event_id":"x","as_of":now,"event_time":"2026-11-20T02:00:00Z","quotes":quotes})
        self.assertEqual(out["status"],"MARKET_REFERENCE_READY")
        self.assertEqual(out["operator_count"],3)
        self.assertGreater(out["mean_overround"],0)


    def test_market_audit_computes_opening_move(self):
        now="2026-11-20T00:00:00Z"
        current=[]; opening=[]
        for op, odds in (("a",1.8),("b",1.82),("c",1.79)):
            current.append({"operator":op,"captured_at":"2026-11-19T23:59:00Z","selected_odds":odds,
                            "opposite_odds":2.1,"market_scope":"S","event_id":"E"})
            opening.append({"operator":op,"captured_at":"2026-11-19T18:00:00Z","selected_odds":2.0,
                            "opposite_odds":1.9,"market_scope":"S","event_id":"E"})
        out=audit_market_quotes({"market_scope":"S","event_id":"E","as_of":now,"event_time":"2026-11-20T02:00:00Z","quotes":current,"opening_quotes":opening})
        self.assertIsNotNone(out["opening_to_current"])
        self.assertEqual(out["opening_to_current"]["opening_operator_count"],3)

    def test_market_quote_audit_rejects_stale(self):
        out=audit_market_quotes({"market_scope":"s","event_id":"x","as_of":"2026-11-20T00:00:00Z","event_time":"2026-11-20T02:00:00Z",
            "quotes":[{"operator":"a","captured_at":"2026-11-19T23:00:00Z","selected_odds":1.8,
                       "opposite_odds":2.1,"market_scope":"s","event_id":"x"}]})
        self.assertEqual(out["status"],"BLOCKED")

    def test_lineup_scenarios_run_with_adjusted_impact(self):
        players=[]
        for i in range(5):
            players.append({"player_id":f"p{i}","status":"AVAILABLE","expected_minutes":48,
                           "minute_sd":0,"impact_per_100":i,"impact_metric_type":"RAPM",
                           "impact_sample_minutes":8000,"replacement_impact_per_100":0,
                           "impact_captured_at":"2026-11-19T18:00:00Z", "status_captured_at":"2026-11-19T18:00:00Z",
                           "minutes_captured_at":"2026-11-19T18:00:00Z", "impact_source_id":"stats-source",
                           "impact_metric_scope":"NBA::2026::RAPM", "impact_model_version":"v1",
                           "status_source_id":"official-injury-report", "minutes_source_id":"rotation-model-v1"})
        out=simulate_lineup_scenarios({"team":"T","competition":"NBA","event_time":"2026-11-20T00:00:00Z","forecast_created_at":"2026-11-19T20:00:00Z",
                                       "game_minutes":48,"players":players,"simulations":1000})
        self.assertEqual(out["status"],"SCENARIO_SENSITIVITY_ONLY")
        self.assertEqual(out["valid_scenarios"],1000)

    def test_lineup_scenarios_reject_raw_plus_minus(self):
        players=[]
        for i in range(5):
            players.append({"player_id":f"p{i}","status":"AVAILABLE","expected_minutes":48,
                           "minute_sd":0,"impact_per_100":1,"impact_metric_type":"RAW_PLUS_MINUS",
                           "impact_sample_minutes":8000,"replacement_impact_per_100":0,
                           "impact_captured_at":"2026-11-19T18:00:00Z", "status_captured_at":"2026-11-19T18:00:00Z",
                           "minutes_captured_at":"2026-11-19T18:00:00Z", "impact_source_id":"stats-source",
                           "impact_metric_scope":"NBA::2026::RAPM", "impact_model_version":"v1",
                           "status_source_id":"official-injury-report", "minutes_source_id":"rotation-model-v1"})
        with self.assertRaises(ValueError):
            simulate_lineup_scenarios({"team":"T","competition":"NBA","event_time":"2026-11-20T00:00:00Z","forecast_created_at":"2026-11-19T20:00:00Z",
                                       "game_minutes":48,"players":players,"simulations":1000})

    def test_possession_simulator_returns_exploratory_not_validated(self):
        out=simulate_market_scenarios({"home_team":"H","away_team":"A","pace_mean":70,
            "home_ppp_mean":1.12,"away_ppp_mean":1.05,"overtime_rule":"INCLUDED","simulations":10000,
            "parameter_batches":10,"markets":[{"market_id":"ml","type":"MONEYLINE_HOME"},
            {"market_id":"tot","type":"TOTAL_OVER","line":150.5},
            {"market_id":"under","type":"TOTAL_UNDER","line":150.5},
            {"market_id":"away","type":"MONEYLINE_AWAY"}]})
        self.assertEqual(out["status"],"EXPLORATORY_NOT_VALIDATED")
        self.assertEqual(len(out["markets"]),4)
        self.assertIsNotNone(out["markets"][0]["scenario_probability_mean"])
        self.assertAlmostEqual(sum(out["markets"][0]["outcome_probabilities"].values()), 1.0, places=12)


    def test_possession_sim_reports_unconditional_probability_and_pushes(self):
        out = simulate_market_scenarios({"home_team":"H", "away_team":"A", "pace_mean":48,
            "home_ppp_mean":1.0, "away_ppp_mean":1.0, "pace_sd":0, "ppp_sd":0,
            "home_ppp_parameter_se":0, "away_ppp_parameter_se":0, "overtime_rule":"REGULATION_ONLY",
            "simulations":10000, "parameter_batches":10,
            "markets":[{"market_id":"ml-home", "type":"MONEYLINE_HOME"}]})
        market = out["markets"][0]
        self.assertEqual(market["scenario_probability_mean"], 0.0)
        self.assertEqual(market["push_probability"], 1.0)
        self.assertEqual(market["outcome_probabilities"]["PUSH"], 1.0)
        self.assertAlmostEqual(sum(market["outcome_probabilities"].values()), 1.0)

    def test_possession_sim_settles_quarter_lines_as_half_results(self):
        out = simulate_market_scenarios({"home_team":"H", "away_team":"A", "pace_mean":48,
            "home_ppp_mean":1.0, "away_ppp_mean":1.0, "pace_sd":0, "ppp_sd":0,
            "home_ppp_parameter_se":0, "away_ppp_parameter_se":0, "overtime_rule":"REGULATION_ONLY",
            "simulations":10000, "parameter_batches":10,
            "markets":[{"market_id":"spread-quarter", "type":"SPREAD_HOME", "line":0.25, "decimal_odds":1.9}]})
        market = out["markets"][0]
        self.assertEqual(market["outcome_probabilities"]["HALF_WIN"], 1.0)
        self.assertEqual(market["scenario_probability_mean"], 0.0)
        self.assertAlmostEqual(market["expected_net_units_per_unit_stake"], 0.45, places=8)

    def test_settlement_quarter_spread_records_half_win_not_binary_win(self):
        out = settle_market({"market_family":"SPREAD", "selection":"HOME", "line_rule":"FULL_GAME",
            "settlement_status":"SETTLED", "overtime_rule":"INCLUDED", "line_value":0.25,
            "final_home_score":100, "final_away_score":100, "decimal_odds":1.9})
        self.assertEqual(out["settlement_result"], "HALF_WIN")
        self.assertFalse(out["binary_training_eligible"])
        self.assertIsNone(out["binary_outcome"])

    def test_lineup_minutes_are_redistributed_without_losing_team_court_time(self):
        players=[]
        for i in range(6):
            players.append({"player_id":f"p{i}", "status":"AVAILABLE", "expected_minutes":48,
                "minute_sd":0, "impact_per_100":1, "impact_metric_type":"RAPM", "impact_sample_minutes":8000,
                "replacement_impact_per_100":0, "impact_captured_at":"2026-11-19T18:00:00Z",
                "status_captured_at":"2026-11-19T18:00:00Z", "minutes_captured_at":"2026-11-19T18:00:00Z",
                "impact_source_id":"stats-source", "impact_metric_scope":"NBA::2026::RAPM",
                "impact_model_version":"v1", "status_source_id":"official-injury-report",
                "minutes_source_id":"rotation-model-v1"})
        out=simulate_lineup_scenarios({"team":"T", "competition":"NBA", "event_time":"2026-11-20T00:00:00Z",
            "forecast_created_at":"2026-11-19T20:00:00Z", "game_minutes":48, "players":players, "simulations":1000})
        self.assertEqual(out["status"], "SCENARIO_SENSITIVITY_ONLY")
        self.assertAlmostEqual(out["projected_team_player_minutes_mean"], 240.0)
        self.assertAlmostEqual(out["projected_team_player_minutes_min"], 240.0)

    def test_market_opening_quote_must_precede_current_quote(self):
        data={"market_scope":"NBA::moneyline", "event_id":"x", "as_of":"2026-11-20T00:00:00Z",
            "event_time":"2026-11-20T02:00:00Z", "quotes":[
                {"operator":"a", "captured_at":"2026-11-19T23:50:00Z", "selected_odds":1.8, "opposite_odds":2.1, "market_scope":"NBA::moneyline", "event_id":"x"},
                {"operator":"b", "captured_at":"2026-11-19T23:51:00Z", "selected_odds":1.8, "opposite_odds":2.1, "market_scope":"NBA::moneyline", "event_id":"x"},
                {"operator":"c", "captured_at":"2026-11-19T23:52:00Z", "selected_odds":1.8, "opposite_odds":2.1, "market_scope":"NBA::moneyline", "event_id":"x"}],
            "opening_quotes":[{"operator":"a", "captured_at":"2026-11-19T23:55:00Z", "selected_odds":1.9,
                "opposite_odds":1.9, "market_scope":"NBA::moneyline", "event_id":"x"}]}
        with self.assertRaises(ValueError):
            audit_market_quotes(data)

    def test_possession_simulator_requires_overtime_rule(self):
        with self.assertRaises(ValueError):
            simulate_market_scenarios({"home_team":"H","away_team":"A","pace_mean":70,
                "home_ppp_mean":1.12,"away_ppp_mean":1.05,"simulations":10000,
                "markets":[{"type":"MONEYLINE_HOME"}]})

    def test_monitor_history_compares_to_market_and_accepteds(self):
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/"history.csv"
            headers="event_id,event_time,forecast_created_at,competition,season,market_scope,model_version,probability,market_probability,outcome,decision,odds_taken,odds_taken_captured_at,market_probability_at_take,market_probability_at_take_captured_at,closing_market_probability,closing_market_probability_captured_at\n"
            lines=[headers]
            for i in range(50):
                outcome=1 if i<35 else 0
                lines.append(f"e{i},2026-10-{(i%28)+1:02d}T20:00:00Z,2026-10-{(i%28)+1:02d}T18:00:00Z,NBA,2026,ML,model1,0.7,0.65,{outcome},{'ACCEPTED' if i<30 else 'REJECTED'},1.8,2026-10-{(i%28)+1:02d}T17:55:00Z,0.65,2026-10-{(i%28)+1:02d}T17:55:00Z,0.67,2026-10-{(i%28)+1:02d}T19:00:00Z\n")
            path.write_text("".join(lines))
            out=audit_forecast_history(path,{"min_settled_predictions":40,"min_accepted_predictions":20,"recent_window":40})
            self.assertEqual(out["status"],"MONITORING_EVIDENCE_AVAILABLE")
            self.assertEqual(out["scopes"][0]["all_candidates"]["n"],50)
            self.assertEqual(out["scopes"][0]["accepted_only"]["n"],30)
            self.assertIsNotNone(out["scopes"][0]["accepted_only"]["flat_stake_roi"])
            self.assertAlmostEqual(out["scopes"][0]["accepted_only"]["mean_clv_probability_points"],0.02,places=8)

    def test_monitor_rejects_naive_timestamp(self):
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/"history.csv"
            path.write_text("event_id,event_time,forecast_created_at,competition,season,market_scope,model_version,probability,market_probability,outcome,decision\n"
                            "e1,2026-10-01T20:00:00,2026-10-01T18:00:00,NBA,2026,ML,m,0.7,0.6,1,ACCEPTED\n")
            with self.assertRaises(ValueError):
                audit_forecast_history(path,{})

    def test_provider_client_config_and_cache(self):
        Handler.hits=0
        server=ThreadingHTTPServer(("127.0.0.1",0),Handler)
        thread=threading.Thread(target=server.serve_forever,daemon=True); thread.start()
        try:
            with tempfile.TemporaryDirectory() as td:
                config={"provider_id":"local-test","base_url":f"http://127.0.0.1:{server.server_port}",
                        "allowed_hosts":["127.0.0.1"],"license_status":"MANUAL_USER_SUPPLIED","terms_confirmed":True,
                        "endpoints":{"schedule":"/games"},"cache_ttl_seconds":60}
                client=JsonProviderClient(config,Path(td)/"cache.sqlite")
                first=client.fetch("schedule")
                second=client.fetch("schedule")
                self.assertFalse(first.cache_hit); self.assertTrue(second.cache_hit)
                self.assertIsNotNone(first.capture_id)
                self.assertEqual(first.capture_id, second.capture_id)
                self.assertEqual(Handler.hits,1)
                import sqlite3
                with sqlite3.connect(Path(td)/"cache.sqlite") as db:
                    self.assertEqual(db.execute("SELECT COUNT(*) FROM source_capture").fetchone()[0],1)
                    with self.assertRaises(sqlite3.IntegrityError):
                        db.execute("DELETE FROM source_capture")
        finally:
            server.shutdown(); thread.join(timeout=2); server.server_close()


    def test_provider_redacts_sensitive_query_parameter(self):
        Handler.hits=0
        server=ThreadingHTTPServer(("127.0.0.1",0),Handler)
        thread=threading.Thread(target=server.serve_forever,daemon=True); thread.start()
        try:
            with tempfile.TemporaryDirectory() as td:
                config={"provider_id":"local-test","base_url":f"http://127.0.0.1:{server.server_port}",
                        "allowed_hosts":["127.0.0.1"],"license_status":"MANUAL_USER_SUPPLIED","terms_confirmed":True,
                        "endpoints":{"schedule":"/games?api_key={secret}"},"cache_ttl_seconds":0}
                client=JsonProviderClient(config,Path(td)/"cache.sqlite")
                result=client.fetch("schedule",params={"secret":"dont-log-this"})
                self.assertNotIn("dont-log-this",result.source_url)
                import sqlite3
                with sqlite3.connect(Path(td)/"cache.sqlite") as db:
                    saved=db.execute("SELECT source_url FROM source_capture").fetchone()[0]
                    self.assertNotIn("dont-log-this",saved)
        finally:
            server.shutdown(); thread.join(timeout=2); server.server_close()

    def test_provider_rejects_unknown_license_and_unconfirmed_terms(self):
        with self.assertRaises(ValueError):
            JsonProviderClient({"provider_id":"x","base_url":"https://api.example.com","license_status":"UNKNOWN",
                                "terms_confirmed":True,"endpoints":{"games":"games"}})
        with self.assertRaises(ValueError):
            JsonProviderClient({"provider_id":"x","base_url":"https://api.example.com","license_status":"OPEN_LICENSE",
                                "terms_confirmed":False,"endpoints":{"games":"games"}})


if __name__=="__main__":
    unittest.main()
