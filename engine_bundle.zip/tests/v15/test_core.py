from __future__ import annotations

import os
import sys
import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "scripts"))

from edge_v15.data_quality import SourceRecord, assess_sources, validate_point_in_time, DataStatus
from edge_v15.team_model import (TeamGame, LeaguePriors, fit_team_rates, fit_opponent_adjusted_ratings,
                                 estimate_possessions, four_factors, project_game, simulate_game)
from edge_v15.market_pricing import price_game_market, ev_per_unit, no_vig_probabilities
from edge_v15.player_model import PlayerRoleInput, simulate_player_stats, prop_probability
from edge_v15.calibration import ForecastOutcome, score_forecasts, wilson_interval
from edge_v15.backtesting import BacktestRow, chronological_backtest, walk_forward_splits
from edge_v15.combo_optimizer import LegCandidate, optimize_combinations
from edge_v15.ledger import ForecastLedger
from edge_v15.prediction_gate import GateInput, assess_prediction_gate
from edge_v15.joint_simulation import PlayerInGame, JointLegSpec, simulate_joint_game_players, build_joint_scenarios
from edge_v15.model_governance import PairedForecast, compare_challenger, detect_degradation


class DataQualityTests(unittest.TestCase):
    def test_source_freshness_and_hash(self):
        src = SourceRecord("official", "boxscore", "2026-11-19T10:00:00Z", "2026-11-19T10:01:00Z",
                           "AUTHORIZED", 1, {"points": 100}, ttl_minutes=120)
        report = assess_sources([src], "2026-11-19T11:00:00Z")
        self.assertEqual(report.status, DataStatus.PASS)
        self.assertEqual(len(report.source_hashes[0]), 64)

    def test_stale_source_is_conditional(self):
        src = SourceRecord("manual", "injury", "2026-11-18T00:00:00Z", "2026-11-18T00:01:00Z",
                           "MANUAL_USER_SUPPLIED", 3, {"status": "questionable"}, ttl_minutes=15)
        report = assess_sources([src], "2026-11-19T00:00:00Z")
        self.assertEqual(report.status, DataStatus.CONDITIONAL)
        self.assertTrue(any("stale" in w for w in report.warnings))

    def test_naive_time_rejected(self):
        src = SourceRecord("x", "y", "2026-11-19T10:00:00", "2026-11-19T10:01:00Z",
                           "AUTHORIZED", 1, {"x": 1})
        self.assertIn("invalid_or_timezone_naive_timestamp", src.validate())

    def test_point_in_time_blocks_lookahead(self):
        ok, errors = validate_point_in_time(event_at="2026-11-19T19:00:00Z",
                                            forecast_created_at="2026-11-19T19:01:00Z",
                                            data_cutoff_at="2026-11-19T18:00:00Z")
        self.assertFalse(ok)
        self.assertIn("forecast_not_created_before_event", errors)


class TeamModelTests(unittest.TestCase):
    def setUp(self):
        self.priors = LeaguePriors(99, 1.12, 0.01, 8, 8)
        self.history = [
            TeamGame("2026-10-01", "A", "C", 110, 100, 98, True),
            TeamGame("2026-10-05", "A", "D", 108, 111, 97, False),
            TeamGame("2026-10-08", "A", "E", 115, 105, 101, True),
            TeamGame("2026-10-02", "B", "F", 105, 112, 98, False),
            TeamGame("2026-10-06", "B", "G", 114, 104, 100, True),
            TeamGame("2026-10-10", "B", "H", 102, 109, 96, False),
            TeamGame("2026-11-20", "A", "B", 200, 190, 100, True),
        ]

    def test_fit_excludes_future_game(self):
        rates = fit_team_rates(self.history, "A", as_of="2026-11-19T00:00:00Z", priors=self.priors)
        self.assertEqual(rates.games, 3)
        self.assertLess(rates.effective_games, 3.01)

    def test_game_simulation_reproducible_and_bounded(self):
        h = fit_team_rates(self.history, "A", as_of="2026-11-19T00:00:00Z", priors=self.priors)
        a = fit_team_rates(self.history, "B", as_of="2026-11-19T00:00:00Z", priors=self.priors)
        adjusted = fit_opponent_adjusted_ratings(self.history, as_of="2026-11-19T00:00:00Z",
                                                   league_ppp=self.priors.points_per_possession, ridge=5)
        projection = project_game(h, a, self.priors, adjusted_ratings=adjusted)
        self.assertEqual(projection.rating_method, "home_away_split_baseline")
        self.assertGreater(h.home_games, 0)
        self.assertGreater(a.away_games, 0)
        sim1 = simulate_game(projection, simulations=1000, seed=42)
        sim2 = simulate_game(projection, simulations=1000, seed=42)
        self.assertEqual(sim1.home_scores, sim2.home_scores)
        self.assertEqual(len(sim1.away_scores), 1000)
        self.assertGreater(projection.home_points_mean, 0)

    def test_insufficient_history_rejected(self):
        with self.assertRaises(ValueError):
            fit_team_rates(self.history, "MISSING", as_of="2026-11-19T00:00:00Z", priors=self.priors)

    def test_date_only_same_day_result_is_not_available_yet(self):
        same_day = [TeamGame("2026-10-08", "Z", "Y", 110, 100, 98, True)]
        with self.assertRaises(ValueError):
            fit_team_rates(same_day, "Z", as_of="2026-10-08T12:00:00Z", priors=self.priors)


class MarketAndPlayerTests(unittest.TestCase):
    def _sim(self):
        rows = [TeamGame("2026-10-01", "A", "C", 110, 100, 98, True),
                TeamGame("2026-10-02", "B", "D", 105, 112, 98, False)]
        priors = LeaguePriors(99, 1.12)
        p = project_game(fit_team_rates(rows, "A", as_of="2026-11-01T00:00:00Z", priors=priors),
                         fit_team_rates(rows, "B", as_of="2026-11-01T00:00:00Z", priors=priors), priors)
        return simulate_game(p, simulations=1000, seed=1)

    def test_possession_estimator_and_four_factors(self):
        poss = estimate_possessions(field_goal_attempts=90, offensive_rebounds=10,
                                    turnovers=12, free_throw_attempts=20)
        self.assertAlmostEqual(poss, 100.8)
        factors = four_factors(field_goal_attempts=80, field_goals_made=40,
                               three_point_attempts=30, three_pointers_made=10,
                               free_throw_attempts=20, free_throws_made=15,
                               offensive_rebounds=10, turnovers=12,
                               opponent_defensive_rebounds=25)
        self.assertAlmostEqual(factors["effective_field_goal_pct"], 0.5625)
        self.assertAlmostEqual(factors["three_point_attempt_rate"], 0.375)

    def test_market_probabilities_sum_to_one(self):
        result = price_game_market(self._sim(), "total", side="over", line=210.5, overtime_rule="excluded")
        self.assertAlmostEqual(result.p_win + result.p_push + result.p_loss, 1.0)
        self.assertEqual(result.samples, 1000)

    def test_unknown_overtime_rule_blocks_pricing(self):
        with self.assertRaises(ValueError):
            price_game_market(self._sim(), "moneyline", side="home")

    def test_no_vig_prices(self):
        probs = no_vig_probabilities({"home": 1.8, "away": 2.1})
        self.assertAlmostEqual(sum(probs.values()), 1.0)
        self.assertGreater(probs["home"], probs["away"])

    def test_market_ev(self):
        result = price_game_market(self._sim(), "moneyline", side="home", overtime_rule="excluded")
        self.assertTrue(-1 <= ev_per_unit(result, 2.0) <= 1)

    def test_player_props_share_minutes_and_produce_counts(self):
        role = PlayerRoleInput("P", 0.9, 30, 3, 48,
                               {"points": 0.7, "rebounds": 0.2},
                               {"points": 0.1, "rebounds": 0.2})
        draws, summary = simulate_player_stats(role, simulations=1000, seed=5)
        self.assertEqual(len(draws), 1000)
        self.assertLess(summary["minutes_mean_unconditional"], 30)
        prop = prop_probability(draws, "points", 15.5, "over")
        self.assertAlmostEqual(prop["p_win"] + prop["p_push"] + prop["p_loss"], 1)

    def test_player_invalid_minutes_rejected(self):
        role = PlayerRoleInput("P", 1.0, 50, 2, 48, {"points": 0.5}, {})
        with self.assertRaises(ValueError): role.validate()

    def test_joint_game_player_scenarios_share_simulation_rows(self):
        history = [TeamGame("2026-10-01", "A", "C", 110, 100, 98, True),
                   TeamGame("2026-10-02", "B", "D", 105, 112, 98, False)]
        priors = LeaguePriors(99, 1.12)
        home = fit_team_rates(history, "A", as_of="2026-11-01T00:00:00Z", priors=priors)
        away = fit_team_rates(history, "B", as_of="2026-11-01T00:00:00Z", priors=priors)
        projection = project_game(home, away, priors)
        role = PlayerRoleInput("P", .95, 30, 3, 48, {"points": .7, "rebounds": .2}, {})
        draws = simulate_joint_game_players(projection, [PlayerInGame(role, "home")], simulations=1000, seed=3)
        specs = [JointLegSpec("G", "game", market="total", side="over", line=190.5),
                 JointLegSpec("PPTS", "player_prop", side="over", line=15.5, player="P", stat="points")]
        scenarios = build_joint_scenarios(draws, specs)
        self.assertEqual(len(scenarios), 1000)
        self.assertEqual(set(scenarios[0]), {"G", "PPTS"})

    def test_joint_scenarios_reject_push_lines(self):
        with self.assertRaises(ValueError):
            build_joint_scenarios([{"home_score": 100, "away_score": 90, "players": {}}],
                                  [JointLegSpec("G", "game", market="total", side="over", line=190)])


class EvaluationTests(unittest.TestCase):
    def test_wilson_interval(self):
        low, high = wilson_interval(80, 100)
        self.assertLess(low, 0.8)
        self.assertGreater(high, 0.8)

    def test_calibration_scores(self):
        report = score_forecasts([ForecastOutcome(0.8, 1), ForecastOutcome(0.2, 0),
                                  ForecastOutcome(0.7, 1), ForecastOutcome(0.3, 0)])
        self.assertEqual(report["n"], 4)
        self.assertLess(report["brier_score"], 0.1)
        self.assertGreaterEqual(report["expected_calibration_error"], 0)

    def test_backtest_rejects_lookahead_and_scores_holdout(self):
        good = BacktestRow("2026-10-01T20:00:00Z", "2026-10-01T18:00:00Z", "2026-10-01T17:00:00Z", .7, 1, "m1", "total", "NBA")
        bad = BacktestRow("2026-10-02T20:00:00Z", "2026-10-02T21:00:00Z", "2026-10-02T17:00:00Z", .7, 0, "m1", "total", "NBA")
        result = chronological_backtest([good, bad], test_start="2026-10-01T00:00:00Z")
        self.assertEqual(result["n_test"], 1)
        self.assertTrue(result["data_integrity_errors"])

    def test_walk_forward_split(self):
        rows = []
        for day in range(1, 11):
            dt = f"2026-10-{day:02d}"
            rows.append(BacktestRow(dt+"T20:00:00Z", dt+"T18:00:00Z", dt+"T17:00:00Z", .6, day % 2, "m", "ml", "NBA"))
        result = walk_forward_splits(rows, min_train_events=4, test_block_events=3)
        self.assertEqual(len(result["splits"]), 2)

    def test_challenger_promotion_uses_paired_event_bootstrap(self):
        rows = []
        for day in range(1, 301):
            outcome = day % 2
            created = f"2026-10-{(day % 28)+1:02d}T12:00:00Z"
            # Keep all events in temporal order with point-in-time cutoffs.
            event = f"2026-12-{(day % 28)+1:02d}T20:00:00Z"
            cutoff = f"2026-10-{(day % 28)+1:02d}T10:00:00Z"
            rows.append(PairedForecast(str(day), "NBA|2026|total|pregame", event, created, cutoff,
                                        outcome, 0.55, 0.95 if outcome else 0.05))
        result = compare_challenger(rows, min_predictions=200, min_events=200, bootstrap_samples=500)
        self.assertEqual(result["status"], "PROMOTION_ELIGIBLE")
        self.assertTrue(result["brier_superiority_gate"])

    def test_degradation_monitor_alerts(self):
        base = [ForecastOutcome(.8, 1), ForecastOutcome(.2, 0)] * 20
        recent = [ForecastOutcome(.8, 0), ForecastOutcome(.2, 1)] * 20
        self.assertEqual(detect_degradation(base, recent)["status"], "DRIFT_ALERT")


class ComboTests(unittest.TestCase):
    def setUp(self):
        self.legs = [
            LegCandidate("A", "G1", "total", "over", 1.5, True, True, True),
            LegCandidate("B", "G1", "player_points", "over", 1.6, True, True, True),
            LegCandidate("C", "G2", "moneyline", "home", 1.8, True, True, True),
            LegCandidate("D", "G3", "total", "under", 1.7, False, True, True),
        ]
        self.scenarios = [
            {"A":True,"B":True,"C":True,"D":True},
            {"A":True,"B":False,"C":True,"D":True},
            {"A":True,"B":True,"C":False,"D":True},
            {"A":False,"B":True,"C":True,"D":True},
            {"A":True,"B":True,"C":True,"D":False},
            {"A":True,"B":True,"C":True,"D":True},
        ]

    def test_optimizer_requires_exact_same_game_price(self):
        result = optimize_combinations(self.legs[:3], self.scenarios, target_odds=2.4,
                                       min_legs=2, max_legs=2, joint_prices={"A|B":2.4},
                                       verified_joint_price_keys=["A|B"])
        self.assertEqual(result["status"], "CANDIDATES_FOUND")
        self.assertEqual(result["best"]["legs"], ["A", "B"])
        self.assertIn("EXACT_OPERATOR_JOINT_PRICE_VERIFIED", result["best"]["price_status"])

    def test_unvalidated_legs_excluded(self):
        result = optimize_combinations(self.legs, self.scenarios, target_odds=3.0,
                                       min_legs=2, max_legs=2, joint_prices={"A|B":2.4},
                                       assume_independent_cross_event=True)
        self.assertIn("D", [x["leg_id"] for x in result["rejected_legs"]])

    def test_no_same_event_product_price(self):
        result = optimize_combinations(self.legs[:2], self.scenarios, target_odds=2.4,
                                       min_legs=2, max_legs=2)
        self.assertEqual(result["status"], "NO_RESPONSIBLE_COMBO_IN_ODDS_BAND")

    def test_combo_requires_scenarios(self):
        with self.assertRaises(ValueError):
            optimize_combinations(self.legs[:2], [], target_odds=2.4)

    def test_combo_rejects_incomplete_or_unknown_scenario_rows(self):
        incomplete = optimize_combinations(self.legs[:2], [{"A": True}], target_odds=2.4, min_legs=2)
        unknown = optimize_combinations(self.legs[:2], [{"A": True, "B": None}], target_odds=2.4, min_legs=2)
        self.assertGreater(incomplete["scenario_integrity_failures"], 0)
        self.assertGreater(unknown["scenario_integrity_failures"], 0)
        self.assertEqual(incomplete["status"], "NO_RESPONSIBLE_COMBO_IN_ODDS_BAND")


class LedgerAndGateTests(unittest.TestCase):
    def test_ledger_persists_and_forecast_is_immutable(self):
        with tempfile.TemporaryDirectory() as tmp:
            ledger = ForecastLedger(Path(tmp) / "test.sqlite")
            ledger.add_forecast(forecast_id="f1", event_id="g1", event_at="2026-12-01T20:00:00Z",
                                market="total", selection="over", probability=.6, model_version="v15",
                                data_cutoff="2026-12-01T10:00:00Z", created_at="2026-12-01T11:00:00Z",
                                validation_status="EXPLORATORY", metadata={})
            self.assertEqual(ledger.counts()["forecast"], 1)
            with self.assertRaises(Exception):
                with ledger.connect() as db: db.execute("UPDATE forecast SET probability=.7 WHERE forecast_id='f1'")

    def test_gate_conditional_when_not_validated(self):
        source = SourceRecord("official", "boxscore", "2026-11-19T10:00:00Z", "2026-11-19T10:01:00Z",
                              "AUTHORIZED", 1, {"score": 1})
        quality = assess_sources([source], "2026-11-19T10:02:00Z")
        result = assess_prediction_gate(GateInput(quality, "2026-11-20T00:00:00Z", "2026-11-19T12:00:00Z",
                                                  "2026-11-19T11:00:00Z", False, False, True, True, 1))
        self.assertEqual(result["status"], "CONDICIONAL")
        self.assertIn("model_not_validated_for_exact_scope", result["warnings"])


if __name__ == "__main__":
    unittest.main()
