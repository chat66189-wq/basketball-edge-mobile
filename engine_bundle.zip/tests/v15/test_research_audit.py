import unittest
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "scripts"))

from edge_v15.research_audit import audit_research_packet, CATEGORY_WEIGHTS


class ResearchAuditTests(unittest.TestCase):
    def packet(self):
        categories = list(CATEGORY_WEIGHTS)
        sources = []
        evidence = []
        for index, category in enumerate(categories, start=1):
            sid = f"S{index}"
            group = "official_competition" if index % 2 else "independent_stats"
            sources.append({
                "id": sid,
                "publisher": f"Publisher {index}",
                "url": f"https://source{index}.example/data",
                "source_type": "official" if index % 2 else "statistics_provider",
                "independence_group": group,
                "retrieved_at": "2026-11-19T19:00:00-03:00",
                "available_at": "2026-11-19T18:00:00-03:00",
            })
            evidence.append({
                "category": category,
                "status": "CHECKED_WITH_DATA",
                "source_ids": [sid],
                "observations": [{"metric": f"{category}_metric", "value": 1, "unit": "index", "window": "current season", "n": 10}],
                "notes": "Observed and captured.",
            })
        # Make the independent cross-check explicitly draw on two distinct origins.
        cross = next(item for item in evidence if item["category"] == "independent_crosscheck")
        cross["source_ids"] = ["S11", "S12"]
        return {
            "as_of": "2026-11-19T20:00:00-03:00",
            "recommendation_requested": True,
            "event": {
                "event_id": "E1", "competition": "League", "season": "2026",
                "home": "A", "away": "B", "start_time": "2026-11-19T21:00:00-03:00",
            },
            "intended_market": {
                "operator": "Book", "market": "moneyline", "selection": "home",
                "period": "full_game", "odds_decimal": 1.8,
                "quoted_at": "2026-11-19T19:30:00-03:00",
            },
            "sources": sources,
            "evidence": evidence,
        }

    def test_complete_research_packet_is_not_pick_approval(self):
        result = audit_research_packet(self.packet())
        self.assertEqual(result["research_completeness_score"], 100.0)
        self.assertEqual(result["status"], "RESEARCH_PACKET_COMPLETE_NOT_PICK_APPROVAL")
        self.assertEqual(result["pick_approval"], "NEVER_GRANTED_BY_RESEARCH_AUDIT")

    def test_missing_critical_category_blocks_completion(self):
        packet = self.packet()
        packet["evidence"] = [x for x in packet["evidence"] if x["category"] != "roster_availability"]
        result = audit_research_packet(packet)
        self.assertEqual(result["status"], "INCOMPLETE_RESEARCH_PACKET")
        self.assertIn("roster_availability", result["missing_critical_categories"])

    def test_lookahead_source_is_flagged(self):
        packet = self.packet()
        packet["sources"][0]["available_at"] = "2026-11-19T20:10:00-03:00"
        result = audit_research_packet(packet)
        self.assertTrue(any("look-ahead" in error for error in result["errors"]))
        self.assertEqual(result["status"], "INCOMPLETE_RESEARCH_PACKET")

    def test_independent_crosscheck_requires_two_source_groups(self):
        packet = self.packet()
        cross = next(item for item in packet["evidence"] if item["category"] == "independent_crosscheck")
        cross["source_ids"] = ["S11", "S1"]  # both official_competition
        result = audit_research_packet(packet)
        self.assertIn("independent_crosscheck", result["missing_critical_categories"])
        self.assertTrue(any("two distinct source groups" in error for error in result["errors"]))

    def test_exact_operator_price_claim_requires_bookmaker_capture(self):
        packet = self.packet()
        packet["intended_market"]["price_verification"] = "EXACT_OPERATOR_VERIFIED"
        result = audit_research_packet(packet)
        self.assertTrue(any("requires a bookmaker or user_capture" in error for error in result["errors"]))

    def test_naive_timestamp_is_rejected(self):
        packet = self.packet()
        packet["as_of"] = "2026-11-19T20:00:00"
        with self.assertRaises(ValueError):
            audit_research_packet(packet)


if __name__ == "__main__":
    unittest.main()
