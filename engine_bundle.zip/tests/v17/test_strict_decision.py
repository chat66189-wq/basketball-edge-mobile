import sys
import unittest
import argparse
import contextlib
import hashlib
import io
import json
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "scripts"))

from edge_v15.strict_decision import evaluate_pick_gate, evaluate_combo_gate
from edge_v15.cli import cmd_pick_audit


class StrictDecisionTests(unittest.TestCase):
    def pick_packet(self):
        return {
            "as_of": "2026-11-20T12:00:00-03:00",
            "event": {"event_id": "E1", "competition": "League", "season": "2026", "start_time": "2026-11-20T20:00:00-03:00"},
            "market": {
                "market_scope": "League|2026|moneyline|full_game|no_line|pregame",
                "market": "moneyline", "selection": "home", "period": "full_game", "line": None,
                "operator": "Book", "odds_decimal": 1.20, "quoted_at": "2026-11-20T11:55:00-03:00",
                "quote_verified_exact_operator": True, "market_rules_verified": True, "model_market_supported": True,
            },
            "availability": {"status": "CONFIRMED", "material_uncertainty": False},
            "data_quality": {"status": "PASS", "point_in_time_pass": True},
            "sources": [
                {"id": "S1", "publisher": "League", "source_type": "official", "independence_group": "official_league", "available_at": "2026-11-20T10:00:00-03:00", "retrieved_at": "2026-11-20T11:00:00-03:00"},
                {"id": "S2", "publisher": "Stats provider", "source_type": "statistics_provider", "independence_group": "independent_stats", "available_at": "2026-11-20T10:00:00-03:00", "retrieved_at": "2026-11-20T11:00:00-03:00"},
            ],
            "model_validation": {
                "status": "VALIDATED_ON_UNTOUCHED_HOLDOUT_FOR_THIS_EXACT_SCOPE", "validated_scope": "League|2026|moneyline|full_game|no_line|pregame",
                "model_card_audit_status": "MODEL_SCOPE_VALIDATED",
                "model_card_scope": "League|2026|moneyline|full_game|no_line|pregame",
                "model_card_sha256": "a" * 64, "model_card_hash_verified": True,
                "high_confidence_subset_n": 150, "high_confidence_hit_rate_lower95": 0.82,
                "test_period_untouched": True, "data_leakage_audit_pass": True,
                "n_test_predictions": 500, "n_test_events": 300, "walk_forward_splits": 5,
                "evaluation_unit": "unique_event_id", "brier": 0.13, "market_baseline_brier": 0.14,
                "log_loss": 0.40, "market_baseline_log_loss": 0.42, "ece": 0.02,
                "calibration_slope": 1.0, "calibration_intercept": 0.01,
            },
            "probabilities": {
                "p_model": 0.90, "p_model_lower95": 0.84, "p_market_no_vig": 0.80,
                "lower_bound_includes_model_parameter_and_data_uncertainty": True,
                "lower_bound_includes_lineup_and_scenario_stress": True,
            },
        }

    def test_complete_pick_passes_strict_gate(self):
        result = evaluate_pick_gate(self.pick_packet())
        self.assertEqual(result["status"], "PICK_ELIGIBLE_FOR_COMBO_SEARCH")
        self.assertEqual(result["errors"], [])

    def test_unvalidated_model_is_rejected(self):
        packet = self.pick_packet()
        packet["model_validation"]["status"] = "EXPLORATORY_NOT_VALIDATED"
        result = evaluate_pick_gate(packet)
        self.assertEqual(result["status"], "REJECT_PICK")
        self.assertIn("model_not_validated_on_untouched_holdout", result["errors"])


    def test_rejects_unverified_model_card(self):
        packet = self.pick_packet()
        packet["model_validation"]["model_card_hash_verified"] = False
        result = evaluate_pick_gate(packet)
        self.assertIn("model_card_file_hash_not_verified", result["errors"])

    def test_rejects_low_high_confidence_holdout_accuracy_bound(self):
        packet = self.pick_packet()
        packet["model_validation"]["high_confidence_hit_rate_lower95"] = 0.79
        result = evaluate_pick_gate(packet)
        self.assertIn("high_confidence_holdout_hit_rate_lower95_below_0_80", result["errors"])

    def test_rejects_unresolved_material_lineup(self):
        packet = self.pick_packet()
        packet["availability"] = {"status": "PROBABLE", "material_uncertainty": True}
        result = evaluate_pick_gate(packet)
        self.assertIn("material_availability_not_resolved", result["errors"])

    def test_rejects_stale_quote(self):
        packet = self.pick_packet()
        packet["market"]["quoted_at"] = "2026-11-20T11:00:00-03:00"
        result = evaluate_pick_gate(packet)
        self.assertIn("quote_stale", result["errors"])

    def test_rejects_market_scope_mismatch(self):
        packet = self.pick_packet()
        packet["model_validation"]["validated_scope"] = "NBA|2026|moneyline"
        result = evaluate_pick_gate(packet)
        self.assertIn("validation_scope_not_exact_match", result["errors"])

    def test_rejects_weak_conservative_probability(self):
        packet = self.pick_packet()
        packet["probabilities"]["p_model_lower95"] = 0.78
        result = evaluate_pick_gate(packet)
        self.assertIn("conservative_leg_probability_below_strict_threshold", result["errors"])


    def test_pick_audit_reads_real_model_card_and_verifies_sha256(self):
        scope = "League|2026|moneyline|full_game|no_line|pregame"
        card = {
            "status": "VALIDATED_ON_UNTOUCHED_HOLDOUT_FOR_THIS_EXACT_SCOPE",
            "scope": {"market_scope": scope},
            "gates": {"market": True, "calibration": True},
            "walk_forward": {"selection_used_untouched_holdout": False, "splits": 5},
            "untouched_holdout": {"n": 500, "metrics": {
                "brier": 0.13, "market_no_vig_brier": 0.14,
                "log_loss": 0.40, "market_no_vig_log_loss": 0.42,
                "ece_10_bins": 0.02,
                "calibration_line": {"slope": 1.0, "intercept": 0.01},
                "high_confidence_subset": {"n": 150, "hit_rate_wilson_95": [0.82, 0.92]},
            }},
        }
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            card_path = root / "model_card.json"
            card_path.write_text(json.dumps(card), encoding="utf-8")
            digest = hashlib.sha256(card_path.read_bytes()).hexdigest()
            packet = self.pick_packet()
            packet["model_validation"] = {"model_card_path": str(card_path), "model_card_sha256": digest}
            packet_path = root / "pick.json"
            packet_path.write_text(json.dumps(packet), encoding="utf-8")
            args = argparse.Namespace(input=str(packet_path), min_leg_lower_probability=0.80,
                                      min_test_predictions=300, min_test_events=200,
                                      min_walk_forward_splits=5, max_quote_age_minutes=10.0)
            output = io.StringIO()
            with contextlib.redirect_stdout(output):
                cmd_pick_audit(args)
            result = json.loads(output.getvalue())
            self.assertEqual(result["status"], "PICK_ELIGIBLE_FOR_COMBO_SEARCH")

    def test_pick_audit_rejects_model_card_hash_mismatch(self):
        scope = "League|2026|moneyline|full_game|no_line|pregame"
        card = {"status": "VALIDATED_ON_UNTOUCHED_HOLDOUT_FOR_THIS_EXACT_SCOPE",
                "scope": {"market_scope": scope}, "gates": {"valid": True},
                "walk_forward": {"selection_used_untouched_holdout": False, "splits": 5},
                "untouched_holdout": {"n": 500, "metrics": {}}}
        with tempfile.TemporaryDirectory() as d:
            root = Path(d); card_path = root / "card.json"
            card_path.write_text(json.dumps(card), encoding="utf-8")
            packet = self.pick_packet()
            packet["model_validation"] = {"model_card_path": str(card_path), "model_card_sha256": "f" * 64}
            packet_path = root / "pick.json"
            packet_path.write_text(json.dumps(packet), encoding="utf-8")
            args = argparse.Namespace(input=str(packet_path), min_leg_lower_probability=0.80,
                                      min_test_predictions=300, min_test_events=200,
                                      min_walk_forward_splits=5, max_quote_age_minutes=10.0)
            output = io.StringIO()
            with contextlib.redirect_stdout(output):
                cmd_pick_audit(args)
            result = json.loads(output.getvalue())
            self.assertEqual(result["status"], "REJECT_PICK")
            self.assertIn("model_card_file_hash_not_verified", result["errors"])

    def combo_packet(self):
        return {
            "target_decimal_odds": 5.0, "actual_decimal_odds": 5.0, "relative_odds_band": 0.10,
            "actual_price_verified_same_operator": True, "all_lines_and_rules_reverified": True,
            "legs": [
                {"leg_id": "A", "pick_gate_status": "PICK_ELIGIBLE_FOR_COMBO_SEARCH", "p_model_lower95": 0.84},
                {"leg_id": "B", "pick_gate_status": "PICK_ELIGIBLE_FOR_COMBO_SEARCH", "p_model_lower95": 0.82},
            ],
            "p_joint_lower95": 0.34, "p_joint_stress_min": 0.32,
            "joint_lower_bound_includes_model_data_parameter_lineup_uncertainty": True,
            "joint_scenarios_include_all_legs_and_dependencies": True,
            "independence_assumed_without_evidence": False, "scenario_count": 150000,
        }

    def test_strict_combo_passes_only_with_robust_joint_lower_bound(self):
        result = evaluate_combo_gate(self.combo_packet())
        self.assertEqual(result["status"], "STRICT_COMBO_ELIGIBLE_FOR_FINAL_USER_RECHECK")
        self.assertGreaterEqual(result["required_joint_lower_probability"], 0.30)

    def test_combo_rejects_monte_carlo_only_interval(self):
        packet = self.combo_packet()
        packet["joint_lower_bound_includes_model_data_parameter_lineup_uncertainty"] = False
        result = evaluate_combo_gate(packet)
        self.assertIn("joint_lower_bound_omits_model_or_data_uncertainty", result["errors"])

    def test_combo_rejects_low_joint_probability(self):
        packet = self.combo_packet()
        packet["p_joint_lower95"] = 0.22
        packet["p_joint_stress_min"] = 0.21
        result = evaluate_combo_gate(packet)
        self.assertIn("joint_probability_lower_bound_below_strict_floor", result["errors"])
        self.assertIn("worst_stress_joint_probability_below_strict_floor", result["errors"])

    def test_combo_rejects_unverified_price(self):
        packet = self.combo_packet()
        packet["actual_price_verified_same_operator"] = False
        result = evaluate_combo_gate(packet)
        self.assertIn("combined_price_not_verified_at_same_operator", result["errors"])


if __name__ == "__main__":
    unittest.main()
