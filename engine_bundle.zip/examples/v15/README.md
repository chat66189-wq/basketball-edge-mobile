# Ejemplos v15

Los tres JSON son fixtures sintéticos para probar la interfaz, no estadísticas reales ni recomendaciones.

- `game_input_example.json`: proyección de partido y pricing por simulación; exige declarar la regla de overtime.
- `player_prop_example.json`: proyección simplificada de minutos/tasas y líneas individuales.
- `joint_input_example.json`: simula marcador + jugadores en una misma secuencia de escenarios, para no evaluar patas del mismo partido en escenarios independientes.
- `combo_search_example.json`: ejemplo del optimizador. Los precios de ejemplo no son cotizaciones de una casa.

Los resultados no se deben apostar. La salida de cada baseline sigue siendo `EXPLORATORY_NOT_VALIDATED` hasta la validación real de su alcance.
