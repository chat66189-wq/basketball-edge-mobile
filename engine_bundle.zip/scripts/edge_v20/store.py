"""Offline-first SQLite data store and auditable manual ingestion for BEA v20."""
from __future__ import annotations
import argparse,csv,hashlib,json,math,sqlite3
from datetime import datetime,timezone
from pathlib import Path

VERSION=1
DATASETS={
 'games':(['event_id','competition','season','event_time','home_team','away_team','status'], 'games', ['event_id','competition','season','event_time','home_team','away_team','status','home_score','away_score','source_id','captured_at','payload_sha256']),
 'team_stats':(['event_id','team','possessions','points'],'team_game_stats',['event_id','team','possessions','points','fga','fgm','fg3a','fg3m','fta','ftm','oreb','dreb','tov','source_id','captured_at']),
 'odds':(['event_id','market_scope','operator','selection','decimal_odds','captured_at'],'odds_snapshots',['event_id','market_scope','operator','selection','line','decimal_odds','captured_at','source_id','rules','payload_sha256']),
 'player_stats':(['event_id','player_id','team','minutes','points'],'player_game_stats',['event_id','player_id','team','minutes','points','rebounds','assists','steals','blocks','turnovers','fga','fgm','fg3a','fg3m','fta','ftm','source_id','captured_at'])}
def now(): return datetime.now(timezone.utc).isoformat()
def timestamp(s,name):
 try: d=datetime.fromisoformat(str(s).replace('Z','+00:00'))
 except Exception as e: raise ValueError(f'{name}_invalid_iso8601') from e
 if d.tzinfo is None or d.utcoffset() is None: raise ValueError(f'{name}_timezone_required')
 return d
def digest(path):
 h=hashlib.sha256()
 with open(path,'rb') as f:
  for b in iter(lambda:f.read(1048576),b''): h.update(b)
 return h.hexdigest()
def connect(path):
 p=Path(path); p.parent.mkdir(parents=True,exist_ok=True); db=sqlite3.connect(p); db.row_factory=sqlite3.Row
 db.execute('PRAGMA foreign_keys=ON'); db.execute('PRAGMA journal_mode=WAL'); schema(db); return db
def schema(db):
 db.executescript('''
 CREATE TABLE IF NOT EXISTS schema_meta(version INTEGER NOT NULL,installed_at TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS source_registry(source_id TEXT PRIMARY KEY,source_name TEXT NOT NULL,source_type TEXT NOT NULL,license_status TEXT NOT NULL CHECK(license_status IN ('AUTHORIZED','OPEN_LICENSE','MANUAL_USER_SUPPLIED','UNKNOWN')),terms_confirmed INTEGER NOT NULL,attribution TEXT,registered_at TEXT NOT NULL,notes TEXT);
 CREATE TABLE IF NOT EXISTS competitions(competition_id TEXT PRIMARY KEY,name TEXT NOT NULL,region TEXT,gender TEXT,level TEXT,source_id TEXT,FOREIGN KEY(source_id) REFERENCES source_registry(source_id));
 CREATE TABLE IF NOT EXISTS seasons(season_id TEXT PRIMARY KEY,competition_id TEXT NOT NULL,season_label TEXT NOT NULL,start_date TEXT,end_date TEXT,FOREIGN KEY(competition_id) REFERENCES competitions(competition_id));
 CREATE TABLE IF NOT EXISTS teams(team_id TEXT PRIMARY KEY,team_name TEXT NOT NULL,competition_id TEXT,source_id TEXT,FOREIGN KEY(competition_id) REFERENCES competitions(competition_id),FOREIGN KEY(source_id) REFERENCES source_registry(source_id));
 CREATE TABLE IF NOT EXISTS players(player_id TEXT PRIMARY KEY,player_name TEXT NOT NULL,source_id TEXT,FOREIGN KEY(source_id) REFERENCES source_registry(source_id));
 CREATE TABLE IF NOT EXISTS games(event_id TEXT PRIMARY KEY,competition TEXT NOT NULL,season TEXT NOT NULL,event_time TEXT NOT NULL,home_team TEXT NOT NULL,away_team TEXT NOT NULL,status TEXT NOT NULL,home_score REAL,away_score REAL,source_id TEXT,captured_at TEXT,payload_sha256 TEXT,FOREIGN KEY(source_id) REFERENCES source_registry(source_id));
 CREATE TABLE IF NOT EXISTS team_game_stats(id INTEGER PRIMARY KEY,event_id TEXT NOT NULL,team TEXT NOT NULL,possessions REAL,points REAL,fga REAL,fgm REAL,fg3a REAL,fg3m REAL,fta REAL,ftm REAL,oreb REAL,dreb REAL,tov REAL,source_id TEXT,captured_at TEXT,FOREIGN KEY(event_id) REFERENCES games(event_id),FOREIGN KEY(source_id) REFERENCES source_registry(source_id));
 CREATE TABLE IF NOT EXISTS player_game_stats(id INTEGER PRIMARY KEY,event_id TEXT NOT NULL,player_id TEXT NOT NULL,team TEXT,minutes REAL,points REAL,rebounds REAL,assists REAL,steals REAL,blocks REAL,turnovers REAL,fga REAL,fgm REAL,fg3a REAL,fg3m REAL,fta REAL,ftm REAL,source_id TEXT,captured_at TEXT,FOREIGN KEY(event_id) REFERENCES games(event_id),FOREIGN KEY(player_id) REFERENCES players(player_id),FOREIGN KEY(source_id) REFERENCES source_registry(source_id));
 CREATE TABLE IF NOT EXISTS rosters(id INTEGER PRIMARY KEY,team_id TEXT NOT NULL,player_id TEXT NOT NULL,valid_from TEXT,valid_to TEXT,status TEXT,captured_at TEXT NOT NULL,source_id TEXT,FOREIGN KEY(team_id) REFERENCES teams(team_id),FOREIGN KEY(player_id) REFERENCES players(player_id),FOREIGN KEY(source_id) REFERENCES source_registry(source_id));
 CREATE TABLE IF NOT EXISTS injuries(id INTEGER PRIMARY KEY,event_id TEXT,player_id TEXT NOT NULL,status TEXT NOT NULL,reason TEXT,probability_to_play REAL,captured_at TEXT NOT NULL,source_id TEXT,FOREIGN KEY(event_id) REFERENCES games(event_id),FOREIGN KEY(player_id) REFERENCES players(player_id),FOREIGN KEY(source_id) REFERENCES source_registry(source_id));
 CREATE TABLE IF NOT EXISTS market_definitions(market_scope TEXT PRIMARY KEY,competition TEXT,season TEXT,gender_level TEXT,market_family TEXT,period TEXT,side TEXT,exact_line TEXT,settlement_rules TEXT,pregame_live TEXT);
 CREATE TABLE IF NOT EXISTS odds_snapshots(id INTEGER PRIMARY KEY,event_id TEXT NOT NULL,market_scope TEXT NOT NULL,operator TEXT NOT NULL,selection TEXT NOT NULL,line TEXT,decimal_odds REAL NOT NULL CHECK(decimal_odds>1),captured_at TEXT NOT NULL,source_id TEXT,rules TEXT,payload_sha256 TEXT,FOREIGN KEY(event_id) REFERENCES games(event_id),FOREIGN KEY(source_id) REFERENCES source_registry(source_id));
 CREATE TABLE IF NOT EXISTS feature_snapshots(id INTEGER PRIMARY KEY,event_id TEXT NOT NULL,scope_token TEXT NOT NULL,feature_json TEXT NOT NULL,feature_time TEXT NOT NULL,source_bundle_sha256 TEXT,FOREIGN KEY(event_id) REFERENCES games(event_id));
 CREATE TABLE IF NOT EXISTS model_runs(model_run_id TEXT PRIMARY KEY,scope_token TEXT NOT NULL,model_name TEXT NOT NULL,model_version TEXT NOT NULL,status TEXT NOT NULL,training_data_sha256 TEXT,created_at TEXT NOT NULL,model_card_path TEXT,model_card_sha256 TEXT,notes TEXT);
 CREATE TABLE IF NOT EXISTS predictions(prediction_id TEXT PRIMARY KEY,event_id TEXT NOT NULL,scope_token TEXT NOT NULL,market TEXT NOT NULL,selection TEXT NOT NULL,line TEXT,probability REAL,probability_lower REAL,decimal_odds REAL,model_run_id TEXT,validation_status TEXT NOT NULL CHECK(validation_status IN ('VALIDATED','EXPLORATORY_NOT_VALIDATED','NO_EVALUABLE','CONDITIONAL','BLOCKED')),decision TEXT NOT NULL CHECK(decision IN ('ACCEPTED','REJECTED','WATCHLIST')),created_at TEXT NOT NULL,data_cutoff_at TEXT,feature_snapshot_at TEXT,notes TEXT,FOREIGN KEY(event_id) REFERENCES games(event_id),FOREIGN KEY(model_run_id) REFERENCES model_runs(model_run_id));
 CREATE TABLE IF NOT EXISTS prediction_settlements(prediction_id TEXT PRIMARY KEY,outcome TEXT NOT NULL CHECK(outcome IN ('WIN','LOSS','PUSH','VOID','HALF_WIN','HALF_LOSS','PENDING')),settled_at TEXT NOT NULL,net_units REAL,evidence TEXT,FOREIGN KEY(prediction_id) REFERENCES predictions(prediction_id));
 CREATE TABLE IF NOT EXISTS model_evaluations(evaluation_id TEXT PRIMARY KEY,model_run_id TEXT NOT NULL,scope_token TEXT NOT NULL,train_start TEXT,train_end TEXT,holdout_start TEXT,holdout_end TEXT,sample_size INTEGER,brier REAL,log_loss REAL,ece REAL,calibration_slope REAL,calibration_intercept REAL,benchmark_brier REAL,status TEXT NOT NULL,report_path TEXT,created_at TEXT NOT NULL,FOREIGN KEY(model_run_id) REFERENCES model_runs(model_run_id));
 CREATE TABLE IF NOT EXISTS audit_logs(audit_id INTEGER PRIMARY KEY,action TEXT NOT NULL,entity_type TEXT NOT NULL,entity_id TEXT,occurred_at TEXT NOT NULL,details_json TEXT);
 CREATE TABLE IF NOT EXISTS coverage_registry(competition TEXT NOT NULL,season TEXT NOT NULL,market_scope TEXT NOT NULL,data_status TEXT NOT NULL,model_status TEXT NOT NULL,validated_status TEXT NOT NULL,sample_size INTEGER NOT NULL DEFAULT 0,last_audited_at TEXT,notes TEXT,PRIMARY KEY(competition,season,market_scope));
 CREATE TABLE IF NOT EXISTS import_log(import_id INTEGER PRIMARY KEY,dataset TEXT NOT NULL,file_name TEXT NOT NULL,file_sha256 TEXT NOT NULL,imported_at TEXT NOT NULL,rows_seen INTEGER NOT NULL,rows_imported INTEGER NOT NULL,status TEXT NOT NULL,details TEXT);
 CREATE TRIGGER IF NOT EXISTS predictions_no_update BEFORE UPDATE ON predictions BEGIN SELECT RAISE(ABORT,'append_only_predictions'); END;
 CREATE TRIGGER IF NOT EXISTS predictions_no_delete BEFORE DELETE ON predictions BEGIN SELECT RAISE(ABORT,'append_only_predictions'); END;
 CREATE TRIGGER IF NOT EXISTS settlements_no_update BEFORE UPDATE ON prediction_settlements BEGIN SELECT RAISE(ABORT,'append_only_settlements'); END;
 CREATE TRIGGER IF NOT EXISTS settlements_no_delete BEFORE DELETE ON prediction_settlements BEGIN SELECT RAISE(ABORT,'append_only_settlements'); END;
 ''')
 if not db.execute('SELECT 1 FROM schema_meta').fetchone(): db.execute('INSERT INTO schema_meta VALUES (?,?)',(VERSION,now()))
 db.commit()
def register_source(db,a):
 db.execute('INSERT INTO source_registry VALUES (?,?,?,?,?,?,?,?)',(a.source_id,a.name,a.type,a.license,int(a.terms_confirmed),a.attribution,now(),a.notes)); db.commit()
 return {'status':'SOURCE_REGISTERED','source_id':a.source_id,'license_status':a.license,'terms_confirmed':a.terms_confirmed}
def register_entity(db,kind,entity_id,name,competition_id=None,source_id=None):
 if kind=='player': db.execute('INSERT INTO players(player_id,player_name,source_id) VALUES (?,?,?)',(entity_id,name,source_id))
 elif kind=='team': db.execute('INSERT INTO teams(team_id,team_name,competition_id,source_id) VALUES (?,?,?,?)',(entity_id,name,competition_id,source_id))
 elif kind=='competition': db.execute('INSERT INTO competitions(competition_id,name,source_id) VALUES (?,?,?)',(entity_id,name,source_id))
 else: raise ValueError('unsupported_entity_kind')
 db.commit(); return {'status':'ENTITY_REGISTERED','kind':kind,'id':entity_id}
def import_csv(db,dataset,file,source_id=None):
 if dataset not in DATASETS: raise ValueError('unsupported_dataset')
 required,table,cols=DATASETS[dataset]; path=Path(file); file_hash=digest(path); seen=0; count=0
 with path.open(encoding='utf-8-sig',newline='') as f:
  r=csv.DictReader(f)
  if not r.fieldnames: raise ValueError('csv_missing_header')
  missing=set(required)-set(r.fieldnames)
  if missing: raise ValueError('csv_missing_columns:'+','.join(sorted(missing)))
  with db:
   for row in r:
    seen+=1; v={k:(row.get(k) or None) for k in cols}
    v['source_id']=source_id or v.get('source_id')
    if dataset=='games':
     timestamp(v['event_time'],'event_time'); v['captured_at']=v['captured_at'] or now(); v['payload_sha256']=v['payload_sha256'] or file_hash
    elif dataset=='team_stats':
     v['captured_at']=v['captured_at'] or now()
     for k in ('possessions','points','fga','fgm','fg3a','fg3m','fta','ftm','oreb','dreb','tov'):
      if v[k] is not None: v[k]=float(v[k])
    elif dataset=='odds':
     timestamp(v['captured_at'],'captured_at'); v['decimal_odds']=float(v['decimal_odds'])
     if not math.isfinite(v['decimal_odds']) or v['decimal_odds']<=1: raise ValueError('decimal_odds_must_be_gt_1')
     v['payload_sha256']=v['payload_sha256'] or file_hash
    else:
     v['captured_at']=v['captured_at'] or now()
     for k in ('minutes','points','rebounds','assists','steals','blocks','turnovers','fga','fgm','fg3a','fg3m','fta','ftm'):
      if v[k] is not None: v[k]=float(v[k])
    db.execute(f"INSERT INTO {table} ({','.join(cols)}) VALUES ({','.join('?' for _ in cols)})",tuple(v.get(k) for k in cols)); count+=1
 db.execute('INSERT INTO import_log(dataset,file_name,file_sha256,imported_at,rows_seen,rows_imported,status,details) VALUES (?,?,?,?,?,?,?,?)',(dataset,path.name,file_hash,now(),seen,count,'IMPORTED',f'source_id={source_id or "unspecified"}')); db.commit()
 return {'status':'IMPORTED','dataset':dataset,'rows_seen':seen,'rows_imported':count,'file_sha256':file_hash,'source_id':source_id}
def log_prediction(db,x):
 required=['prediction_id','event_id','scope_token','market','selection','validation_status','decision','created_at']; missing=set(required)-set(x)
 if missing: raise ValueError('prediction_missing_fields:'+','.join(sorted(missing)))
 t=timestamp(x['created_at'],'created_at')
 for k in ('data_cutoff_at','feature_snapshot_at'):
  if x.get(k): timestamp(x[k],k)
 if x.get('data_cutoff_at') and x.get('feature_snapshot_at') and timestamp(x['data_cutoff_at'],'cutoff')>timestamp(x['feature_snapshot_at'],'feature_time'): raise ValueError('point_in_time_order_invalid')
 if x.get('feature_snapshot_at') and timestamp(x['feature_snapshot_at'],'feature_time')>t: raise ValueError('lookahead_blocked:feature_after_forecast')
 if x.get('data_cutoff_at') and timestamp(x['data_cutoff_at'],'cutoff')>t: raise ValueError('lookahead_blocked:cutoff_after_forecast')
 for k in ('probability','probability_lower'):
  if x.get(k) is not None and not 0<=float(x[k])<=1: raise ValueError(k+'_out_of_range')
 cols=['prediction_id','event_id','scope_token','market','selection','line','probability','probability_lower','decimal_odds','model_run_id','validation_status','decision','created_at','data_cutoff_at','feature_snapshot_at','notes']
 db.execute(f"INSERT INTO predictions ({','.join(cols)}) VALUES ({','.join('?' for _ in cols)})",tuple(x.get(k) for k in cols)); db.commit()
 return {'status':'PREDICTION_RECORDED','prediction_id':x['prediction_id'],'validation_status':x['validation_status']}
def settle(db,a):
 if not db.execute('SELECT 1 FROM predictions WHERE prediction_id=?',(a.prediction_id,)).fetchone(): raise ValueError('prediction_not_found')
 db.execute('INSERT INTO prediction_settlements VALUES (?,?,?,?,?)',(a.prediction_id,a.outcome,now(),a.net_units,a.evidence)); db.commit(); return {'status':'SETTLEMENT_RECORDED','outcome':a.outcome}
def audit(db):
 tables=['competitions','seasons','teams','players','games','team_game_stats','player_game_stats','rosters','injuries','odds_snapshots','predictions','prediction_settlements','source_registry','model_runs','model_evaluations','coverage_registry','audit_logs']
 counts={t:db.execute(f'SELECT COUNT(*) n FROM {t}').fetchone()['n'] for t in tables}
 return {'status':'AUDIT_COMPLETE','schema_version':VERSION,'counts':counts,'network_enabled':False,'providers_configured':0,'note':'Integridad del almacenamiento; no valida precisión predictiva.'}
def main(argv=None):
 p=argparse.ArgumentParser(prog='basketball-edge-v20'); p.add_argument('--db',default='data/basketball_edge_v20.sqlite3'); s=p.add_subparsers(dest='cmd',required=True)
 s.add_parser('init-db')
 q=s.add_parser('register-source'); q.add_argument('--source-id',required=True); q.add_argument('--name',required=True); q.add_argument('--type',default='MANUAL_IMPORT'); q.add_argument('--license',choices=['AUTHORIZED','OPEN_LICENSE','MANUAL_USER_SUPPLIED','UNKNOWN'],default='MANUAL_USER_SUPPLIED'); q.add_argument('--terms-confirmed',action='store_true'); q.add_argument('--attribution',default=''); q.add_argument('--notes',default='')
 q=s.add_parser('register-entity'); q.add_argument('--kind',choices=['competition','team','player'],required=True); q.add_argument('--id',required=True); q.add_argument('--name',required=True); q.add_argument('--competition-id'); q.add_argument('--source-id')
 q=s.add_parser('import-csv'); q.add_argument('--dataset',choices=sorted(DATASETS),required=True); q.add_argument('--file',required=True); q.add_argument('--source-id')
 q=s.add_parser('log-prediction'); q.add_argument('--input',required=True)
 q=s.add_parser('settle-prediction'); q.add_argument('--prediction-id',required=True); q.add_argument('--outcome',choices=['WIN','LOSS','PUSH','VOID','HALF_WIN','HALF_LOSS','PENDING'],required=True); q.add_argument('--net-units',type=float); q.add_argument('--evidence',default='')
 s.add_parser('audit-db'); a=p.parse_args(argv)
 try:
  db=connect(a.db)
  if a.cmd=='init-db': out={'status':'DATABASE_READY','path':str(Path(a.db).resolve()),'schema_version':VERSION}
  elif a.cmd=='register-source': out=register_source(db,a)
  elif a.cmd=='register-entity': out=register_entity(db,a.kind,a.id,a.name,a.competition_id,a.source_id)
  elif a.cmd=='import-csv': out=import_csv(db,a.dataset,a.file,a.source_id)
  elif a.cmd=='log-prediction': out=log_prediction(db,json.loads(Path(a.input).read_text(encoding='utf-8')))
  elif a.cmd=='settle-prediction': out=settle(db,a)
  else: out=audit(db)
  print(json.dumps(out,ensure_ascii=False,indent=2)); db.close(); return 0
 except Exception as e: print(json.dumps({'status':'BLOCKED','error':type(e).__name__,'message':str(e)},ensure_ascii=False)); return 2
if __name__=='__main__': raise SystemExit(main())
