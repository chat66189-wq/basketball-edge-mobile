from __future__ import annotations
import argparse
import json
from pathlib import Path
from typing import Any
from .features import build_feature_snapshot
from .ingestion import JsonProviderClient
from .lineup_scenarios import simulate_lineup_scenarios
from .market_intelligence import audit_market_quotes
from .market_scope import build_market_scope
from .market_profiles import audit_feature_profile
from .settlement import settle_market
from .performance_monitor import audit_forecast_history
from .possession_simulator import simulate_market_scenarios


def _load(path: str) -> dict[str, Any]:
    with open(path,"r",encoding="utf-8") as f: value=json.load(f)
    if not isinstance(value,dict): raise ValueError("input_must_be_json_object")
    return value


def main(argv=None) -> int:
    p=argparse.ArgumentParser(prog="basketball-edge-v19",description="Basketball Edge Analyst v19 research, feature, market, lineup and monitoring tools")
    s=p.add_subparsers(dest="cmd",required=True)
    fs=s.add_parser("feature-snapshot",help="Build point-in-time team features from source-backed game logs")
    fs.add_argument("--input",required=True)
    ln=s.add_parser("lineup-scenarios",help="Simulate availability/minute impact sensitivity from adjusted player impact inputs")
    ln.add_argument("--input",required=True)
    ma=s.add_parser("market-audit",help="Compare exact-scope two-way odds across operators and remove vig")
    ma.add_argument("--input",required=True)
    ps=s.add_parser("possession-sim",help="Run nested possessions/efficiency market scenarios")
    ps.add_argument("--input",required=True)
    sc=s.add_parser("market-scope",help="Build exact validation scope token")
    sc.add_argument("--input",required=True)
    mp=s.add_parser("feature-profile",help="Check that a market-specific starter feature set is included")
    mp.add_argument("--input",required=True)
    st=s.add_parser("settle-market",help="Settle a market with explicit pushes, voids and Asian quarter-lines")
    st.add_argument("--input",required=True)
    pf=s.add_parser("provider-fetch",help="Fetch JSON from a configured official provider endpoint")
    pf.add_argument("--config",required=True); pf.add_argument("--resource",required=True)
    pf.add_argument("--params",default="{}"); pf.add_argument("--output",required=True)
    pf.add_argument("--cache-db",default="data/provider_cache.sqlite"); pf.add_argument("--force-refresh",action="store_true")
    mh=s.add_parser("monitor-history",help="Audit settled forecast history, accepted and rejected picks included")
    mh.add_argument("--input",required=True); mh.add_argument("--config",default=None); mh.add_argument("--output",default=None)
    args=p.parse_args(argv)
    try:
        if args.cmd=="feature-snapshot": out=build_feature_snapshot(_load(args.input))
        elif args.cmd=="lineup-scenarios": out=simulate_lineup_scenarios(_load(args.input))
        elif args.cmd=="market-audit": out=audit_market_quotes(_load(args.input))
        elif args.cmd=="possession-sim": out=simulate_market_scenarios(_load(args.input))
        elif args.cmd=="market-scope": out=build_market_scope(_load(args.input))
        elif args.cmd=="feature-profile": out=audit_feature_profile(_load(args.input))
        elif args.cmd=="settle-market": out=settle_market(_load(args.input))
        elif args.cmd=="provider-fetch":
            params=json.loads(args.params)
            if not isinstance(params,dict): raise ValueError("params_must_be_json_object")
            client=JsonProviderClient.from_file(args.config,args.cache_db)
            out=client.fetch(args.resource,params=params,force_refresh=args.force_refresh).as_dict()
        else:
            cfg=_load(args.config) if args.config else {}
            out=audit_forecast_history(args.input,cfg)
        serialized=json.dumps(out,ensure_ascii=False,indent=2,default=str)
        if getattr(args,"output",None):
            path=Path(args.output); path.parent.mkdir(parents=True,exist_ok=True); path.write_text(serialized+"\n",encoding="utf-8")
        print(serialized)
        return 1 if out.get("status") in {"BLOCKED","SUSPEND_AND_REVIEW","INSUFFICIENT_EVIDENCE","FEATURE_PROFILE_INCOMPLETE"} else 0
    except Exception as exc:
        print(json.dumps({"status":"BLOCKED","error":type(exc).__name__,"message":str(exc)},ensure_ascii=False))
        return 2

if __name__=="__main__":
    raise SystemExit(main())
