"""Nested possession/efficiency simulator with parameter and stress uncertainty.

Outputs are scenario-based projections only. They become eligible probabilities only
when an exact market/competition scope passes model-lab validation and pick-audit.
"""
from __future__ import annotations

import math
import random
from typing import Any


def _t_noise(rng: random.Random, df: float) -> float:
    # Student-t via normal / sqrt(chi-square/df); gamma is chi-square/2.
    z = rng.gauss(0, 1)
    chi2 = 2.0 * rng.gammavariate(df/2.0, 1.0)
    return z / math.sqrt(chi2/df)


def _wilson(wins: int, n: int, z: float = 1.959963984540054):
    if n <= 0:
        return None
    p=wins/n; den=1+z*z/n
    center=(p+z*z/(2*n))/den
    half=z*math.sqrt((p*(1-p)+z*z/(4*n))/n)/den
    return [max(0,center-half), min(1,center+half)]


def _quarter_components(line: float) -> list[float]:
    frac = round(line - math.floor(line), 2)
    if frac not in {0.0, 0.25, 0.5, 0.75}:
        raise ValueError("line_fraction_must_be_quarter_point_or_half_point")
    if frac in {0.25, 0.75}:
        lower = math.floor(line * 2) / 2
        return [lower, lower + 0.5]
    return [line]


def _combine(parts: list[str]) -> str:
    if len(parts) == 1:
        return parts[0]
    wins, losses, pushes = parts.count("WIN"), parts.count("LOSS"), parts.count("PUSH")
    if wins == 2:
        return "WIN"
    if losses == 2:
        return "LOSS"
    if pushes == 2:
        return "PUSH"
    if wins == 1 and pushes == 1:
        return "HALF_WIN"
    if losses == 1 and pushes == 1:
        return "HALF_LOSS"
    if wins == 1 and losses == 1:
        return "HALF_WIN_LOSS_SPLIT"
    raise ValueError("unsupported_asian_settlement_state")


def _compare(value: float, line: float, over: bool) -> str:
    if abs(value - line) < 1e-9:
        return "PUSH"
    won = value > line if over else value < line
    return "WIN" if won else "LOSS"


def _classify_market(market: dict[str, Any], home_score: int, away_score: int) -> str:
    typ = market["type"]
    if typ == "MONEYLINE_HOME":
        return "WIN" if home_score > away_score else "LOSS" if home_score < away_score else "PUSH"
    if typ == "MONEYLINE_AWAY":
        return "WIN" if away_score > home_score else "LOSS" if away_score < home_score else "PUSH"
    line = float(market["line"])
    components = _quarter_components(line)
    if typ in {"SPREAD_HOME", "SPREAD_AWAY"}:
        parts = []
        for component in components:
            margin = (home_score + component - away_score) if typ == "SPREAD_HOME" else (away_score + component - home_score)
            parts.append("WIN" if margin > 1e-9 else "LOSS" if margin < -1e-9 else "PUSH")
        return _combine(parts)
    if typ == "TOTAL_OVER":
        return _combine([_compare(home_score + away_score, component, True) for component in components])
    if typ == "TOTAL_UNDER":
        return _combine([_compare(home_score + away_score, component, False) for component in components])
    if typ == "TEAM_TOTAL_HOME_OVER":
        return _combine([_compare(home_score, component, True) for component in components])
    if typ == "TEAM_TOTAL_HOME_UNDER":
        return _combine([_compare(home_score, component, False) for component in components])
    if typ == "TEAM_TOTAL_AWAY_OVER":
        return _combine([_compare(away_score, component, True) for component in components])
    return _combine([_compare(away_score, component, False) for component in components])


def _overtime_scores(rng: random.Random, possessions_mean: float, home_ppp: float,
                     away_ppp: float, ppp_sd: float, corr: float) -> tuple[int, int]:
    """Simulate repeated five-minute OTs; never resolve a tied game with a coin flip."""
    for _ in range(100):
        ot_possessions = max(1, int(math.floor(rng.gauss(possessions_mean * 5.0 / 48.0,
                                                        max(0.15, math.sqrt(max(0.01, possessions_mean * 5.0 / 48.0))) ) + 0.5)))
        z1, z2 = rng.gauss(0, 1), rng.gauss(0, 1)
        home_eff = max(0.25, home_ppp + ppp_sd * z1)
        away_eff = max(0.25, away_ppp + ppp_sd * (corr * z1 + math.sqrt(1 - corr * corr) * z2))
        hs = max(0, int(math.floor(ot_possessions * home_eff + 0.5)))
        aws = max(0, int(math.floor(ot_possessions * away_eff + 0.5)))
        if hs != aws:
            return hs, aws
    raise RuntimeError("overtime_simulation_failed_to_resolve_after_100_periods")


def simulate_market_scenarios(data: dict[str, Any]) -> dict[str, Any]:
    required = ("home_team", "away_team", "pace_mean", "home_ppp_mean", "away_ppp_mean", "markets")
    missing = [x for x in required if x not in data]
    if missing:
        raise ValueError("missing_fields:" + ",".join(missing))
    n = int(data.get("simulations", 100000))
    if not 10000 <= n <= 1000000:
        raise ValueError("simulations_must_be_10000_to_1000000")
    seed = int(data.get("seed", 20261120))
    rng = random.Random(seed)
    pace = float(data["pace_mean"]); hp = float(data["home_ppp_mean"]); ap = float(data["away_ppp_mean"])
    if not all(math.isfinite(x) and x > 0 for x in (pace, hp, ap)):
        raise ValueError("pace_and_efficiency_means_must_be_finite_and_positive")
    pace_sd = float(data.get("pace_sd", 3.0)); ppp_sd = float(data.get("ppp_sd", 0.075))
    h_se = float(data.get("home_ppp_parameter_se", ppp_sd / math.sqrt(max(1, float(data.get("home_effective_games", 10))))))
    a_se = float(data.get("away_ppp_parameter_se", ppp_sd / math.sqrt(max(1, float(data.get("away_effective_games", 10))))))
    corr = float(data.get("efficiency_residual_correlation", 0.10))
    pace_n = float(data.get("pace_effective_games", 10)); home_n = float(data.get("home_effective_games", 10)); away_n = float(data.get("away_effective_games", 10))
    if not all(math.isfinite(x) and x >= 0 for x in (pace_sd, ppp_sd, h_se, a_se)) or not math.isfinite(corr) or not -0.95 <= corr <= 0.95:
        raise ValueError("invalid_uncertainty_or_correlation")
    if not all(math.isfinite(x) and x > 0 for x in (pace_n, home_n, away_n)):
        raise ValueError("effective_game_counts_must_be_finite_and_positive")
    overtime_rule = data.get("overtime_rule")
    if overtime_rule not in {"INCLUDED", "REGULATION_ONLY"}:
        raise ValueError("overtime_rule_must_be_explicit_INCLUDED_or_REGULATION_ONLY")
    include_ot = overtime_rule == "INCLUDED"
    markets = data["markets"]
    if not isinstance(markets, list) or not markets:
        raise ValueError("markets_must_be_nonempty_list")
    supported = {"MONEYLINE_HOME", "MONEYLINE_AWAY", "SPREAD_HOME", "SPREAD_AWAY", "TOTAL_OVER", "TOTAL_UNDER",
                 "TEAM_TOTAL_HOME_OVER", "TEAM_TOTAL_HOME_UNDER", "TEAM_TOTAL_AWAY_OVER", "TEAM_TOTAL_AWAY_UNDER"}
    market_ids = [str(m.get("market_id", i)) for i, m in enumerate(markets)]
    if len(set(market_ids)) != len(market_ids):
        raise ValueError("market_id_must_be_unique")
    for m in markets:
        if m.get("type") not in supported:
            raise ValueError(f"unsupported_market_type:{m.get('type')}")
        if m["type"] not in {"MONEYLINE_HOME", "MONEYLINE_AWAY"}:
            if "line" not in m or not math.isfinite(float(m["line"])):
                raise ValueError("market_line_must_be_finite_numeric")
            _quarter_components(float(m["line"]))
        if m.get("period", "FULL_GAME") != "FULL_GAME":
            raise ValueError("only_full_game_market_supported_by_this_simulator")
        if m.get("decimal_odds") is not None and (not math.isfinite(float(m["decimal_odds"])) or float(m["decimal_odds"]) <= 1):
            raise ValueError("decimal_odds_must_be_greater_than_1")
    batch_n = int(data.get("parameter_batches", 50))
    if not 10 <= batch_n <= 500:
        raise ValueError("parameter_batches_must_be_10_to_500")
    per_batch = max(1, n // batch_n)
    actual_simulations = per_batch * batch_n
    categories = ("WIN", "LOSS", "PUSH", "HALF_WIN", "HALF_LOSS", "HALF_WIN_LOSS_SPLIT")
    counts = {key: {cat: 0 for cat in categories} for key in market_ids}
    batch_win_probabilities = {key: [] for key in market_ids}
    for _batch in range(batch_n):
        b_pace = max(1.0, rng.gauss(pace, pace_sd / math.sqrt(pace_n)))
        b_hp = max(0.30, hp + _t_noise(rng, 7) * h_se)
        b_ap = max(0.30, ap + _t_noise(rng, 7) * a_se)
        local_counts = {key: {cat: 0 for cat in categories} for key in market_ids}
        for _ in range(per_batch):
            possessions = max(1.0, rng.gauss(b_pace, pace_sd))
            z1, z2 = rng.gauss(0, 1), rng.gauss(0, 1)
            h_eff = max(0.25, b_hp + ppp_sd * z1)
            a_eff = max(0.25, b_ap + ppp_sd * (corr * z1 + math.sqrt(1 - corr * corr) * z2))
            home_score = max(0, int(math.floor(possessions * h_eff + 0.5)))
            away_score = max(0, int(math.floor(possessions * a_eff + 0.5)))
            if include_ot and home_score == away_score:
                ot_h, ot_a = _overtime_scores(rng, possessions, h_eff, a_eff, ppp_sd, corr)
                home_score += ot_h; away_score += ot_a
            for index, market in enumerate(markets):
                key = str(market.get("market_id", index))
                result = _classify_market(market, home_score, away_score)
                local_counts[key][result] += 1
        for key in market_ids:
            for category in categories:
                counts[key][category] += local_counts[key][category]
            batch_win_probabilities[key].append(local_counts[key]["WIN"] / per_batch)
    summaries = []
    for i, market in enumerate(markets):
        key = str(market.get("market_id", i)); c = counts[key]
        full_wins = c["WIN"]; half_wins = c["HALF_WIN"]
        full_losses = c["LOSS"]; pushes = c["PUSH"]
        probs = batch_win_probabilities[key]
        sorted_probs = sorted(probs)
        q = lambda frac: sorted_probs[min(len(sorted_probs)-1, int(frac*(len(sorted_probs)-1)))]
        outcome_probabilities = {category: c[category] / actual_simulations for category in categories}
        row = {"market_id": key, "market_type": market["type"], "line": market.get("line"),
               "decimal_odds": market.get("decimal_odds"),
               "settlement_rule": "FULL_AND_SPLIT_SETTLEMENT_CATEGORIES_REPORTED_SEPARATELY",
               "effective_simulations": actual_simulations,
               "outcome_counts": c, "outcome_probabilities": outcome_probabilities,
               "scenario_probability_mean": outcome_probabilities["WIN"],
               "win_equivalent_probability": (full_wins + 0.5 * half_wins) / actual_simulations,
               "conditional_full_win_probability_excluding_full_push_and_loss": (full_wins / (full_wins + full_losses) if full_wins + full_losses else None),
               "push_probability": outcome_probabilities["PUSH"],
               "monte_carlo_wilson_95": _wilson(full_wins, actual_simulations),
               "parameter_scenario_probability_range": {"p10": q(.10), "median": q(.50), "p90": q(.90)},
               "status": "EXPLORATORY_NOT_VALIDATED"}
        odds = market.get("decimal_odds")
        if odds is not None:
            odds = float(odds)
            profit = {"WIN": odds - 1, "LOSS": -1, "PUSH": 0, "HALF_WIN": (odds - 1)/2,
                      "HALF_LOSS": -0.5, "HALF_WIN_LOSS_SPLIT": (odds - 2)/2}
            row["expected_net_units_per_unit_stake"] = sum(outcome_probabilities[k] * profit[k] for k in categories)
        summaries.append(row)
    return {"status": "EXPLORATORY_NOT_VALIDATED", "home_team": data["home_team"], "away_team": data["away_team"],
            "simulations_requested": n, "simulations_executed": actual_simulations, "parameter_batches": batch_n, "markets": summaries,
            "assumptions": {"pace_mean": pace, "home_ppp_mean": hp, "away_ppp_mean": ap, "pace_sd": pace_sd,
                            "ppp_sd": ppp_sd, "parameter_standard_errors": {"home_ppp": h_se, "away_ppp": a_se},
                            "effective_games": {"pace": pace_n, "home": home_n, "away": away_n},
                            "efficiency_residual_correlation": corr, "overtime_rule": overtime_rule},
            "warnings": ["The reported win probability is unconditional: pushes and split settlements remain separate outcomes.",
                         "Monte Carlo Wilson intervals quantify simulation error only, not predictive uncertainty.",
                         "Parameter-batch p10/p90 is a sensitivity range under supplied assumptions, not a calibrated confidence interval.",
                         "Overtime repeats five-minute periods until a winner exists; this approximation still requires exact-scope backtesting.",
                         "Quarter-point lines are settled as two equal half-stakes; pushes are not counted as wins.",
                         "No output is eligible for betting without an approved exact-scope model card and pick-audit."]}
