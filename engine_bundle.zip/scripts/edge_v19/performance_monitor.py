"""Prospective/rolling forecast monitoring from immutable, settled prediction exports."""
from __future__ import annotations

import csv
import json
import math
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from typing import Any

REQUIRED = ("event_id", "event_time", "forecast_created_at", "competition", "season",
            "market_scope", "model_version", "probability", "market_probability", "outcome", "decision")


def wilson_interval(successes: int, n: int, z: float = 1.959963984540054) -> tuple[float, float] | None:
    if n <= 0 or successes < 0 or successes > n:
        return None
    p = successes/n
    den = 1+z*z/n
    center = (p+z*z/(2*n))/den
    half = z*math.sqrt((p*(1-p)+z*z/(4*n))/n)/den
    return max(0, center-half), min(1, center+half)


def _metrics(rows: list[dict[str, Any]]) -> dict[str, Any]:
    n = len(rows)
    if n == 0:
        return {"n": 0}
    eps = 1e-12
    p = [r["probability"] for r in rows]
    m = [r["market_probability"] for r in rows]
    y = [r["outcome"] for r in rows]
    brier = sum((a-b)**2 for a,b in zip(p,y))/n
    def ll(probs):
        return -sum(yy*math.log(max(eps, pp))+(1-yy)*math.log(max(eps,1-pp)) for yy,pp in zip(y,probs))/n
    buckets = []
    ece = 0.0
    for lo, hi in ((0,.5),(.5,.6),(.6,.7),(.7,.8),(.8,.9),(.9,1.000001)):
        idx = [i for i,pp in enumerate(p) if lo <= pp < hi]
        if idx:
            mean_p = sum(p[i] for i in idx)/len(idx)
            observed = sum(y[i] for i in idx)/len(idx)
            ece += len(idx)/n*abs(mean_p-observed)
            buckets.append({"lower":lo,"upper":hi,"n":len(idx),"mean_probability":mean_p,
                            "observed_hit_rate":observed,
                            "hit_rate_wilson_95":wilson_interval(sum(y[i] for i in idx),len(idx))})
    high = [r for r in rows if r["probability"] >= .80]
    wins = sum(r["outcome"] for r in rows)
    priced = [r for r in rows if r.get("odds_taken") is not None]
    roi = None
    if priced:
        roi = sum((r["odds_taken"]-1.0) if r["outcome"] else -1.0 for r in priced)/len(priced)
    clv_rows = [r for r in rows if r.get("market_probability_at_take") is not None and r.get("closing_market_probability") is not None]
    clv = (sum(r["closing_market_probability"]-r["market_probability_at_take"] for r in clv_rows)/len(clv_rows)
           if clv_rows else None)
    return {"n":n,"hit_rate":wins/n,"hit_rate_wilson_95":wilson_interval(wins,n),
            "brier":brier,"market_brier":sum((a-b)**2 for a,b in zip(m,y))/n,
            "log_loss":ll(p),"market_log_loss":ll(m),"ece":ece,"buckets":buckets,
            "flat_stake_roi":roi,"roi_sample_n":len(priced),"mean_clv_probability_points":clv,
            "clv_sample_n":len(clv_rows),
            "high_confidence":{"n":len(high),"hit_rate":(sum(r["outcome"] for r in high)/len(high) if high else None),
                               "hit_rate_wilson_95":wilson_interval(sum(r["outcome"] for r in high),len(high))}}


def audit_forecast_history(csv_path: str | Path, config: dict[str, Any]) -> dict[str, Any]:
    with open(csv_path, "r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        missing = [c for c in REQUIRED if c not in (reader.fieldnames or [])]
        if missing:
            raise ValueError("missing_monitor_columns:"+",".join(missing))
        records = list(reader)
    if not records:
        raise ValueError("monitor_history_empty")
    seen = set()
    groups = defaultdict(list)
    accepted_groups = defaultdict(list)
    errors = []
    for i,r in enumerate(records, start=2):
        try:
            event_id = r["event_id"].strip()
            unique = (r["competition"],r["season"],r["market_scope"],r["model_version"],event_id)
            if not event_id or unique in seen:
                raise ValueError("duplicate_or_missing_event_id_in_scope")
            seen.add(unique)
            event = datetime.fromisoformat(r["event_time"].replace("Z","+00:00"))
            created = datetime.fromisoformat(r["forecast_created_at"].replace("Z","+00:00"))
            if event.tzinfo is None or event.utcoffset() is None or created.tzinfo is None or created.utcoffset() is None or created >= event:
                raise ValueError("forecast_must_be_timezone_aware_and_pre_event")
            row = dict(r)
            row["_event_dt"] = event
            for f in ("probability","market_probability"):
                row[f] = float(r[f])
                if not math.isfinite(row[f]) or not 0 < row[f] < 1:
                    raise ValueError(f"invalid_{f}")
            row["outcome"] = int(r["outcome"])
            if row["outcome"] not in (0,1):
                raise ValueError("outcome_must_be_0_or_1")
            decision = r["decision"].strip().upper()
            if decision not in {"ACCEPTED","REJECTED","CONDITIONAL","NO_PICK"}:
                raise ValueError("invalid_decision")
            row["decision"] = decision
            row["odds_taken"] = None
            if r.get("odds_taken", "").strip():
                row["odds_taken"] = float(r["odds_taken"])
                if not math.isfinite(row["odds_taken"]) or row["odds_taken"] <= 1.0:
                    raise ValueError("odds_taken_must_be_finite_decimal_gt_1")
                if not r.get("odds_taken_captured_at", "").strip():
                    raise ValueError("odds_taken_requires_capture_timestamp")
                odds_time=datetime.fromisoformat(r["odds_taken_captured_at"].replace("Z","+00:00"))
                if odds_time.tzinfo is None or odds_time.utcoffset() is None or odds_time>created:
                    raise ValueError("odds_taken_timestamp_must_be_aware_and_no_later_than_forecast")
                if (created-odds_time).total_seconds()/60 > float(config.get("max_odds_age_minutes",10)):
                    raise ValueError("odds_taken_quote_stale_at_forecast")
            for f in ("market_probability_at_take", "closing_market_probability"):
                row[f] = None
                if r.get(f, "").strip():
                    row[f] = float(r[f])
                    if not math.isfinite(row[f]) or not 0 < row[f] < 1:
                        raise ValueError(f"invalid_{f}")
            if (row["market_probability_at_take"] is None) != (row["closing_market_probability"] is None):
                raise ValueError("clv_requires_both_taken_and_closing_market_probabilities")
            if row["market_probability_at_take"] is not None:
                for field_name, must_be_after in (("market_probability_at_take_captured_at", False),
                                                  ("closing_market_probability_captured_at", True)):
                    if not r.get(field_name, "").strip():
                        raise ValueError(f"clv_requires_{field_name}")
                    capture=datetime.fromisoformat(r[field_name].replace("Z","+00:00"))
                    if capture.tzinfo is None or capture.utcoffset() is None:
                        raise ValueError(f"{field_name}_must_be_timezone_aware")
                    if must_be_after and not (created < capture < event):
                        raise ValueError("closing_market_capture_must_be_after_forecast_and_before_event")
                    if not must_be_after and capture > created:
                        raise ValueError("taken_market_capture_must_be_no_later_than_forecast")
            key = (r["competition"],r["season"],r["market_scope"],r["model_version"])
            groups[key].append(row)
            if decision == "ACCEPTED":
                accepted_groups[key].append(row)
        except Exception as exc:
            errors.append(f"row_{i}:{exc}")
    if errors:
        raise ValueError("monitor_integrity_errors:"+"|".join(errors[:20]))
    minimum = int(config.get("min_settled_predictions",200))
    min_accepted = int(config.get("min_accepted_predictions",100))
    results=[]
    any_suspend=False
    for key, rows in sorted(groups.items()):
        rows.sort(key=lambda x:x["_event_dt"])
        accepted=accepted_groups[key]
        all_metrics=_metrics(rows)
        accepted_metrics=_metrics(accepted)
        latest_n=int(config.get("recent_window",100))
        recent=_metrics(rows[-latest_n:])
        status="INSUFFICIENT_EVIDENCE"
        reasons=[]
        if len(rows)>=minimum and len(accepted)>=min_accepted:
            status="CONTINUE_PAPER_OR_CONTROLLED"
            if all_metrics["brier"] >= all_metrics["market_brier"]:
                status="SUSPEND_AND_REVIEW"
                reasons.append("overall_brier_not_better_than_market_baseline")
            if all_metrics["log_loss"] > all_metrics["market_log_loss"] + float(config.get("max_log_loss_degradation",0.005)):
                status="SUSPEND_AND_REVIEW"
                reasons.append("overall_log_loss_degraded_vs_market")
            hc=accepted_metrics.get("high_confidence",{})
            hc_interval=hc.get("hit_rate_wilson_95")
            if hc["n"] >= int(config.get("min_high_confidence_n",50)) and hc_interval and hc_interval[0] < float(config.get("min_high_confidence_lower_bound",0.75)):
                status="SUSPEND_AND_REVIEW"
                reasons.append("accepted_high_confidence_subset_below_wilson_floor")
            if recent.get("n",0)>=int(config.get("min_recent_n",50)) and recent["brier"] > recent["market_brier"]:
                status="SUSPEND_AND_REVIEW"
                reasons.append("recent_rolling_brier_worse_than_market")
        else:
            reasons.append("not_enough_settled_records_for_release_decision")
        if status=="SUSPEND_AND_REVIEW": any_suspend=True
        results.append({"scope":{"competition":key[0],"season":key[1],"market_scope":key[2],"model_version":key[3]},
                        "status":status,"all_candidates":all_metrics,"accepted_only":accepted_metrics,
                        "recent_window":recent,"reasons":reasons})
    return {"status":"SUSPEND_AND_REVIEW" if any_suspend else ("MONITORING_EVIDENCE_AVAILABLE" if results else "NO_DATA"),
            "scopes":results,
            "policy":"Monitoring can suspend a model; it cannot promote a model or guarantee future hit rate.",
            "note":"Include accepted and rejected candidate decisions. The accepted-only view is reported separately to avoid selection bias."}
