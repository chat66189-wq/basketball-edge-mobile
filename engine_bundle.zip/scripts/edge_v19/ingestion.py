"""Configured, auditable HTTP/JSON ingestion; no provider endpoints are invented.

A provider is queryable only when the user configures its official endpoint,
confirms licensing/terms, and (when required) supplies credentials. Raw payloads
are cached and captured with timestamps and hashes for point-in-time auditing.
"""
from __future__ import annotations

import hashlib
import json
import os
import random
import sqlite3
import time
import urllib.error
import urllib.parse
import urllib.request
import threading
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ALLOWED_LICENSE_STATES = {"AUTHORIZED", "OPEN_LICENSE", "MANUAL_USER_SUPPLIED"}


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _canonical_hash(value: Any) -> str:
    raw = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _host(url: str) -> str:
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme != "https" and parsed.hostname not in {"localhost", "127.0.0.1"}:
        raise ValueError("provider_endpoint_must_use_https")
    if not parsed.hostname:
        raise ValueError("provider_endpoint_missing_hostname")
    return parsed.hostname.lower()


@dataclass(frozen=True)
class FetchResult:
    provider_id: str
    resource: str
    requested_at: str
    retrieved_at: str
    status_code: int
    payload: Any
    payload_sha256: str
    source_url: str
    cache_hit: bool
    license_status: str
    capture_id: int | None = None

    def as_dict(self) -> dict[str, Any]:
        return {
            "provider_id": self.provider_id, "resource": self.resource,
            "requested_at": self.requested_at, "retrieved_at": self.retrieved_at,
            "status_code": self.status_code, "payload": self.payload,
            "payload_sha256": self.payload_sha256, "source_url": self.source_url,
            "cache_hit": self.cache_hit, "license_status": self.license_status,
            "capture_id": self.capture_id,
        }


class JsonProviderClient:
    def __init__(self, config: dict[str, Any], cache_db: str | Path = "data/provider_cache.sqlite"):
        self.config = config
        self.cache_db = Path(cache_db)
        self._last_request_monotonic = 0.0
        self._request_lock = threading.Lock()
        self._validate_config()
        self.cache_db.parent.mkdir(parents=True, exist_ok=True)
        self._init_cache()

    @classmethod
    def from_file(cls, path: str | Path, cache_db: str | Path = "data/provider_cache.sqlite") -> "JsonProviderClient":
        with open(path, "r", encoding="utf-8") as handle:
            config = json.load(handle)
        if not isinstance(config, dict):
            raise ValueError("provider_config_must_be_object")
        return cls(config, cache_db)

    def _validate_config(self) -> None:
        c = self.config
        for key in ("provider_id", "base_url", "license_status", "terms_confirmed", "endpoints"):
            if key not in c:
                raise ValueError(f"provider_config_missing:{key}")
        if c["license_status"] not in ALLOWED_LICENSE_STATES:
            raise ValueError("provider_license_not_authorized_or_verified")
        if c["terms_confirmed"] is not True:
            raise ValueError("provider_terms_must_be_explicitly_confirmed")
        if not isinstance(c["endpoints"], dict) or not c["endpoints"]:
            raise ValueError("provider_endpoints_must_be_nonempty_object")
        base = str(c["base_url"]).rstrip("/") + "/"
        _host(base)
        allowed = {str(x).lower() for x in c.get("allowed_hosts", [])}
        allowed.add(_host(base))
        if not allowed:
            raise ValueError("provider_allowed_hosts_empty")
        for resource, endpoint in c["endpoints"].items():
            if not isinstance(endpoint, str) or not endpoint.strip():
                raise ValueError(f"invalid_endpoint:{resource}")
            full = urllib.parse.urljoin(base, endpoint)
            if _host(full) not in allowed:
                raise ValueError(f"endpoint_host_not_allowlisted:{resource}")
        timeout = float(c.get("timeout_seconds", 15))
        if not 1 <= timeout <= 90:
            raise ValueError("timeout_seconds_must_be_1_to_90")
        max_bytes = int(c.get("max_response_bytes", 20_000_000))
        if not 1024 <= max_bytes <= 100_000_000:
            raise ValueError("max_response_bytes_must_be_1KB_to_100MB")
        interval = float(c.get("minimum_interval_seconds", 0.0))
        if not 0 <= interval <= 120:
            raise ValueError("minimum_interval_seconds_must_be_0_to_120")
        if int(c.get("max_retries", 2)) not in range(0, 6):
            raise ValueError("max_retries_must_be_0_to_5")

    def _init_cache(self) -> None:
        with sqlite3.connect(self.cache_db) as db:
            db.execute("""CREATE TABLE IF NOT EXISTS response_cache (
                cache_key TEXT PRIMARY KEY, provider_id TEXT NOT NULL, resource TEXT NOT NULL,
                captured_at TEXT NOT NULL, expires_at REAL NOT NULL, source_url TEXT NOT NULL,
                status_code INTEGER NOT NULL, payload_json TEXT NOT NULL, payload_sha256 TEXT NOT NULL)""")
            db.execute("""CREATE TABLE IF NOT EXISTS source_capture (
                capture_id INTEGER PRIMARY KEY AUTOINCREMENT, provider_id TEXT NOT NULL, resource TEXT NOT NULL,
                requested_at TEXT NOT NULL, captured_at TEXT NOT NULL, source_url TEXT NOT NULL,
                status_code INTEGER NOT NULL, payload_json TEXT NOT NULL, payload_sha256 TEXT NOT NULL,
                license_status TEXT NOT NULL)""")
            db.execute("CREATE TRIGGER IF NOT EXISTS source_capture_no_update BEFORE UPDATE ON source_capture BEGIN SELECT RAISE(ABORT,'append_only_source_capture'); END")
            db.execute("CREATE TRIGGER IF NOT EXISTS source_capture_no_delete BEFORE DELETE ON source_capture BEGIN SELECT RAISE(ABORT,'append_only_source_capture'); END")

    def _redact_url(self, url: str) -> str:
        parsed = urllib.parse.urlparse(url)
        sensitive = {"key", "api_key", "token", "access_token", "secret", "auth", "authorization"}
        query = urllib.parse.parse_qsl(parsed.query, keep_blank_values=True)
        safe = [(k, "REDACTED" if k.lower() in sensitive else v) for k, v in query]
        return urllib.parse.urlunparse(parsed._replace(query=urllib.parse.urlencode(safe)))

    def _cache_key(self, resource: str, url: str) -> str:
        return _canonical_hash({"provider": self.config["provider_id"], "resource": resource, "url": url})

    def fetch(self, resource: str, *, params: dict[str, Any] | None = None,
              now: str | None = None, force_refresh: bool = False) -> FetchResult:
        if resource not in self.config["endpoints"]:
            raise ValueError(f"resource_not_configured:{resource}")
        requested_at = now or _utc_now()
        try:
            requested_dt = datetime.fromisoformat(requested_at.replace("Z", "+00:00"))
        except ValueError as exc:
            raise ValueError("requested_at_invalid_timestamp") from exc
        if requested_dt.tzinfo is None or requested_dt.utcoffset() is None:
            raise ValueError("requested_at_must_be_timezone_aware")
        base = str(self.config["base_url"]).rstrip("/") + "/"
        path = str(self.config["endpoints"][resource]).format(**(params or {}))
        url = urllib.parse.urljoin(base, path)
        query = (params or {}).get("query", {})
        if query:
            if not isinstance(query, dict):
                raise ValueError("params.query_must_be_object")
            url += ("&" if "?" in url else "?") + urllib.parse.urlencode(query, doseq=True)
        allowed = {str(x).lower() for x in self.config.get("allowed_hosts", [])}
        allowed.add(_host(base))
        if _host(url) not in allowed:
            raise ValueError("resolved_url_host_not_allowlisted")
        key = self._cache_key(resource, url)
        now_epoch = time.time()
        if not force_refresh:
            with sqlite3.connect(self.cache_db) as db:
                row = db.execute("SELECT captured_at,source_url,status_code,payload_json,payload_sha256,expires_at FROM response_cache WHERE cache_key=?", (key,)).fetchone()
            if row and row[5] > now_epoch:
                with sqlite3.connect(self.cache_db) as db:
                    cap = db.execute("SELECT capture_id FROM source_capture WHERE provider_id=? AND resource=? AND captured_at=? AND payload_sha256=? ORDER BY capture_id DESC LIMIT 1",
                                     (self.config["provider_id"], resource, row[0], row[4])).fetchone()
                return FetchResult(self.config["provider_id"], resource, requested_at, row[0], row[2],
                                   json.loads(row[3]), row[4], row[1], True, self.config["license_status"],
                                   int(cap[0]) if cap else None)

        headers = {"Accept": "application/json", "User-Agent": "BasketballEdgeAnalyst/19.0"}
        api_key_env = self.config.get("api_key_env")
        if api_key_env:
            token = os.getenv(str(api_key_env))
            if not token:
                raise ValueError(f"provider_api_key_missing_environment_variable:{api_key_env}")
            header_name = str(self.config.get("auth_header", "Authorization"))
            prefix = str(self.config.get("auth_prefix", "Bearer "))
            headers[header_name] = prefix + token
        for name, env_name in self.config.get("extra_headers_env", {}).items():
            value = os.getenv(str(env_name))
            if not value:
                raise ValueError(f"provider_header_missing_environment_variable:{env_name}")
            headers[str(name)] = value

        req = urllib.request.Request(url, headers=headers, method="GET")
        minimum_interval = max(0.0, float(self.config.get("minimum_interval_seconds", 0.0)))
        with self._request_lock:
            elapsed = time.monotonic() - self._last_request_monotonic
            if elapsed < minimum_interval:
                time.sleep(minimum_interval - elapsed)
            self._last_request_monotonic = time.monotonic()
        retries = int(self.config.get("max_retries", 2))
        timeout = float(self.config.get("timeout_seconds", 15))
        response_body = None
        status = 0
        for attempt in range(retries + 1):
            try:
                with urllib.request.urlopen(req, timeout=timeout) as response:
                    status = int(response.status)
                    response_body = response.read(int(self.config.get("max_response_bytes", 20_000_000)) + 1)
                    if len(response_body) > int(self.config.get("max_response_bytes", 20_000_000)):
                        raise ValueError("provider_response_exceeds_max_response_bytes")
                break
            except urllib.error.HTTPError as exc:
                status = int(exc.code)
                if status not in (429, 500, 502, 503, 504) or attempt >= retries:
                    raise RuntimeError(f"provider_http_error:{status}") from exc
                retry_after = exc.headers.get("Retry-After")
                delay = min(20.0, float(retry_after)) if retry_after and retry_after.isdigit() else min(8.0, 0.5 * (2 ** attempt) + random.random() * 0.2)
                time.sleep(delay)
            except (urllib.error.URLError, TimeoutError) as exc:
                if attempt >= retries:
                    raise RuntimeError(f"provider_transport_error:{type(exc).__name__}") from exc
                time.sleep(min(8.0, 0.5 * (2 ** attempt) + random.random() * 0.2))
        if response_body is None:
            raise RuntimeError("provider_empty_response")
        try:
            payload = json.loads(response_body.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ValueError("provider_response_not_valid_json") from exc
        captured_at = _utc_now()
        digest = _canonical_hash(payload)
        cache_seconds = max(0, int(self.config.get("cache_ttl_seconds", 60)))
        payload_json = json.dumps(payload, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
        redacted_url = self._redact_url(url)
        with sqlite3.connect(self.cache_db) as db:
            db.execute("INSERT OR REPLACE INTO response_cache VALUES (?,?,?,?,?,?,?,?,?)",
                       (key, self.config["provider_id"], resource, captured_at, now_epoch + cache_seconds,
                        redacted_url, status, payload_json, digest))
            cur = db.execute("INSERT INTO source_capture (provider_id,resource,requested_at,captured_at,source_url,status_code,payload_json,payload_sha256,license_status) VALUES (?,?,?,?,?,?,?,?,?)",
                             (self.config["provider_id"], resource, requested_at, captured_at, redacted_url,
                              status, payload_json, digest, self.config["license_status"]))
            capture_id = int(cur.lastrowid)
        return FetchResult(self.config["provider_id"], resource, requested_at, captured_at, status,
                           payload, digest, redacted_url, False, self.config["license_status"], capture_id)
