"""Availability/minute uncertainty scenarios using externally validated adjusted impact inputs.

This is a sensitivity engine, not a causal player-value estimator. It refuses raw +/-
without provenance and never labels scenario outputs as calibrated win probabilities.
"""
from __future__ import annotations

import math
import random
from typing import Any
from datetime import datetime


def _aware_time(value: str, field: str) -> datetime:
    try:
        dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError as exc:
        raise ValueError(f"{field}_invalid_timestamp") from exc
    if dt.tzinfo is None or dt.utcoffset() is None:
        raise ValueError(f"{field}_must_be_timezone_aware")
    return dt


def simulate_lineup_scenarios(data: dict[str, Any]) -> dict[str, Any]:
    required = ("team", "competition", "event_time", "forecast_created_at", "game_minutes", "players")
    missing = [k for k in required if k not in data]
    if missing:
        raise ValueError("missing_fields:" + ",".join(missing))
    forecast_created = _aware_time(data["forecast_created_at"], "forecast_created_at")
    event_time = _aware_time(data["event_time"], "event_time")
    if forecast_created >= event_time:
        raise ValueError("forecast_must_precede_event")
    game_minutes = float(data["game_minutes"])
    if not 32 <= game_minutes <= 60:
        raise ValueError("game_minutes_out_of_supported_range")
    players = data["players"]
    if not isinstance(players, list) or len(players) < 5:
        raise ValueError("at_least_five_rotation_players_required")
    simulations = int(data.get("simulations", 50000))
    if not 1000 <= simulations <= 250000:
        raise ValueError("simulations_must_be_1000_to_250000")
    rng = random.Random(int(data.get("seed", 20261120)))
    impact_prior = float(data.get("impact_prior_minutes", 4000))
    if not math.isfinite(impact_prior) or impact_prior <= 0:
        raise ValueError("impact_prior_minutes_must_be_finite_and_positive")
    missing_fields = []
    normalized = []
    seen = set()
    for i, row in enumerate(players):
        pid = str(row.get("player_id", "")).strip()
        if not pid or pid in seen:
            raise ValueError(f"player_{i}_id_missing_or_duplicate")
        seen.add(pid)
        for field in ("status", "expected_minutes", "minute_sd", "impact_per_100", "impact_metric_type",
                      "impact_sample_minutes", "replacement_impact_per_100", "impact_captured_at",
                      "status_captured_at", "minutes_captured_at", "impact_source_id",
                      "impact_metric_scope", "impact_model_version", "status_source_id", "minutes_source_id"):
            if field not in row:
                missing_fields.append(f"{pid}:{field}")
        if row.get("impact_metric_type") not in {"RAPM", "EPM", "DARKO", "VALIDATED_LINEUP_MODEL"}:
            raise ValueError(f"{pid}:impact_metric_must_be_adjusted_impact_not_raw_plus_minus")
        for provenance_field in ("impact_source_id", "impact_metric_scope", "impact_model_version",
                                 "status_source_id", "minutes_source_id"):
            if not str(row.get(provenance_field, "")).strip():
                raise ValueError(f"{pid}:{provenance_field}_must_be_nonempty")
        for timestamp_field in ("impact_captured_at", "status_captured_at", "minutes_captured_at"):
            if row.get(timestamp_field):
                captured = _aware_time(row[timestamp_field], f"{pid}:{timestamp_field}")
                if captured > forecast_created:
                    raise ValueError(f"{pid}:{timestamp_field}_is_after_forecast_creation")
        status = str(row.get("status", "UNKNOWN")).upper()
        if status not in {"AVAILABLE", "OUT", "QUESTIONABLE", "PROBABLE", "DOUBTFUL"}:
            raise ValueError(f"{pid}:unknown_availability_status_blocks_projection")
        mean = float(row.get("expected_minutes", 0))
        sd = float(row.get("minute_sd", 0))
        sample = float(row.get("impact_sample_minutes", 0))
        if not all(math.isfinite(x) for x in (mean, sd, sample)) or min(mean, sd, sample) < 0 or mean > game_minutes + 1e-6:
            raise ValueError(f"{pid}:invalid_minute_or_sample_values")
        prob = float(row.get("availability_probability", 1.0 if status in {"AVAILABLE", "PROBABLE"} else 0.0 if status in {"OUT", "DOUBTFUL"} else -1))
        if status in {"QUESTIONABLE", "DOUBTFUL"} and not 0 <= prob <= 1:
            raise ValueError(f"{pid}:questionable_status_requires_availability_probability")
        if status == "AVAILABLE": prob = 1.0
        if status == "OUT": prob = 0.0
        if status == "PROBABLE": prob = max(prob, 0.85)
        impact = float(row["impact_per_100"])
        replacement = float(row["replacement_impact_per_100"])
        if not all(math.isfinite(x) for x in (impact, replacement, prob)):
            raise ValueError(f"{pid}:non_finite_input")
        # Shrink noisy impact estimates toward replacement. 4,000 minutes is a
        # conservative prior-equivalent scale; this is a sensitivity convention.
        shrink = sample / (sample + impact_prior)
        adjusted = replacement + shrink * (impact - replacement)
        normalized.append({"id": pid, "status": status, "mean": mean, "sd": sd,
                           "availability": prob, "impact": adjusted, "replacement": replacement,
                           "shrinkage": shrink, "sample": sample})
    if missing_fields:
        raise ValueError("missing_player_evidence:" + ",".join(missing_fields[:30]))
    expected_total = sum(p["mean"] * p["availability"] for p in normalized)
    target_total = 5.0 * game_minutes
    if expected_total < target_total * 0.70 or expected_total > target_total * 1.30:
        raise ValueError("projected_rotation_minutes_not_coherent_with_five_player_court_time")
    impacts = []
    allocated_team_minutes = []
    availability_counts = {"available": 0, "questionable_or_doubtful": 0, "out": 0}
    for p in normalized:
        if p["status"] in {"AVAILABLE", "PROBABLE"}: availability_counts["available"] += 1
        elif p["status"] in {"QUESTIONABLE", "DOUBTFUL"}: availability_counts["questionable_or_doubtful"] += 1
        else: availability_counts["out"] += 1
    for _ in range(simulations):
        raw_minutes = []
        for p in normalized:
            if rng.random() > p["availability"]:
                raw_minutes.append(0.0)
            else:
                m = max(0.0, rng.gauss(p["mean"], p["sd"]))
                raw_minutes.append(min(game_minutes, m))
        active = [i for i, minutes in enumerate(raw_minutes) if minutes > 1e-9]
        if len(active) < 5:
            continue
        # Allocate exactly five-player court time while respecting the per-player
        # game-minute cap. Scale-then-clip can silently lose minutes and bias impact.
        allocation = [0.0] * len(raw_minutes)
        remaining = target_total
        open_indices = set(active)
        while open_indices and remaining > 1e-8:
            weight_sum = sum(raw_minutes[i] for i in open_indices)
            if weight_sum <= 1e-12:
                break
            proposed = {i: remaining * raw_minutes[i] / weight_sum for i in open_indices}
            saturated = [i for i, value in proposed.items() if value >= game_minutes - 1e-9]
            if not saturated:
                for i, value in proposed.items():
                    allocation[i] = value
                remaining = 0.0
                break
            for i in saturated:
                allocation[i] = game_minutes
                remaining -= game_minutes
                open_indices.remove(i)
        if remaining > 1e-6:
            continue
        raw_minutes = allocation
        allocated_team_minutes.append(sum(raw_minutes))
        # Team net impact relative to replacement. The metric is not necessarily additive;
        # outputs are scenario sensitivities only and must be prospectively validated.
        impact = sum((m / game_minutes) * (p["impact"] - p["replacement"])
                     for m, p in zip(raw_minutes, normalized))
        impacts.append(impact)
    if len(impacts) < simulations * 0.90:
        return {"status": "BLOCKED", "reason": "too_many_scenarios_without_available_rotation",
                "valid_scenarios": len(impacts), "requested_scenarios": simulations}
    impacts.sort()
    def quantile(q: float) -> float:
        idx = min(len(impacts)-1, max(0, int(q*(len(impacts)-1))))
        return impacts[idx]
    return {
        "status": "SCENARIO_SENSITIVITY_ONLY",
        "team": data["team"], "event_time": data["event_time"], "forecast_created_at": data["forecast_created_at"],
        "valid_scenarios": len(impacts), "requested_scenarios": simulations,
        "projected_team_player_minutes_mean": sum(allocated_team_minutes) / len(allocated_team_minutes),
        "projected_team_player_minutes_min": min(allocated_team_minutes),
        "projected_team_player_minutes_max": max(allocated_team_minutes),
        "availability_counts": availability_counts,
        "net_rating_impact_per_100": {"mean": sum(impacts)/len(impacts), "p05": quantile(.05),
                                       "p50": quantile(.50), "p95": quantile(.95)},
        "players": [{"player_id": p["id"], "availability_probability": p["availability"],
                     "adjusted_impact": p["impact"], "shrinkage": p["shrinkage"],
                     "impact_sample_minutes": p["sample"]} for p in normalized],
        "provenance": [{"player_id": row["player_id"], "impact_source_id": row["impact_source_id"],
                        "impact_metric_scope": row["impact_metric_scope"], "impact_model_version": row["impact_model_version"],
                        "status_source_id": row["status_source_id"], "minutes_source_id": row["minutes_source_id"]}
                       for row in players],
        "warnings": ["Impact metrics must be point-in-time and independently sourced.",
                     "RAPM/EPM/DARKO are not automatically causal; minute-weighted player effects may overlap.",
                     "Do not add this output directly to a win probability without training and validating the mapping.",
                     "Unknown injury status, raw +/- or missing minute distributions must block use."],
    }
