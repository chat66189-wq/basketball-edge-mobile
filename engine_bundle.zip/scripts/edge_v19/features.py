"""Point-in-time basketball feature engineering for team form, Four Factors and schedule context."""
from __future__ import annotations

import math
from datetime import datetime, date, timezone, timedelta
from typing import Any


def _dt(value: str, field: str) -> datetime:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field}_missing")
    raw = value.strip().replace("Z", "+00:00")
    try:
        if len(raw) == 10:
            d = date.fromisoformat(raw)
            return datetime(d.year, d.month, d.day, tzinfo=timezone.utc)
        out = datetime.fromisoformat(raw)
    except ValueError as exc:
        raise ValueError(f"{field}_invalid_iso8601") from exc
    if out.tzinfo is None or out.utcoffset() is None:
        raise ValueError(f"{field}_must_be_timezone_aware")
    return out


def _available(row: dict[str, Any]) -> datetime:
    raw = str(row.get("available_at") or row.get("game_date", ""))
    # A date-only publication timestamp is deliberately available only from
    # the following UTC day, even when stored in an available_at field.
    if len(raw.strip()) == 10:
        d = date.fromisoformat(raw.strip())
        return datetime(d.year, d.month, d.day, tzinfo=timezone.utc) + timedelta(days=1)
    return _dt(raw, "available_at" if row.get("available_at") else "game_date")


def _haversine_km(a: tuple[float, float], b: tuple[float, float]) -> float:
    lat1, lon1, lat2, lon2 = map(math.radians, (a[0], a[1], b[0], b[1]))
    dlat, dlon = lat2-lat1, lon2-lon1
    h = math.sin(dlat/2)**2 + math.cos(lat1)*math.cos(lat2)*math.sin(dlon/2)**2
    return 6371.0088 * 2 * math.asin(min(1.0, math.sqrt(h)))


def _mean(rows: list[dict[str, Any]], key: str, default: float | None = None) -> float | None:
    vals = [float(r[key]) for r in rows if r.get(key) not in (None, "")]
    return sum(vals)/len(vals) if vals else default


def _weighted_mean(rows: list[dict[str, Any]], key: str, cutoff: datetime, half_life_days: float) -> float | None:
    pairs = []
    for row in rows:
        value = row.get(key)
        if value in (None, ""):
            continue
        played = row.get("_played_at") or _dt(str(row.get("tipoff_at") or row.get("game_date")), "game_date")
        age = max(0.0, (cutoff-played).total_seconds()/86400)
        weight = math.exp(-math.log(2)*age/half_life_days)
        pairs.append((float(value), weight))
    den = sum(w for _, w in pairs)
    return sum(v*w for v,w in pairs)/den if den else None


def _team_history(history: list[dict[str, Any]], team: str, cutoff: datetime) -> list[dict[str, Any]]:
    eligible = []
    for row in history:
        if str(row.get("team")) != team:
            continue
        played = row.get("_played_at") or _dt(str(row.get("tipoff_at") or row.get("game_date")), "game_date")
        available = _available(row)
        if played < cutoff and available <= cutoff:
            eligible.append(dict(row, _played_at=played))
    return sorted(eligible, key=lambda r: r["_played_at"])


def _summarize_team(rows: list[dict[str, Any]], cutoff: datetime, windows=(5,10,20)) -> dict[str, Any]:
    out: dict[str, Any] = {"games_total": len(rows)}
    for window in windows:
        sample = rows[-window:]
        n = len(sample)
        out[f"games_last_{window}"] = n
        if not sample:
            for metric in ("pace", "off_ppp", "def_ppp", "net_ppp", "efg", "tov_rate", "oreb_rate", "ft_rate"):
                out[f"{metric}_last_{window}"] = None
            continue
        out[f"pace_last_{window}"] = _weighted_mean(sample, "possessions", cutoff, 45.0)
        out[f"off_ppp_last_{window}"] = _weighted_mean(sample, "off_ppp", cutoff, 45.0)
        out[f"def_ppp_last_{window}"] = _weighted_mean(sample, "def_ppp", cutoff, 45.0)
        out[f"net_ppp_last_{window}"] = (out[f"off_ppp_last_{window}"] - out[f"def_ppp_last_{window}"]
                                               if out[f"off_ppp_last_{window}"] is not None and out[f"def_ppp_last_{window}"] is not None else None)
        for source, target in (("efg_pct", "efg"), ("turnover_rate", "tov_rate"),
                               ("offensive_rebound_rate", "oreb_rate"), ("free_throw_rate", "ft_rate")):
            out[f"{target}_last_{window}"] = _weighted_mean(sample, source, cutoff, 45.0)
    if rows:
        last = rows[-1]
        rest = (cutoff-last["_played_at"]).total_seconds()/86400
        out["rest_days"] = max(0.0, rest)
        out["back_to_back"] = int(rest < 1.5)
        out["games_last_7_days"] = sum((cutoff-r["_played_at"]).total_seconds() <= 7*86400 for r in rows)
        out["games_last_14_days"] = sum((cutoff-r["_played_at"]).total_seconds() <= 14*86400 for r in rows)
    else:
        out.update({"rest_days": None, "back_to_back": None, "games_last_7_days": 0, "games_last_14_days": 0})
    # Home/away splits are descriptive only; consumers must shrink small samples.
    for home_flag, label in ((True, "home"), (False, "away")):
        split = [r for r in rows if bool(r.get("is_home")) is home_flag]
        out[f"{label}_split_n"] = len(split)
        out[f"{label}_off_ppp"] = _weighted_mean(split[-20:], "off_ppp", cutoff, 90.0)
        out[f"{label}_def_ppp"] = _weighted_mean(split[-20:], "def_ppp", cutoff, 90.0)
    return out


def build_feature_snapshot(data: dict[str, Any]) -> dict[str, Any]:
    """Build one match feature row using strictly pre-cutoff historical team logs.

    Each history row needs team, opponent, game_date or tipoff_at, points_for,
    points_against, possessions and either available_at or date-only availability.
    Optional Four Factors must be point-in-time source fields.
    """
    required = ("as_of", "event_time", "home_team", "away_team", "history")
    missing = [k for k in required if k not in data]
    if missing:
        raise ValueError("missing_fields:" + ",".join(missing))
    cutoff = _dt(str(data["as_of"]), "as_of")
    event_time = _dt(str(data["event_time"]), "event_time")
    if cutoff >= event_time:
        raise ValueError("feature_cutoff_must_precede_event")
    history = data["history"]
    if not isinstance(history, list) or not history:
        raise ValueError("history_must_be_nonempty_list")
    valid = []
    for idx, row in enumerate(history):
        if not isinstance(row, dict):
            raise ValueError(f"history_row_{idx}_must_be_object")
        for key in ("team", "opponent", "points_for", "points_against", "possessions", "is_home"):
            if key not in row:
                raise ValueError(f"history_row_{idx}_missing_{key}")
        if not isinstance(row["is_home"], bool):
            raise ValueError(f"history_row_{idx}_is_home_must_be_boolean")
        possessions = float(row["possessions"])
        if possessions <= 0:
            raise ValueError(f"history_row_{idx}_invalid_possessions")
        played = row.get("_played_at") or _dt(str(row.get("tipoff_at") or row.get("game_date")), "game_date")
        available = _available(row)
        if played >= cutoff or available > cutoff:
            continue
        r = dict(row)
        r["_played_at"] = played
        r["off_ppp"] = float(row["points_for"])/possessions
        r["def_ppp"] = float(row["points_against"])/possessions
        valid.append(r)
    home_rows = _team_history(valid, str(data["home_team"]), cutoff)
    away_rows = _team_history(valid, str(data["away_team"]), cutoff)
    home = _summarize_team(home_rows, cutoff)
    away = _summarize_team(away_rows, cutoff)
    features: dict[str, float | int | None] = {}
    for side, summary in (("home", home), ("away", away)):
        for key, value in summary.items():
            features[f"{side}_{key}"] = value
    for metric in ("pace_last_5", "pace_last_10", "pace_last_20", "off_ppp_last_5", "off_ppp_last_10",
                   "off_ppp_last_20", "def_ppp_last_5", "def_ppp_last_10", "def_ppp_last_20",
                   "net_ppp_last_5", "net_ppp_last_10", "net_ppp_last_20"):
        h, a = home.get(metric), away.get(metric)
        features[f"diff_{metric}"] = h-a if h is not None and a is not None else None
    # Travel is emitted only when the caller supplies verified prior venue coordinates.
    travel = {"home_travel_km": None, "away_travel_km": None}
    target = data.get("target_venue_coordinates")
    if target:
        for team, label, team_rows in ((data["home_team"], "home", home_rows), (data["away_team"], "away", away_rows)):
            coords = data.get("team_last_venue_coordinates", {}).get(str(team))
            if coords and len(coords) == 2:
                travel[f"{label}_travel_km"] = _haversine_km(tuple(map(float, coords)), tuple(map(float, target)))
    features.update(travel)
    return {
        "status": "FEATURE_SNAPSHOT_READY" if home_rows and away_rows else "INSUFFICIENT_HISTORY",
        "scope": {"competition": data.get("competition"), "season": data.get("season"),
                  "market_scope": data.get("market_scope")},
        "event_time": event_time.isoformat(), "feature_snapshot_at": cutoff.isoformat(),
        "home_team": str(data["home_team"]), "away_team": str(data["away_team"]),
        "home_history_n": len(home_rows), "away_history_n": len(away_rows),
        "features": features,
        "warnings": ["Rolling form, home/away splits and schedule density are features, not calibrated predictions.",
                     "Small home/away samples require shrinkage and exact-scope validation.",
                     "Travel is omitted unless verified venue coordinates are provided."],
    }
