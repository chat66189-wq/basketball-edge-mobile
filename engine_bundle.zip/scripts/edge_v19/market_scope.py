"""Canonical exact-scope construction; prevents accidental calibration transfer."""
from __future__ import annotations

import math
import re
from typing import Any

ALLOWED_FAMILIES = {"MONEYLINE", "SPREAD", "TOTAL", "TEAM_TOTAL", "PLAYER_PROP"}
ALLOWED_PERIODS = {"FULL_GAME", "FIRST_HALF", "SECOND_HALF", "FIRST_QUARTER", "SECOND_QUARTER",
                   "THIRD_QUARTER", "FOURTH_QUARTER", "FIRST_5_MINUTES", "CUSTOM"}
ALLOWED_STATES = {"PREMATCH", "LIVE"}
SELECTIONS = {
    "MONEYLINE": {"HOME", "AWAY"},
    "SPREAD": {"HOME", "AWAY"},
    "TOTAL": {"OVER", "UNDER"},
    "TEAM_TOTAL": {"HOME_OVER", "HOME_UNDER", "AWAY_OVER", "AWAY_UNDER"},
    "PLAYER_PROP": {"OVER", "UNDER"},
}


def _line_token(value: Any) -> str:
    if isinstance(value, bool):
        raise ValueError("line_value_must_be_numeric")
    try:
        number = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError("line_value_must_be_numeric") from exc
    if not math.isfinite(number):
        raise ValueError("line_value_must_be_finite")
    return format(number, ".6f").rstrip("0").rstrip(".")


def build_market_scope(data: dict[str, Any]) -> dict[str, Any]:
    required = ("competition", "season", "sex_category", "level", "market_family", "period",
                "line_rule", "game_state", "selection")
    missing = [k for k in required if not str(data.get(k, "")).strip()]
    if missing:
        raise ValueError("market_scope_missing:" + ",".join(missing))
    family = str(data["market_family"]).upper()
    period = str(data["period"]).upper()
    state = str(data["game_state"]).upper()
    sex = str(data["sex_category"]).upper()
    selection = str(data["selection"]).upper()
    if family not in ALLOWED_FAMILIES:
        raise ValueError("unsupported_market_family")
    if period not in ALLOWED_PERIODS:
        raise ValueError("unsupported_period")
    if state not in ALLOWED_STATES:
        raise ValueError("game_state_must_be_PREMATCH_or_LIVE")
    if sex not in {"M", "F", "MIXED", "UNKNOWN"}:
        raise ValueError("sex_category_invalid")
    if selection not in SELECTIONS[family]:
        raise ValueError(f"selection_invalid_for_{family.lower()}")
    line_value = None
    if family == "MONEYLINE":
        if data.get("line_value") not in (None, "", "NONE"):
            raise ValueError("moneyline_must_not_have_line_value")
    else:
        if data.get("line_value") in (None, ""):
            raise ValueError("exact_line_value_required_for_spread_total_and_props")
        line_value = _line_token(data["line_value"])
    prop_stat = None
    player_scope = None
    if family == "PLAYER_PROP":
        if not str(data.get("prop_stat", "")).strip():
            raise ValueError("player_prop_requires_exact_prop_stat")
        if not str(data.get("player_scope", "")).strip():
            raise ValueError("player_prop_requires_player_scope_or_explicit_pooled_population")
        prop_stat = re.sub(r"\s+", "_", str(data["prop_stat"]).strip().upper())
        player_scope = re.sub(r"\s+", "_", str(data["player_scope"]).strip().upper())
    pieces = [str(data[k]).strip() for k in ("competition", "season")]
    pieces += [sex, str(data["level"]).strip().upper(), family, period,
               re.sub(r"\s+", "_", str(data["line_rule"]).strip().upper()), selection,
               line_value if line_value is not None else "NO_LINE", state]
    if prop_stat:
        pieces.extend([prop_stat, player_scope])
    token = "::".join(pieces)
    if len(token) > 512:
        raise ValueError("market_scope_token_too_long")
    return {"market_scope": token, "scope_components": {
        "competition": data["competition"], "season": data["season"], "sex_category": sex,
        "level": data["level"], "market_family": family, "period": period,
        "line_rule": data["line_rule"], "selection": selection,
        "line_value": line_value, "game_state": state, "prop_stat": prop_stat, "player_scope": player_scope,
    }, "warning": "The scope token is a validation boundary, not evidence that this model has passed validation."}
