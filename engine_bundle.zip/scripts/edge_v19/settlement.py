"""Market settlement labels with explicit push/void/quarter-line handling.

Binary model training includes only clean wins/losses. Pushes, voids and split
Asian settlements are kept out of binary classification labels.
"""
from __future__ import annotations

import math
from typing import Any


def _finite(value: Any, name: str) -> float:
    try: x=float(value)
    except (TypeError,ValueError) as exc: raise ValueError(f"{name}_must_be_numeric") from exc
    if not math.isfinite(x): raise ValueError(f"{name}_must_be_finite")
    return x


def _compare(value: float, line: float, over: bool) -> str:
    if abs(value-line) < 1e-9: return "PUSH"
    wins = value > line if over else value < line
    return "WIN" if wins else "LOSS"


def _quarter_components(line: float) -> list[float]:
    frac = round(line - math.floor(line), 2)
    if frac not in {0.0, 0.25, 0.5, 0.75}:
        raise ValueError("line_fraction_must_be_quarter_point_or_half_point")
    if frac in {0.25, 0.75}:
        lower = math.floor(line*2)/2
        upper = lower + 0.5
        return [lower, upper]
    return [line]


def _combine(parts: list[str]) -> str:
    if len(parts)==1: return parts[0]
    wins=parts.count("WIN"); losses=parts.count("LOSS"); pushes=parts.count("PUSH")
    if wins==2: return "WIN"
    if losses==2: return "LOSS"
    if pushes==2: return "PUSH"
    if wins==1 and pushes==1: return "HALF_WIN"
    if losses==1 and pushes==1: return "HALF_LOSS"
    if wins==1 and losses==1: return "HALF_WIN_LOSS_SPLIT"  # one half won, one half lost: net -0.25 unit at ordinary odds not binary
    raise ValueError("unsupported_asian_settlement_state")


def settle_market(data: dict[str, Any]) -> dict[str, Any]:
    required=("market_family","selection","line_rule","settlement_status")
    missing=[k for k in required if k not in data]
    if missing: raise ValueError("missing_fields:"+",".join(missing))
    family=str(data["market_family"]).upper(); selection=str(data["selection"]).upper()
    status=str(data["settlement_status"]).upper()
    if status=="VOID":
        result="VOID"; parts=[]
    elif status!="SETTLED":
        raise ValueError("settlement_status_must_be_SETTLED_or_VOID")
    else:
        if family in {"MONEYLINE","SPREAD","TOTAL","TEAM_TOTAL"}:
            overtime=str(data.get("overtime_rule","")).upper()
            if overtime not in {"INCLUDED","REGULATION_ONLY"}:
                raise ValueError("team_market_requires_explicit_overtime_rule")
            if overtime=="INCLUDED":
                h=_finite(data.get("final_home_score"),"final_home_score")
                a=_finite(data.get("final_away_score"),"final_away_score")
            else:
                h=_finite(data.get("regulation_home_score"),"regulation_home_score")
                a=_finite(data.get("regulation_away_score"),"regulation_away_score")
        if family=="MONEYLINE":
            if selection not in {"HOME","AWAY"}: raise ValueError("moneyline_selection_must_be_HOME_or_AWAY")
            diff=(h-a) if selection=="HOME" else (a-h)
            result="WIN" if diff>0 else "LOSS" if diff<0 else "PUSH"
            parts=[result]
        elif family=="SPREAD":
            if selection not in {"HOME","AWAY"}: raise ValueError("spread_selection_must_be_HOME_or_AWAY")
            line=_finite(data.get("line_value"),"line_value")
            line_parts=_quarter_components(line)
            parts=[]
            for part in line_parts:
                margin=(h+part-a) if selection=="HOME" else (a+part-h)
                parts.append("WIN" if margin>1e-9 else "LOSS" if margin<-1e-9 else "PUSH")
            result=_combine(parts)
        elif family=="TOTAL":
            if selection not in {"OVER","UNDER"}: raise ValueError("total_selection_must_be_OVER_or_UNDER")
            line=_finite(data.get("line_value"),"line_value")
            total=h+a; line_parts=_quarter_components(line)
            parts=[_compare(total,part,selection=="OVER") for part in line_parts]
            result=_combine(parts)
        elif family=="TEAM_TOTAL":
            if selection not in {"HOME_OVER","HOME_UNDER","AWAY_OVER","AWAY_UNDER"}:
                raise ValueError("team_total_selection_invalid")
            line=_finite(data.get("line_value"),"line_value")
            score=h if selection.startswith("HOME") else a
            over=selection.endswith("OVER")
            line_parts=_quarter_components(line)
            parts=[_compare(score,part,over) for part in line_parts]
            result=_combine(parts)
        elif family=="PLAYER_PROP":
            if selection not in {"OVER","UNDER"}: raise ValueError("player_prop_selection_must_be_OVER_or_UNDER")
            stat=_finite(data.get("player_stat"),"player_stat")
            line=_finite(data.get("line_value"),"line_value")
            line_parts=_quarter_components(line)
            parts=[_compare(stat,part,selection=="OVER") for part in line_parts]
            result=_combine(parts)
        else:
            raise ValueError("unsupported_market_family")
    binary=result in {"WIN","LOSS"}
    odds=None if data.get("decimal_odds") in (None,"") else _finite(data["decimal_odds"],"decimal_odds")
    if odds is not None and odds<=1: raise ValueError("decimal_odds_must_be_greater_than_1")
    net_profit=None
    if odds is not None:
        net_profit={"WIN":odds-1,"LOSS":-1,"PUSH":0,"HALF_WIN":(odds-1)/2,
                    "HALF_LOSS":-0.5,"HALF_WIN_LOSS_SPLIT":(odds-1)/2-0.5,"VOID":0}[result]
    outcome=1 if result=="WIN" else 0 if result=="LOSS" else None
    return {"settlement_result":result,"component_results":parts,"binary_training_eligible":binary,
            "binary_outcome":outcome,"net_profit_per_unit_stake":net_profit,
            "policy":"Only WIN/LOSS become 1/0 for binary model training. PUSH, VOID and split Asian results stay separate.",
            "market_family":family,"selection":selection,"line_value":data.get("line_value"),
            "line_rule":data["line_rule"],"overtime_rule":data.get("overtime_rule")}
