"""Market-specific feature-profile gate for preparing exact-scope model-lab datasets."""
from __future__ import annotations
from typing import Any

BASE_TEAM = {
    "home_games_last_10", "away_games_last_10",
    "home_off_ppp_last_10", "home_def_ppp_last_10",
    "away_off_ppp_last_10", "away_def_ppp_last_10",
    "home_rest_days", "away_rest_days",
}
PROFILES = {
    "MONEYLINE": BASE_TEAM | {"home_net_ppp_last_10", "away_net_ppp_last_10", "diff_net_ppp_last_10"},
    "SPREAD": BASE_TEAM | {"diff_net_ppp_last_5", "diff_net_ppp_last_10", "diff_net_ppp_last_20",
                            "home_pace_last_10", "away_pace_last_10"},
    "TOTAL": {"home_pace_last_10", "away_pace_last_10", "home_off_ppp_last_10", "away_off_ppp_last_10",
              "home_def_ppp_last_10", "away_def_ppp_last_10", "diff_pace_last_10"},
    "TEAM_TOTAL": {"home_pace_last_10", "away_pace_last_10", "home_off_ppp_last_10", "away_off_ppp_last_10",
                   "home_def_ppp_last_10", "away_def_ppp_last_10"},
    "PLAYER_PROP": {"projected_minutes_mean", "projected_minutes_sd", "usage_rate", "stat_rate_per_minute",
                     "opponent_position_allowance", "player_role_stability", "teammate_availability_impact"},
}


def audit_feature_profile(data: dict[str, Any]) -> dict[str, Any]:
    family=str(data.get("market_family","")).upper()
    if family not in PROFILES:
        raise ValueError("unsupported_market_family")
    columns=data.get("feature_columns")
    if not isinstance(columns,list) or not all(isinstance(c,str) and c for c in columns):
        raise ValueError("feature_columns_must_be_nonempty_string_list")
    observed=set(columns)
    required=PROFILES[family]
    missing=sorted(required-observed)
    extras=sorted(observed-required)
    return {"status":"FEATURE_PROFILE_PASS" if not missing else "FEATURE_PROFILE_INCOMPLETE",
            "market_family":family,"required_feature_columns":sorted(required),
            "provided_feature_columns":sorted(observed),"missing_feature_columns":missing,
            "additional_feature_columns":extras,
            "warning":"This checks the presence of a starter feature set only. It does not authenticate data, prove predictive value or replace walk-forward validation."}
