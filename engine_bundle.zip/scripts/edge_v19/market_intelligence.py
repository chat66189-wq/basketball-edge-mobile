"""Multi-operator odds consensus, vig removal, freshness and movement audit (two-way markets)."""
from __future__ import annotations

import math
import statistics
from datetime import datetime
from typing import Any


def _dt(value: str) -> datetime:
    dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    if dt.tzinfo is None or dt.utcoffset() is None:
        raise ValueError("odds_timestamp_must_be_timezone_aware")
    return dt


def _no_vig(a: float, b: float) -> tuple[float, float, float]:
    if not all(math.isfinite(x) and x > 1.0 for x in (a, b)):
        raise ValueError("decimal_odds_must_be_finite_and_greater_than_1")
    ia, ib = 1/a, 1/b
    total = ia + ib
    return ia/total, ib/total, total-1


def audit_market_quotes(data: dict[str, Any]) -> dict[str, Any]:
    for field in ("market_scope", "event_id", "as_of", "event_time", "quotes"):
        if field not in data:
            raise ValueError(f"missing_field:{field}")
    as_of = _dt(data["as_of"])
    event_time = _dt(data["event_time"])
    if as_of >= event_time:
        raise ValueError("market_audit_as_of_must_precede_event")
    max_age = float(data.get("max_quote_age_minutes", 10))
    if not math.isfinite(max_age) or max_age <= 0:
        raise ValueError("max_quote_age_minutes_must_be_finite_and_positive")
    rows = data["quotes"]
    if not isinstance(rows, list) or not rows:
        raise ValueError("quotes_must_be_nonempty_list")
    seen = set()
    clean = []
    errors = []
    for i, q in enumerate(rows):
        try:
            for key in ("operator", "captured_at", "selected_odds", "opposite_odds", "market_scope", "event_id"):
                if key not in q:
                    raise ValueError(f"missing_{key}")
            if q["market_scope"] != data["market_scope"] or q["event_id"] != data["event_id"]:
                raise ValueError("event_or_market_scope_mismatch")
            operator = str(q["operator"]).strip()
            if not operator or operator in seen:
                raise ValueError("operator_missing_or_duplicate_latest_quote")
            seen.add(operator)
            captured = _dt(q["captured_at"])
            age = (as_of-captured).total_seconds()/60
            if age < 0 or age > max_age:
                raise ValueError("quote_stale_or_captured_after_as_of")
            p, op, vig = _no_vig(float(q["selected_odds"]), float(q["opposite_odds"]))
            clean.append({"operator": operator, "captured_at": captured, "age_minutes": age,
                          "selected_odds": float(q["selected_odds"]), "opposite_odds": float(q["opposite_odds"]),
                          "p_selected_no_vig": p, "p_opposite_no_vig": op, "overround": vig})
        except Exception as exc:
            errors.append(f"quote_{i}:{exc}")
    if errors:
        return {"status": "BLOCKED", "errors": errors, "market_scope": data["market_scope"], "event_id": data["event_id"]}
    ps = [q["p_selected_no_vig"] for q in clean]
    selected_prices = [q["selected_odds"] for q in clean]
    newest = max(q["captured_at"] for q in clean)
    oldest = min(q["captured_at"] for q in clean)
    best_idx = max(range(len(clean)), key=lambda i: selected_prices[i])
    best_opposite_idx = max(range(len(clean)), key=lambda i: clean[i]["opposite_odds"])
    dispersion = max(ps)-min(ps)
    warnings = []
    if len(clean) < int(data.get("min_operators", 3)):
        warnings.append("fewer_than_required_independent_operators")
    if dispersion > float(data.get("max_probability_dispersion", 0.08)):
        warnings.append("operator_probability_dispersion_high_research_required")
    if statistics.mean(q["overround"] for q in clean) > float(data.get("max_mean_overround", 0.12)):
        warnings.append("market_mean_overround_high")
    market_consensus = statistics.median(ps)
    # Use median probability to resist a single anomalous operator; return range for uncertainty.
    movement = None
    if data.get("opening_quotes"):
        open_rows = []
        opening_operators = set()
        for i, q in enumerate(data["opening_quotes"]):
            if q.get("market_scope") != data["market_scope"] or q.get("event_id") != data["event_id"]:
                raise ValueError(f"opening_quote_{i}_event_or_scope_mismatch")
            if not q.get("captured_at") or not q.get("operator"):
                raise ValueError(f"opening_quote_{i}_missing_operator_or_timestamp")
            captured = _dt(q["captured_at"])
            if not captured < as_of:
                raise ValueError(f"opening_quote_{i}_must_precede_as_of")
            current_for_operator = next((row for row in clean if row["operator"] == q["operator"]), None)
            if current_for_operator and not captured < current_for_operator["captured_at"]:
                raise ValueError(f"opening_quote_{i}_must_precede_current_quote")
            if q["operator"] in opening_operators:
                raise ValueError("duplicate_operator_in_opening_quotes")
            opening_operators.add(q["operator"])
            open_rows.append(q)
        if open_rows:
            opening_ps = [_no_vig(float(q["selected_odds"]), float(q["opposite_odds"]))[0] for q in open_rows]
            movement = {"opening_consensus_no_vig": statistics.median(opening_ps),
                        "current_consensus_no_vig": market_consensus,
                        "probability_point_move": market_consensus-statistics.median(opening_ps),
                        "opening_operator_count":len(open_rows)}
    return {
        "status": "MARKET_REFERENCE_READY" if len(clean) >= int(data.get("min_operators", 3)) and not warnings else "CONDITIONAL",
        "event_id": data["event_id"], "market_scope": data["market_scope"],
        "operator_count": len(clean), "operators": [q["operator"] for q in clean],
        "consensus_no_vig_probability_selected": market_consensus,
        "probability_range": [min(ps), max(ps)], "probability_dispersion": dispersion,
        "best_selected_price": {"operator": clean[best_idx]["operator"], "odds": selected_prices[best_idx]},
        "best_opposite_price": {"operator": clean[best_opposite_idx]["operator"], "odds": clean[best_opposite_idx]["opposite_odds"]},
        "mean_overround": statistics.mean(q["overround"] for q in clean),
        "freshness": {"newest_capture": newest.isoformat(), "oldest_capture": oldest.isoformat(),
                      "max_age_minutes": max(q["age_minutes"] for q in clean)},
        "opening_to_current": movement, "operator_quotes": clean and [
            {k: (v.isoformat() if isinstance(v, datetime) else v) for k,v in q.items()} for q in clean],
        "warnings": warnings + ["Operator consensus is a market benchmark, not proof of the true probability.",
                                "Operator independence and quote authenticity must be verified outside this function."],
    }
