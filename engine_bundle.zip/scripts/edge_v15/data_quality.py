from __future__ import annotations

from dataclasses import dataclass, asdict
from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import Iterable
import hashlib
import json

from .common import parse_datetime


class DataStatus(str, Enum):
    PASS = "PASS"
    CONDITIONAL = "CONDITIONAL"
    BLOCKED = "BLOCKED"


@dataclass(frozen=True)
class SourceRecord:
    provider: str
    source_type: str
    captured_at: str
    retrieved_at: str
    license_status: str
    authority_level: int
    payload: dict
    url: str | None = None
    ttl_minutes: int = 1440

    def validate(self) -> list[str]:
        errors: list[str] = []
        if not self.provider.strip(): errors.append("provider_missing")
        if not self.source_type.strip(): errors.append("source_type_missing")
        if self.license_status not in {"AUTHORIZED", "OPEN_LICENSE", "MANUAL_USER_SUPPLIED", "UNKNOWN", "PROHIBITED"}:
            errors.append("license_status_invalid")
        if self.license_status == "PROHIBITED": errors.append("source_use_prohibited")
        if not 1 <= self.authority_level <= 5: errors.append("authority_level_out_of_range")
        if self.ttl_minutes <= 0: errors.append("ttl_must_be_positive")
        try:
            captured = parse_datetime(self.captured_at)
            retrieved = parse_datetime(self.retrieved_at)
            if captured > retrieved + timedelta(minutes=5):
                errors.append("capture_time_in_future_of_retrieval")
        except (TypeError, ValueError):
            errors.append("invalid_or_timezone_naive_timestamp")
        if not isinstance(self.payload, dict) or not self.payload:
            errors.append("payload_missing")
        return errors

    def freshness(self, now: str | datetime) -> tuple[bool, float]:
        now_dt = parse_datetime(now)
        captured = parse_datetime(self.captured_at)
        age = max(0.0, (now_dt - captured).total_seconds() / 60.0)
        return age <= self.ttl_minutes, age

    def payload_sha256(self) -> str:
        packed = json.dumps(self.payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        return hashlib.sha256(packed.encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class QualityReport:
    status: DataStatus
    errors: tuple[str, ...]
    warnings: tuple[str, ...]
    source_hashes: tuple[str, ...]


def assess_sources(sources: Iterable[SourceRecord], now: str | datetime) -> QualityReport:
    errors: list[str] = []
    warnings: list[str] = []
    hashes: list[str] = []
    items = list(sources)
    if not items:
        errors.append("no_sources")
    for index, source in enumerate(items):
        errors.extend(f"source[{index}]:{x}" for x in source.validate())
        if source.validate():
            continue
        fresh, age = source.freshness(now)
        hashes.append(source.payload_sha256())
        if not fresh:
            warnings.append(f"source[{index}]:stale:{age:.1f}m")
        if source.license_status == "UNKNOWN":
            warnings.append(f"source[{index}]:license_unverified")
        if source.authority_level >= 4:
            warnings.append(f"source[{index}]:low_authority")
    if errors:
        status = DataStatus.BLOCKED
    elif warnings:
        status = DataStatus.CONDITIONAL
    else:
        status = DataStatus.PASS
    return QualityReport(status, tuple(errors), tuple(warnings), tuple(hashes))


def validate_point_in_time(*, event_at: str | datetime, forecast_created_at: str | datetime,
                           data_cutoff_at: str | datetime) -> tuple[bool, tuple[str, ...]]:
    event = parse_datetime(event_at)
    created = parse_datetime(forecast_created_at)
    cutoff = parse_datetime(data_cutoff_at)
    errors = []
    if created >= event:
        errors.append("forecast_not_created_before_event")
    if cutoff >= event:
        errors.append("data_cutoff_not_before_event")
    if cutoff > created:
        errors.append("data_cutoff_after_forecast_creation")
    return not errors, tuple(errors)
