"""Strict, accuracy-first decision gates for Basketball Edge Analyst v17.

These gates do not predict winners. They reject recommendations whose evidence,
market scope, calibration, uncertainty, or execution details are insufficient.
"""
from __future__ import annotations

from datetime import datetime
import math
import re
from typing import Any


def _timestamp(value: Any, field: str) -> datetime:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field}_missing")
    parsed = datetime.fromisoformat(value.strip().replace("Z", "+00:00"))
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ValueError(f"{field}_must_include_timezone")
    return parsed


def _number(value: Any, field: str, *, minimum: float | None = None,
            maximum: float | None = None) -> float:
    try:
        result = float(value)
    except (TypeError, ValueError):
        raise ValueError(f"{field}_missing_or_not_numeric")
    if not math.isfinite(result):
        raise ValueError(f"{field}_not_finite")
    if minimum is not None and result < minimum:
        raise ValueError(f"{field}_below_minimum_{minimum}")
    if maximum is not None and result > maximum:
        raise ValueError(f"{field}_above_maximum_{maximum}")
    return result


def evaluate_pick_gate(packet: dict[str, Any], *, min_leg_lower_probability: float = 0.80,
                       min_test_predictions: int = 300, min_test_events: int = 200,
                       min_walk_forward_splits: int = 5, max_quote_age_minutes: float = 10.0,
                       min_edge_over_market: float = 0.01) -> dict[str, Any]:
    """Evaluate one pick against strict, predeclared v17 eligibility rules."""
    if not isinstance(packet, dict):
        raise TypeError("pick packet must be a JSON object")
    errors: list[str] = []
    warnings: list[str] = []
    as_of = _timestamp(packet.get("as_of"), "as_of")

    event = packet.get("event") or {}
    for field in ("event_id", "competition", "season", "start_time"):
        if not event.get(field):
            errors.append(f"event_{field}_missing")
    try:
        start_time = _timestamp(event.get("start_time"), "event_start_time")
        if start_time <= as_of:
            errors.append("event_not_future_at_forecast_time")
    except ValueError as exc:
        errors.append(str(exc))

    market = packet.get("market") or {}
    required_market = ("market_scope", "market", "selection", "period", "operator", "odds_decimal", "quoted_at")
    for field in required_market:
        if market.get(field) in (None, ""):
            errors.append(f"market_{field}_missing")
    try:
        odds = _number(market.get("odds_decimal"), "odds_decimal", minimum=1.0000001)
    except ValueError as exc:
        errors.append(str(exc))
        odds = None
    try:
        quote_time = _timestamp(market.get("quoted_at"), "quoted_at")
        quote_age = (as_of - quote_time).total_seconds() / 60
        if quote_age < 0:
            errors.append("quote_is_from_future")
        elif quote_age > max_quote_age_minutes:
            errors.append("quote_stale")
    except ValueError as exc:
        errors.append(str(exc))
    if market.get("quote_verified_exact_operator") is not True:
        errors.append("exact_operator_quote_not_verified")
    if market.get("market_rules_verified") is not True:
        errors.append("market_settlement_rules_not_verified")
    if market.get("model_market_supported") is not True:
        errors.append("exact_market_not_supported_by_model")

    # Critical team/player availability must not remain unresolved.
    lineup = packet.get("availability") or {}
    if lineup.get("status") not in {"CONFIRMED", "NOT_MATERIAL"}:
        errors.append("material_availability_not_resolved")
    if lineup.get("material_uncertainty") is True:
        errors.append("material_availability_uncertainty_remains")

    dq = packet.get("data_quality") or {}
    if dq.get("status") != "PASS":
        errors.append("data_quality_not_pass")
    if dq.get("point_in_time_pass") is not True:
        errors.append("point_in_time_integrity_not_pass")

    # Require independent data families and timestamps no later than as_of.
    sources = packet.get("sources", [])
    if not isinstance(sources, list):
        errors.append("sources_must_be_array")
        sources = []
    source_ids: set[str] = set()
    source_groups: set[str] = set()
    official_group_found = False
    for i, src in enumerate(sources):
        if not isinstance(src, dict):
            errors.append(f"source_{i}_not_object")
            continue
        sid = str(src.get("id", "")).strip()
        group = str(src.get("independence_group", "")).strip()
        if not sid or sid in source_ids:
            errors.append(f"source_{i}_missing_or_duplicate_id")
        source_ids.add(sid)
        if not group:
            errors.append(f"source_{sid or i}_independence_group_missing")
        source_groups.add(group)
        official_group_found = official_group_found or src.get("source_type") in {"official", "official_competition", "official_club", "official_league"}
        try:
            available = _timestamp(src.get("available_at"), f"source_{sid}_available_at")
            retrieved = _timestamp(src.get("retrieved_at"), f"source_{sid}_retrieved_at")
            if available > as_of or retrieved > as_of:
                errors.append(f"source_{sid}_lookahead")
        except ValueError as exc:
            errors.append(str(exc))
    if len(source_groups - {""}) < 2:
        errors.append("fewer_than_two_independent_source_groups")
    if not official_group_found:
        errors.append("no_official_competition_or_club_source")

    validation = packet.get("model_validation") or {}
    if validation.get("status") != "VALIDATED_ON_UNTOUCHED_HOLDOUT_FOR_THIS_EXACT_SCOPE":
        errors.append("model_not_validated_on_untouched_holdout")
    scope = str(market.get("market_scope", ""))
    if validation.get("validated_scope") != scope:
        errors.append("validation_scope_not_exact_match")
    if validation.get("model_card_audit_status") != "MODEL_SCOPE_VALIDATED":
        errors.append("model_card_not_validated_for_exact_scope")
    if validation.get("model_card_scope") != scope:
        errors.append("model_card_scope_not_exact_match")
    card_hash = str(validation.get("model_card_sha256", "")).lower()
    if not re.fullmatch(r"[0-9a-f]{64}", card_hash):
        errors.append("model_card_sha256_missing_or_invalid")
    if validation.get("model_card_hash_verified") is not True:
        errors.append("model_card_file_hash_not_verified")
    if validation.get("test_period_untouched") is not True:
        errors.append("test_period_not_proven_untouched")
    if validation.get("data_leakage_audit_pass") is not True:
        errors.append("data_leakage_audit_not_pass")
    try:
        n_pred = int(validation.get("n_test_predictions", 0))
        n_events = int(validation.get("n_test_events", 0))
        n_splits = int(validation.get("walk_forward_splits", 0))
        high_confidence_n = int(validation.get("high_confidence_subset_n", 0))
        high_confidence_lower = _number(validation.get("high_confidence_hit_rate_lower95"),
                                        "high_confidence_hit_rate_lower95", minimum=0, maximum=1)
        if high_confidence_n < 100:
            errors.append("insufficient_high_confidence_holdout_predictions")
        if high_confidence_lower < 0.80:
            errors.append("high_confidence_holdout_hit_rate_lower95_below_0_80")
        if n_pred < min_test_predictions:
            errors.append("insufficient_oos_test_predictions")
        if n_events < min_test_events:
            errors.append("insufficient_unique_oos_events")
        if n_splits < min_walk_forward_splits:
            errors.append("insufficient_walk_forward_splits")
        if validation.get("evaluation_unit") != "unique_event_id" and validation.get("evaluation_unit") != "event_grouped":
            errors.append("test_sample_not_event_grouped")
        brier = _number(validation.get("brier"), "test_brier", minimum=0, maximum=1)
        brier_market = _number(validation.get("market_baseline_brier"), "market_baseline_brier", minimum=0, maximum=1)
        logloss = _number(validation.get("log_loss"), "test_log_loss", minimum=0)
        logloss_market = _number(validation.get("market_baseline_log_loss"), "market_baseline_log_loss", minimum=0)
        ece = _number(validation.get("ece"), "test_ece", minimum=0, maximum=1)
        slope = _number(validation.get("calibration_slope"), "calibration_slope", minimum=0)
        intercept = _number(validation.get("calibration_intercept"), "calibration_intercept")
        if brier >= brier_market:
            errors.append("model_brier_not_better_than_market_baseline")
        if logloss > logloss_market + 0.005:
            errors.append("model_logloss_materially_worse_than_market_baseline")
        if ece > 0.03:
            errors.append("model_ece_above_strict_limit")
        if not 0.80 <= slope <= 1.20 or abs(intercept) > 0.10:
            errors.append("model_calibration_slope_or_intercept_out_of_range")
    except ValueError as exc:
        errors.append(str(exc))

    probs = packet.get("probabilities") or {}
    try:
        p_model = _number(probs.get("p_model"), "p_model", minimum=0, maximum=1)
        p_lower = _number(probs.get("p_model_lower95"), "p_model_lower95", minimum=0, maximum=1)
        p_market = _number(probs.get("p_market_no_vig"), "p_market_no_vig", minimum=0, maximum=1)
        if p_lower > p_model:
            errors.append("model_lower_bound_exceeds_point_estimate")
        if p_lower < min_leg_lower_probability:
            errors.append("conservative_leg_probability_below_strict_threshold")
        if p_lower < p_market + min_edge_over_market:
            errors.append("conservative_probability_does_not_clear_market_edge")
        if probs.get("lower_bound_includes_model_parameter_and_data_uncertainty") is not True:
            errors.append("probability_interval_omits_model_or_data_uncertainty")
        if probs.get("lower_bound_includes_lineup_and_scenario_stress") is not True:
            errors.append("probability_interval_omits_lineup_or_scenario_stress")
    except ValueError as exc:
        errors.append(str(exc))

    return {
        "status": "PICK_ELIGIBLE_FOR_COMBO_SEARCH" if not errors else "REJECT_PICK",
        "errors": errors,
        "warnings": warnings,
        "scope": scope,
        "p_model": probs.get("p_model"),
        "p_model_lower95": probs.get("p_model_lower95"),
        "minimum_required_lower_probability": min_leg_lower_probability,
        "meaning": "Eligibility is a strict evidence gate, not a guarantee that the event will occur.",
    }


def evaluate_combo_gate(packet: dict[str, Any], *, min_joint_lower_probability: float = 0.30,
                        min_leg_lower_probability: float = 0.80) -> dict[str, Any]:
    """Require robust joint probability, exact execution price and approved legs."""
    if not isinstance(packet, dict):
        raise TypeError("combo packet must be a JSON object")
    errors: list[str] = []
    legs = packet.get("legs", [])
    if not isinstance(legs, list) or len(legs) < 2:
        errors.append("at_least_two_legs_required")
        legs = []
    if len(legs) > 6:
        errors.append("more_than_six_legs_disallowed_in_strict_mode")
    ids = [str(x.get("leg_id", "")) for x in legs if isinstance(x, dict)]
    if len(ids) != len(legs) or any(not x for x in ids) or len(set(ids)) != len(ids):
        errors.append("leg_ids_missing_or_duplicate")
    for i, leg in enumerate(legs):
        if not isinstance(leg, dict):
            continue
        if leg.get("pick_gate_status") != "PICK_ELIGIBLE_FOR_COMBO_SEARCH":
            errors.append(f"leg_{i}_did_not_pass_pick_gate")
        try:
            p = _number(leg.get("p_model_lower95"), f"leg_{i}_p_model_lower95", minimum=0, maximum=1)
            if p < min_leg_lower_probability:
                errors.append(f"leg_{i}_below_minimum_conservative_probability")
        except ValueError as exc:
            errors.append(str(exc))
    try:
        target = _number(packet.get("target_decimal_odds"), "target_decimal_odds", minimum=1.0000001)
        actual = _number(packet.get("actual_decimal_odds"), "actual_decimal_odds", minimum=1.0000001)
        if packet.get("actual_price_verified_same_operator") is not True:
            errors.append("combined_price_not_verified_at_same_operator")
        if packet.get("all_lines_and_rules_reverified") is not True:
            errors.append("combo_lines_or_settlement_rules_not_reverified")
        band = _number(packet.get("relative_odds_band", 0.10), "relative_odds_band", minimum=0, maximum=0.5)
        if not target * (1-band) <= actual <= target * (1+band):
            errors.append("actual_combo_odds_outside_target_band")
        # Conservative floor is intentionally above break-even; hitting rate takes priority.
        required_joint = max(min_joint_lower_probability, (1.0 / actual) + 0.05)
    except ValueError as exc:
        errors.append(str(exc))
        required_joint = min_joint_lower_probability
    try:
        p_joint = _number(packet.get("p_joint_lower95"), "p_joint_lower95", minimum=0, maximum=1)
        p_stress = _number(packet.get("p_joint_stress_min"), "p_joint_stress_min", minimum=0, maximum=1)
        if p_joint < required_joint:
            errors.append("joint_probability_lower_bound_below_strict_floor")
        if p_stress < required_joint:
            errors.append("worst_stress_joint_probability_below_strict_floor")
        if packet.get("joint_lower_bound_includes_model_data_parameter_lineup_uncertainty") is not True:
            errors.append("joint_lower_bound_omits_model_or_data_uncertainty")
        if packet.get("joint_scenarios_include_all_legs_and_dependencies") is not True:
            errors.append("joint_scenarios_do_not_cover_all_legs_and_dependencies")
        if packet.get("independence_assumed_without_evidence") is True:
            errors.append("unsupported_independence_assumption")
        scenarios = int(packet.get("scenario_count", 0))
        if scenarios < 100000:
            errors.append("insufficient_joint_scenario_count_for_strict_mode")
    except ValueError as exc:
        errors.append(str(exc))
        p_joint = packet.get("p_joint_lower95")
        p_stress = packet.get("p_joint_stress_min")
    return {
        "status": "STRICT_COMBO_ELIGIBLE_FOR_FINAL_USER_RECHECK" if not errors else "NO_STRICT_COMBO",
        "errors": errors,
        "target_decimal_odds": packet.get("target_decimal_odds"),
        "actual_decimal_odds": packet.get("actual_decimal_odds"),
        "p_joint_lower95": p_joint,
        "p_joint_stress_min": p_stress,
        "required_joint_lower_probability": required_joint,
        "meaning": "Strict eligibility is not a guarantee. Even a well-calibrated forecast can lose; abstention is preferred over a weak combination.",
    }
