from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Iterable

from .common import parse_datetime
from .calibration import ForecastOutcome, score_forecasts


@dataclass(frozen=True)
class BacktestRow:
    event_time: str
    created_at: str
    data_cutoff: str
    probability: float
    outcome: int
    model_version: str
    market: str
    competition: str


def validate_backtest_rows(rows: Iterable[BacktestRow]) -> tuple[list[BacktestRow], list[str]]:
    valid: list[BacktestRow] = []
    errors: list[str] = []
    for i, r in enumerate(rows):
        try:
            event, created, cutoff = map(parse_datetime, (r.event_time, r.created_at, r.data_cutoff))
            if created >= event: raise ValueError("forecast_created_after_event")
            if cutoff >= event: raise ValueError("data_cutoff_after_event")
            if cutoff > created: raise ValueError("data_cutoff_after_forecast")
            ForecastOutcome(r.probability, r.outcome).validate()
            if not r.model_version or not r.market or not r.competition:
                raise ValueError("missing_model_market_or_competition")
            valid.append(r)
        except Exception as exc:
            errors.append(f"row[{i}]:{exc}")
    return valid, errors


def chronological_backtest(rows: Iterable[BacktestRow], *, test_start: str) -> dict:
    items, errors = validate_backtest_rows(rows)
    cutoff = parse_datetime(test_start)
    test = [r for r in items if parse_datetime(r.event_time) >= cutoff]
    train = [r for r in items if parse_datetime(r.event_time) < cutoff]
    if not test:
        return {"status": "INSUFFICIENT_TEST_DATA", "n_train": len(train), "n_test": 0, "errors": errors}
    report = score_forecasts([ForecastOutcome(r.probability, r.outcome) for r in test])
    return {"status": "RETROSPECTIVE_HOLDOUT_ONLY", "n_train": len(train), "n_test": len(test),
            "test_start": cutoff.isoformat(), "metrics": report, "data_integrity_errors": errors,
            "warning": "One fixed holdout is not a walk-forward proof and does not guarantee future performance."}


def walk_forward_splits(rows: Iterable[BacktestRow], *, min_train_events: int = 100,
                        test_block_events: int = 50) -> dict:
    valid, errors = validate_backtest_rows(rows)
    ordered = sorted(valid, key=lambda r: parse_datetime(r.event_time))
    if min_train_events < 1 or test_block_events < 1: raise ValueError("split sizes must be positive")
    splits = []
    start = min_train_events
    while start < len(ordered):
        train = ordered[:start]
        test = ordered[start:start + test_block_events]
        if not test: break
        splits.append({"train_start": train[0].event_time, "train_end": train[-1].event_time,
                       "test_start": test[0].event_time, "test_end": test[-1].event_time,
                       "n_train": len(train), "n_test": len(test),
                       "test_metrics": score_forecasts([ForecastOutcome(r.probability, r.outcome) for r in test])})
        start += test_block_events
    return {"splits": splits, "n_valid_rows": len(valid), "integrity_errors": errors,
            "method": "expanding-window; timestamps sorted chronologically"}
