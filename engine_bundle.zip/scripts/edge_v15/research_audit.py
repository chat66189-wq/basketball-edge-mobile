"""Research-packet completeness audit for Basketball Edge Analyst v16.

This module audits research provenance and completeness only. It does not
estimate betting probabilities, validate a predictive model, or approve a bet.
"""
from __future__ import annotations

from datetime import datetime
from typing import Any
from urllib.parse import urlparse

CATEGORY_WEIGHTS = {
    "fixture": 8,
    "competition_rules": 8,
    "season_team_stats": 11,
    "advanced_team_metrics": 12,
    "home_away_splits": 8,
    "opponent_quality": 8,
    "roster_availability": 12,
    "schedule_context": 8,
    "matchup_analysis": 8,
    "market_prices": 10,
    "independent_crosscheck": 3,
    "news_updates": 4,
}

CRITICAL_CATEGORIES = {
    "fixture", "competition_rules", "season_team_stats",
    "roster_availability", "market_prices", "independent_crosscheck",
}

VALID_STATUSES = {
    "CHECKED_WITH_DATA", "CHECKED_NO_RELEVANT_DATA", "NOT_COVERED",
    "NOT_ACCESSIBLE", "NOT_FOUND", "NOT_CHECKED",
}


def _dt(value: Any, field: str) -> datetime:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field} must be an ISO-8601 timestamp with timezone")
    parsed = datetime.fromisoformat(value.strip().replace("Z", "+00:00"))
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ValueError(f"{field} must include a timezone offset")
    return parsed


def _valid_url(value: Any) -> bool:
    if not isinstance(value, str) or not value.strip():
        return False
    parsed = urlparse(value.strip())
    return parsed.scheme in {"http", "https"} and bool(parsed.netloc)


def audit_research_packet(packet: dict[str, Any]) -> dict[str, Any]:
    """Return a transparent completeness audit; never an approval to bet."""
    errors: list[str] = []
    warnings: list[str] = []
    missing_critical: list[str] = []
    observations_summary: dict[str, Any] = {}

    if not isinstance(packet, dict):
        raise TypeError("research packet must be a JSON object")
    as_of = _dt(packet.get("as_of"), "as_of")

    event = packet.get("event") or {}
    for field in ("event_id", "competition", "season", "home", "away", "start_time"):
        if not event.get(field):
            errors.append(f"event.{field} is missing")
    if event.get("start_time"):
        try:
            _dt(event["start_time"], "event.start_time")
        except ValueError as exc:
            errors.append(str(exc))

    sources = packet.get("sources", [])
    if not isinstance(sources, list):
        raise TypeError("sources must be an array")
    source_by_id: dict[str, dict[str, Any]] = {}
    source_groups: dict[str, set[str]] = {}
    for index, source in enumerate(sources):
        if not isinstance(source, dict):
            errors.append(f"sources[{index}] must be an object")
            continue
        sid = str(source.get("id", "")).strip()
        if not sid:
            errors.append(f"sources[{index}].id is missing")
            continue
        if sid in source_by_id:
            errors.append(f"duplicate source id: {sid}")
            continue
        source_by_id[sid] = source
        for field in ("publisher", "source_type", "independence_group", "retrieved_at", "available_at"):
            if not source.get(field):
                errors.append(f"source {sid}: {field} is missing")
        if source.get("source_type") != "user_capture" and not _valid_url(source.get("url")):
            errors.append(f"source {sid}: valid http(s) url is required")
        try:
            retrieved = _dt(source.get("retrieved_at"), f"source {sid}.retrieved_at")
            available = _dt(source.get("available_at"), f"source {sid}.available_at")
            if available > as_of:
                errors.append(f"source {sid}: look-ahead (available_at is after packet as_of)")
            if retrieved > as_of:
                errors.append(f"source {sid}: retrieved after packet as_of")
        except (TypeError, ValueError) as exc:
            errors.append(str(exc))
        group = str(source.get("independence_group", "")).strip()
        if group:
            source_groups.setdefault(group, set()).add(sid)

    evidence = packet.get("evidence", [])
    if not isinstance(evidence, list):
        raise TypeError("evidence must be an array")
    by_category: dict[str, dict[str, Any]] = {}
    for index, item in enumerate(evidence):
        if not isinstance(item, dict):
            errors.append(f"evidence[{index}] must be an object")
            continue
        category = str(item.get("category", "")).strip()
        if category not in CATEGORY_WEIGHTS:
            errors.append(f"evidence[{index}] has unknown category: {category or '<empty>'}")
            continue
        if category in by_category:
            errors.append(f"duplicate evidence category: {category}")
            continue
        by_category[category] = item
        status = item.get("status")
        if status not in VALID_STATUSES:
            errors.append(f"{category}: invalid or missing status")
            continue
        refs = item.get("source_ids", [])
        if not isinstance(refs, list):
            errors.append(f"{category}: source_ids must be an array")
            refs = []
        unknown = [sid for sid in refs if sid not in source_by_id]
        if unknown:
            errors.append(f"{category}: unknown source ids {unknown}")
        observations = item.get("observations", [])
        if not isinstance(observations, list):
            errors.append(f"{category}: observations must be an array")
            observations = []
        if status == "CHECKED_WITH_DATA" and (not refs or not observations):
            errors.append(f"{category}: CHECKED_WITH_DATA requires source_ids and observations")
        if status != "NOT_CHECKED" and not item.get("notes") and status != "CHECKED_WITH_DATA":
            errors.append(f"{category}: explain checked absence/coverage status in notes")
        observations_summary[category] = {
            "status": status,
            "source_count": len(set(refs) & set(source_by_id)),
            "observation_count": len(observations),
        }

    score = 0.0
    for category, weight in CATEGORY_WEIGHTS.items():
        item = by_category.get(category)
        if not item:
            missing_critical.append(category) if category in CRITICAL_CATEGORIES else None
            continue
        status = item.get("status")
        if status == "CHECKED_WITH_DATA":
            score += weight
        elif status in {"CHECKED_NO_RELEVANT_DATA", "NOT_COVERED", "NOT_ACCESSIBLE", "NOT_FOUND"}:
            score += weight * 0.25  # documented attempts get limited coverage credit only
        if category in CRITICAL_CATEGORIES and status != "CHECKED_WITH_DATA":
            missing_critical.append(category)

    cross = by_category.get("independent_crosscheck", {})
    cross_refs = cross.get("source_ids", []) if isinstance(cross, dict) else []
    cross_groups = {
        source_by_id[sid].get("independence_group")
        for sid in cross_refs if sid in source_by_id
    }
    if cross.get("status") == "CHECKED_WITH_DATA" and len(cross_groups) < 2:
        message = "independent_crosscheck requires at least two distinct source groups"
        warnings.append(message)
        errors.append(message)
        missing_critical.append("independent_crosscheck")

    market = packet.get("intended_market") or {}
    price_verification = market.get("price_verification", "NOT_VERIFIED")
    if price_verification != "EXACT_OPERATOR_VERIFIED":
        warnings.append("price is not verified at the exact requested operator; external odds remain reference-only")
    else:
        market_evidence = by_category.get("market_prices", {})
        market_refs = market_evidence.get("source_ids", []) if isinstance(market_evidence, dict) else []
        valid_price_sources = [source_by_id[sid] for sid in market_refs if sid in source_by_id and source_by_id[sid].get("source_type") in {"bookmaker", "user_capture"}]
        if not valid_price_sources:
            errors.append("EXACT_OPERATOR_VERIFIED requires a bookmaker or user_capture source in market_prices evidence")
        operator_name = str(market.get("operator", "")).strip().casefold()
        if operator_name and valid_price_sources and not any(str(src.get("publisher", "")).strip().casefold() == operator_name for src in valid_price_sources):
            errors.append("price verification source publisher does not match intended_market.operator")
    exact_market_fields = ("operator", "market", "selection", "period", "odds_decimal", "quoted_at")
    if packet.get("recommendation_requested", True):
        for field in exact_market_fields:
            if market.get(field) in (None, ""):
                warnings.append(f"intended_market.{field} is missing; operator price is not verified")
        if market.get("quoted_at"):
            try:
                quote_time = _dt(market["quoted_at"], "intended_market.quoted_at")
                if quote_time > as_of:
                    errors.append("intended market quote is from after packet as_of")
            except ValueError as exc:
                errors.append(str(exc))
        odds = market.get("odds_decimal")
        if odds is not None:
            try:
                if float(odds) <= 1.0:
                    errors.append("intended_market.odds_decimal must be > 1.0")
            except (TypeError, ValueError):
                errors.append("intended_market.odds_decimal must be numeric")

    # Evidence score is descriptive, not a probability and not a model-quality score.
    complete = score >= 80.0 and not missing_critical and not errors
    status = "RESEARCH_PACKET_COMPLETE_NOT_PICK_APPROVAL" if complete else "INCOMPLETE_RESEARCH_PACKET"
    if score < 80.0:
        warnings.append("research completeness score is below 80/100")
    if errors:
        warnings.append("critical data/provenance errors must be resolved before using this packet")

    return {
        "status": status,
        "research_completeness_score": round(score, 1),
        "score_interpretation": "coverage/provenance checklist only; NOT win probability, confidence, model accuracy, or bet approval",
        "missing_critical_categories": sorted(set(missing_critical)),
        "evidence_by_category": observations_summary,
        "unique_independence_groups": len(source_groups),
        "errors": errors,
        "warnings": warnings,
        "pick_approval": "NEVER_GRANTED_BY_RESEARCH_AUDIT",
    }
