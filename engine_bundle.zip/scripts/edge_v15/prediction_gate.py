from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

from .data_quality import DataStatus, QualityReport, validate_point_in_time


@dataclass(frozen=True)
class GateInput:
    data_quality: QualityReport
    event_at: str
    created_at: str
    data_cutoff: str
    model_validated_for_scope: bool
    calibration_valid_for_scope: bool
    quote_verified: bool
    market_rules_verified: bool
    quote_age_minutes: float | None
    quote_ttl_minutes: float = 10.0
    model_probability: float | None = None


def assess_prediction_gate(item: GateInput) -> dict:
    errors: list[str] = []
    warnings: list[str] = []
    point_ok, point_errors = validate_point_in_time(event_at=item.event_at,
                                                     forecast_created_at=item.created_at,
                                                     data_cutoff_at=item.data_cutoff)
    errors.extend(point_errors)
    if item.data_quality.status == DataStatus.BLOCKED:
        errors.extend(item.data_quality.errors or ("data_quality_blocked",))
    elif item.data_quality.status == DataStatus.CONDITIONAL:
        warnings.extend(item.data_quality.warnings)
    if not item.model_validated_for_scope: warnings.append("model_not_validated_for_exact_scope")
    if not item.calibration_valid_for_scope: warnings.append("calibration_not_valid_for_exact_scope")
    if not item.quote_verified: warnings.append("quote_not_verified")
    if not item.market_rules_verified: warnings.append("market_rules_not_verified")
    if item.quote_age_minutes is None: warnings.append("quote_age_unknown")
    elif item.quote_age_minutes > item.quote_ttl_minutes: warnings.append("quote_stale")
    if item.model_probability is None or not 0 < item.model_probability < 1:
        warnings.append("model_probability_missing_or_invalid")
    if errors:
        status = "BLOQUEADO"
    elif warnings:
        status = "CONDICIONAL"
    else:
        status = "EJECUTABLE_SUBJECT_TO_FINAL_OPERATOR_RECHECK"
    return {"status": status, "errors": errors, "warnings": warnings,
            "point_in_time_pass": point_ok,
            "meaning": "EJECUTABLE is a technical gate only; it does not certify future accuracy or profitability."}
