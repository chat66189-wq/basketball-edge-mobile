from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Iterable
import math
import random

from .common import effective_sample_size, parse_datetime, finite_number, clamp


@dataclass(frozen=True)
class TeamGame:
    game_date: str
    team: str
    opponent: str
    points_for: float
    points_against: float
    possessions: float
    is_home: bool
    available_at: str | None = None

    def validate(self) -> None:
        if not self.team.strip() or not self.opponent.strip():
            raise ValueError("team and opponent are required")
        if not isinstance(self.is_home, bool):
            raise ValueError("is_home must be boolean")
        finite_number(self.points_for, "points_for", minimum=0)
        finite_number(self.points_against, "points_against", minimum=0)
        finite_number(self.possessions, "possessions", minimum=1)
        parse_datetime(self.game_date, allow_date_only=True)
        if self.available_at:
            parse_datetime(self.available_at)


@dataclass(frozen=True)
class LeaguePriors:
    pace: float
    points_per_possession: float
    home_advantage_ppp: float = 0.012
    pace_prior_games: float = 8.0
    efficiency_prior_games: float = 8.0
    split_prior_games: float = 4.0

    def validate(self) -> None:
        finite_number(self.pace, "league pace", minimum=1, maximum=200)
        finite_number(self.points_per_possession, "league PPP", minimum=0.3, maximum=2.5)
        finite_number(self.home_advantage_ppp, "home advantage PPP", minimum=-0.2, maximum=0.2)
        finite_number(self.pace_prior_games, "pace prior games", minimum=0)
        finite_number(self.efficiency_prior_games, "efficiency prior games", minimum=0)
        finite_number(self.split_prior_games, "split prior games", minimum=0)


@dataclass(frozen=True)
class TeamRates:
    team: str
    games: int
    effective_games: float
    pace: float
    offense_ppp: float
    defense_allowed_ppp: float
    raw_pace: float
    raw_offense_ppp: float
    raw_defense_allowed_ppp: float
    data_cutoff: str
    home_games: int
    away_games: int
    home_pace: float
    away_pace: float
    home_offense_ppp: float
    away_offense_ppp: float
    home_defense_allowed_ppp: float
    away_defense_allowed_ppp: float


@dataclass(frozen=True)
class GameProjection:
    home: str
    away: str
    pace: float
    home_ppp: float
    away_ppp: float
    home_points_mean: float
    away_points_mean: float
    home_rates: TeamRates
    away_rates: TeamRates
    rating_method: str = "team_split_baseline"
    model_version: str = "v15.0.0-baseline"
    validation_status: str = "EXPLORATORY_NOT_VALIDATED"


def _weighted_stats(rows: list[TeamGame], as_of: datetime, half_life_days: float) -> tuple[float, float, float, float]:
    if not rows:
        raise ValueError("no eligible historical games")
    if half_life_days <= 0:
        raise ValueError("half_life_days must be positive")
    wts: list[float] = []
    pace_values: list[float] = []
    off_values: list[float] = []
    def_values: list[float] = []
    for row in rows:
        played = parse_datetime(row.game_date, allow_date_only=True)
        age_days = max(0.0, (as_of - played).total_seconds() / 86400.0)
        weight = math.exp(-math.log(2) * age_days / half_life_days)
        wts.append(weight)
        pace_values.append(row.possessions)
        off_values.append(row.points_for / row.possessions)
        def_values.append(row.points_against / row.possessions)
    total = sum(wts)
    if total <= 0:
        raise ValueError("historical sample has zero effective weight")
    mean = lambda vals: sum(w * v for w, v in zip(wts, vals)) / total
    return mean(pace_values), mean(off_values), mean(def_values), effective_sample_size(wts)


def fit_team_rates(rows: Iterable[TeamGame], team: str, *, as_of: str | datetime,
                   priors: LeaguePriors, half_life_days: float = 180.0) -> TeamRates:
    priors.validate()
    cutoff = parse_datetime(as_of)
    eligible = []
    for row in rows:
        row.validate()
        if row.team != team:
            continue
        played = parse_datetime(row.game_date, allow_date_only=True)
        if row.available_at:
            available = parse_datetime(row.available_at)
        elif isinstance(row.game_date, str) and len(row.game_date.strip()) == 10:
            # A date-only result has no reliable publication time. Treat it as
            # unavailable until the following UTC day to prevent same-day leakage.
            from datetime import timedelta
            available = played + timedelta(days=1)
        else:
            available = played
        if played < cutoff and available < cutoff:
            eligible.append(row)
    if not eligible:
        raise ValueError(f"no point-in-time history for team {team!r}")
    raw_pace, raw_off, raw_def, n_eff = _weighted_stats(eligible, cutoff, half_life_days)
    n_pace = n_eff
    n_efficiency = n_eff
    pace = (n_pace * raw_pace + priors.pace_prior_games * priors.pace) / (n_pace + priors.pace_prior_games)
    off = (n_efficiency * raw_off + priors.efficiency_prior_games * priors.points_per_possession) / (n_efficiency + priors.efficiency_prior_games)
    defense = (n_efficiency * raw_def + priors.efficiency_prior_games * priors.points_per_possession) / (n_efficiency + priors.efficiency_prior_games)

    def fit_split(split_rows: list[TeamGame]) -> tuple[int, float, float, float]:
        if not split_rows:
            return 0, pace, off, defense
        split_pace_raw, split_off_raw, split_def_raw, split_n_eff = _weighted_stats(split_rows, cutoff, half_life_days)
        prior = priors.split_prior_games
        pace_value = (split_n_eff * split_pace_raw + prior * pace) / (split_n_eff + prior)
        off_value = (split_n_eff * split_off_raw + prior * off) / (split_n_eff + prior)
        def_value = (split_n_eff * split_def_raw + prior * defense) / (split_n_eff + prior)
        return len(split_rows), pace_value, off_value, def_value

    home_split = fit_split([r for r in eligible if r.is_home])
    away_split = fit_split([r for r in eligible if not r.is_home])
    return TeamRates(team, len(eligible), n_eff, pace, off, defense,
                     raw_pace, raw_off, raw_def, cutoff.isoformat(),
                     home_split[0], away_split[0], home_split[1], away_split[1],
                     home_split[2], away_split[2], home_split[3], away_split[3])


@dataclass(frozen=True)
class AdjustedTeamRating:
    team: str
    games: int
    effective_games: float
    attack_delta_ppp: float
    defense_delta_ppp: float


def fit_opponent_adjusted_ratings(rows: Iterable[TeamGame], *, as_of: str | datetime,
                                   league_ppp: float, half_life_days: float = 180.0,
                                   ridge: float = 5.0, iterations: int = 100) -> dict[str, AdjustedTeamRating]:
    """Fit regularized attack/defense PPP deltas with weighted coordinate descent.

    Requires team-game records with opponent identifiers. Positive defensive
    delta means suppressing opponent PPP. This is a transparent rating baseline,
    not a causal or fully hierarchical model.
    """
    cutoff = parse_datetime(as_of)
    finite_number(league_ppp, "league_ppp", minimum=0.3, maximum=2.5)
    finite_number(half_life_days, "half_life_days", minimum=0.001)
    finite_number(ridge, "ridge", minimum=0.0)
    if iterations < 1 or iterations > 1000: raise ValueError("iterations must be in [1,1000]")
    eligible: list[tuple[TeamGame, float, float]] = []
    teams: set[str] = set()
    for row in rows:
        row.validate()
        played = parse_datetime(row.game_date, allow_date_only=True)
        if row.available_at:
            available = parse_datetime(row.available_at)
        elif isinstance(row.game_date, str) and len(row.game_date.strip()) == 10:
            from datetime import timedelta
            available = played + timedelta(days=1)
        else:
            available = played
        if played >= cutoff or available >= cutoff: continue
        age_days = max(0.0, (cutoff - played).total_seconds() / 86400.0)
        weight = math.exp(-math.log(2) * age_days / half_life_days)
        eligible.append((row, weight, row.points_for / row.possessions - league_ppp))
        teams.update((row.team, row.opponent))
    if not eligible: raise ValueError("no eligible point-in-time records for adjusted ratings")
    team_names = sorted(teams)
    attack = {team: 0.0 for team in team_names}
    defense = {team: 0.0 for team in team_names}
    for _ in range(iterations):
        for team in team_names:
            subset = [(r, w, y) for r, w, y in eligible if r.team == team]
            den = sum(w for _, w, _ in subset) + ridge
            if den > 0:
                attack[team] = sum(w * (y + defense[r.opponent]) for r, w, y in subset) / den
        for team in team_names:
            subset = [(r, w, y) for r, w, y in eligible if r.opponent == team]
            den = sum(w for _, w, _ in subset) + ridge
            if den > 0:
                defense[team] = sum(w * (attack[r.team] - y) for r, w, y in subset) / den
        # Remove the non-identifiable common level without changing a-d.
        shift = (sum(attack.values()) + sum(defense.values())) / (2 * len(teams))
        attack = {k: v - shift for k, v in attack.items()}
        defense = {k: v - shift for k, v in defense.items()}
    result = {}
    for team in team_names:
        subset = [(r, w) for r, w, _ in eligible if r.team == team]
        weights = [w for _, w in subset]
        result[team] = AdjustedTeamRating(team, len(subset), effective_sample_size(weights),
                                          attack[team], defense[team])
    return result


def estimate_possessions(*, field_goal_attempts: float, offensive_rebounds: float,
                         turnovers: float, free_throw_attempts: float,
                         free_throw_possession_factor: float = 0.44) -> float:
    """Estimate possessions using FGA - OREB + TOV + factor*FTA."""
    fga = finite_number(field_goal_attempts, "field_goal_attempts", minimum=0)
    oreb = finite_number(offensive_rebounds, "offensive_rebounds", minimum=0)
    tov = finite_number(turnovers, "turnovers", minimum=0)
    fta = finite_number(free_throw_attempts, "free_throw_attempts", minimum=0)
    factor = finite_number(free_throw_possession_factor, "free_throw_possession_factor", minimum=0, maximum=1)
    if oreb > fga + 1e-9: raise ValueError("offensive_rebounds cannot exceed field_goal_attempts")
    return fga - oreb + tov + factor * fta


def four_factors(*, field_goal_attempts: float, field_goals_made: float,
                 three_point_attempts: float, three_pointers_made: float,
                 free_throw_attempts: float, free_throws_made: float,
                 offensive_rebounds: float, turnovers: float,
                 opponent_defensive_rebounds: float | None = None) -> dict[str, float | None]:
    fga = finite_number(field_goal_attempts, "field_goal_attempts", minimum=0)
    fgm = finite_number(field_goals_made, "field_goals_made", minimum=0)
    tpa = finite_number(three_point_attempts, "three_point_attempts", minimum=0)
    tpm = finite_number(three_pointers_made, "three_pointers_made", minimum=0)
    fta = finite_number(free_throw_attempts, "free_throw_attempts", minimum=0)
    ftm = finite_number(free_throws_made, "free_throws_made", minimum=0)
    oreb = finite_number(offensive_rebounds, "offensive_rebounds", minimum=0)
    tov = finite_number(turnovers, "turnovers", minimum=0)
    if fgm > fga or tpa > fga or tpm > tpa or ftm > fta:
        raise ValueError("made shots cannot exceed attempts")
    opp_dreb = None if opponent_defensive_rebounds is None else finite_number(
        opponent_defensive_rebounds, "opponent_defensive_rebounds", minimum=0)
    efg = None if fga == 0 else (fgm + 0.5 * tpm) / fga
    possession_proxy = fga - oreb + tov + 0.44 * fta
    return {"effective_field_goal_pct": efg,
            "turnover_pct_proxy": None if possession_proxy == 0 else tov / possession_proxy,
            "offensive_rebound_pct": None if opp_dreb is None or (oreb + opp_dreb) == 0 else oreb / (oreb + opp_dreb),
            "free_throw_rate": None if fga == 0 else fta / fga,
            "three_point_attempt_rate": None if fga == 0 else tpa / fga}


def project_game(home_rates: TeamRates, away_rates: TeamRates, priors: LeaguePriors,
                 adjusted_ratings: dict[str, AdjustedTeamRating] | None = None) -> GameProjection:
    priors.validate()
    if home_rates.team == away_rates.team:
        raise ValueError("home and away teams must differ")
    pace = 0.5 * (home_rates.home_pace + away_rates.away_pace)
    # Home team's home split against away team's away defensive split; reverse for away.
    split_home_ppp = 0.5 * (home_rates.home_offense_ppp + away_rates.away_defense_allowed_ppp) + priors.home_advantage_ppp / 2
    split_away_ppp = 0.5 * (away_rates.away_offense_ppp + home_rates.home_defense_allowed_ppp) - priors.home_advantage_ppp / 2
    if (adjusted_ratings and home_rates.team in adjusted_ratings and away_rates.team in adjusted_ratings
            and adjusted_ratings[home_rates.team].games >= 8 and adjusted_ratings[away_rates.team].games >= 8):
        home_rating = adjusted_ratings[home_rates.team]
        away_rating = adjusted_ratings[away_rates.team]
        adjusted_home_ppp = priors.points_per_possession + home_rating.attack_delta_ppp - away_rating.defense_delta_ppp + priors.home_advantage_ppp / 2
        adjusted_away_ppp = priors.points_per_possession + away_rating.attack_delta_ppp - home_rating.defense_delta_ppp - priors.home_advantage_ppp / 2
        # Blend split baseline and opponent-adjusted rating; weights need future
        # walk-forward tuning before they can be considered calibrated.
        home_ppp = 0.5 * split_home_ppp + 0.5 * adjusted_home_ppp
        away_ppp = 0.5 * split_away_ppp + 0.5 * adjusted_away_ppp
        rating_method = "home_away_splits_plus_regularized_opponent_adjustment"
    else:
        home_ppp = split_home_ppp
        away_ppp = split_away_ppp
        rating_method = "home_away_split_baseline"
    home_ppp = clamp(home_ppp, 0.45, 1.8)
    away_ppp = clamp(away_ppp, 0.45, 1.8)
    return GameProjection(home_rates.team, away_rates.team, pace, home_ppp, away_ppp,
                          pace * home_ppp, pace * away_ppp, home_rates, away_rates, rating_method)


@dataclass
class GameSimulation:
    projection: GameProjection
    home_scores: list[int]
    away_scores: list[int]
    simulation_count: int
    seed: int
    regulation_only: bool = True

    def __post_init__(self):
        if len(self.home_scores) != len(self.away_scores) or len(self.home_scores) != self.simulation_count:
            raise ValueError("simulation arrays and simulation_count must match")


def simulate_game(projection: GameProjection, *, simulations: int = 50000, seed: int = 20261119,
                  pace_sd: float = 3.0, ppp_sd: float = 0.075,
                  residual_correlation: float = 0.10) -> GameSimulation:
    if not 1000 <= simulations <= 1_000_000:
        raise ValueError("simulations must be between 1,000 and 1,000,000")
    finite_number(pace_sd, "pace_sd", minimum=0)
    finite_number(ppp_sd, "ppp_sd", minimum=0)
    finite_number(residual_correlation, "residual_correlation", minimum=-0.95, maximum=0.95)
    rng = random.Random(seed)
    hs: list[int] = []
    aws: list[int] = []
    corr = residual_correlation
    orth = math.sqrt(1.0 - corr * corr)
    for _ in range(simulations):
        pace = max(1.0, rng.gauss(projection.pace, pace_sd))
        z1, z2 = rng.gauss(0, 1), rng.gauss(0, 1)
        home_eff = max(0.3, projection.home_ppp + ppp_sd * z1)
        away_eff = max(0.3, projection.away_ppp + ppp_sd * (corr * z1 + orth * z2))
        hs.append(max(0, int(math.floor(pace * home_eff + 0.5))))
        aws.append(max(0, int(math.floor(pace * away_eff + 0.5))))
    return GameSimulation(projection, hs, aws, simulations, seed)
