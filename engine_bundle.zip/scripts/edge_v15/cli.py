from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

from .team_model import (TeamGame, LeaguePriors, fit_team_rates, fit_opponent_adjusted_ratings,
                         project_game, simulate_game)
from .market_pricing import price_game_market
from .combo_optimizer import LegCandidate, optimize_combinations
from .ledger import ForecastLedger
from .provider_contracts import provider_readiness
from .player_model import PlayerRoleInput, simulate_player_stats, prop_probability
from .joint_simulation import PlayerInGame, JointLegSpec, simulate_joint_game_players, build_joint_scenarios
from .research_audit import audit_research_packet
from .strict_decision import evaluate_pick_gate, evaluate_combo_gate
from .model_lab import train_model_lab, predict_from_bundle, model_card_gate


def _load(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as handle:
        value = json.load(handle)
    if not isinstance(value, dict):
        raise ValueError("input JSON must be an object")
    return value


def cmd_project(args):
    data = _load(args.input)
    priors = LeaguePriors(**data["league_priors"])
    history = [TeamGame(**row) for row in data["history"]]
    home = fit_team_rates(history, data["home"], as_of=data["as_of"], priors=priors,
                          half_life_days=data.get("half_life_days", 180))
    away = fit_team_rates(history, data["away"], as_of=data["as_of"], priors=priors,
                          half_life_days=data.get("half_life_days", 180))
    adjusted = None
    if data.get("use_opponent_adjustment", True):
        try:
            adjusted = fit_opponent_adjusted_ratings(history, as_of=data["as_of"],
                                                       league_ppp=priors.points_per_possession,
                                                       half_life_days=data.get("half_life_days", 180),
                                                       ridge=data.get("rating_ridge", 5.0))
        except ValueError:
            adjusted = None
    projection = project_game(home, away, priors, adjusted_ratings=adjusted)
    simulation = simulate_game(projection, simulations=data.get("simulations", 50000),
                               seed=data.get("seed", 20261119))
    markets = [price_game_market(simulation, item["market"], side=item["side"],
                                 line=item.get("line"), overtime_rule=item.get("overtime_rule", "unknown")).__dict__
               for item in data.get("markets", [])]
    output = {"projection": projection.__dict__, "markets": markets,
              "simulation": {"n": simulation.simulation_count, "seed": simulation.seed,
                             "regulation_only": simulation.regulation_only},
              "warning": "EXPLORATORY_NOT_VALIDATED until chronological validation passes."}
    print(json.dumps(output, indent=2, default=lambda x: x.__dict__, ensure_ascii=False))


def cmd_combo(args):
    data = _load(args.input)
    candidates = [LegCandidate(**row) for row in data["candidates"]]
    result = optimize_combinations(candidates, data["scenarios"], target_odds=data["target_odds"],
                                   relative_band=data.get("relative_band", 0.10),
                                   min_legs=data.get("min_legs", 2), max_legs=data.get("max_legs", 6),
                                   joint_prices=data.get("joint_prices", {}),
                                   verified_joint_price_keys=data.get("verified_joint_price_keys", []),
                                   stress_scenarios=data.get("stress_scenarios", []),
                                   assume_independent_cross_event=data.get("assume_independent_cross_event", False),
                                   require_positive_robust_ev=data.get("require_positive_robust_ev", False),
                                   max_combinations=data.get("max_combinations", 250000))
    print(json.dumps(result, indent=2, ensure_ascii=False))


def cmd_player(args):
    data = _load(args.input)
    role = PlayerRoleInput(**data["player"])
    draws, summary = simulate_player_stats(role, simulations=data.get("simulations", 50000),
                                           seed=data.get("seed", 20261119))
    markets = {f"{item['stat']}:{item['side']}:{item['line']}":
               prop_probability(draws, item["stat"], float(item["line"]), item["side"])
               for item in data.get("markets", [])}
    print(json.dumps({"player": role.player, "summary": summary, "markets": markets,
                      "validation_status": "EXPLORATORY_NOT_VALIDATED",
                      "warning": "Per-minute count model only; needs role/market/competition-specific backtesting and calibration."}, indent=2, ensure_ascii=False))


def cmd_joint(args):
    data = _load(args.input)
    priors = LeaguePriors(**data["league_priors"])
    history = [TeamGame(**row) for row in data["history"]]
    home = fit_team_rates(history, data["home"], as_of=data["as_of"], priors=priors,
                          half_life_days=data.get("half_life_days", 180))
    away = fit_team_rates(history, data["away"], as_of=data["as_of"], priors=priors,
                          half_life_days=data.get("half_life_days", 180))
    adjusted = None
    if data.get("use_opponent_adjustment", True):
        try:
            adjusted = fit_opponent_adjusted_ratings(history, as_of=data["as_of"],
                                                       league_ppp=priors.points_per_possession,
                                                       half_life_days=data.get("half_life_days", 180),
                                                       ridge=data.get("rating_ridge", 5.0))
        except ValueError:
            adjusted = None
    projection = project_game(home, away, priors, adjusted_ratings=adjusted)
    players = [PlayerInGame(PlayerRoleInput(**row["role"]), row["team_side"]) for row in data["players"]]
    legs = [JointLegSpec(**row) for row in data["legs"]]
    draws = simulate_joint_game_players(projection, players, simulations=data.get("simulations", 20000),
                                         seed=data.get("seed", 20261119),
                                         pace_sd=data.get("pace_sd", 3.0),
                                         ppp_sd=data.get("ppp_sd", 0.075),
                                         residual_correlation=data.get("residual_correlation", 0.10))
    scenarios = build_joint_scenarios(draws, legs)
    output_path = Path(data.get("output", "data/v15_joint_scenarios.json"))
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(scenarios, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({"output": str(output_path), "scenarios": len(scenarios),
                      "legs": [x.leg_id for x in legs], "projection": {"home": projection.home, "away": projection.away,
                      "home_points_mean": projection.home_points_mean, "away_points_mean": projection.away_points_mean,
                      "rating_method": projection.rating_method, "validation_status": projection.validation_status},
                      "warning": "These are exploratory baseline scenarios, not calibrated probabilities."}, indent=2, ensure_ascii=False))


def cmd_ledger(args):
    ledger = ForecastLedger(args.database)
    print(json.dumps({"database": str(Path(args.database).resolve()), "counts": ledger.counts()}, indent=2))


def cmd_providers(args):
    print(json.dumps(provider_readiness(), indent=2, ensure_ascii=False))


def cmd_model_lab(args):
    config = _load(args.config)
    result = train_model_lab(args.input, config, args.output)
    print(json.dumps(result, indent=2, ensure_ascii=False))
    if result.get("status") != "VALIDATED_ON_UNTOUCHED_HOLDOUT_FOR_THIS_EXACT_SCOPE":
        args.audit_incomplete = True


def cmd_predict_model(args):
    result = predict_from_bundle(args.artifact, args.input)
    print(json.dumps(result, indent=2, ensure_ascii=False))


def cmd_model_card_audit(args):
    card = _load(args.input)
    result = model_card_gate(card, exact_scope=args.scope)
    print(json.dumps(result, indent=2, ensure_ascii=False))
    if result["status"] != "MODEL_SCOPE_VALIDATED":
        args.audit_incomplete = True


def cmd_candidate_log(args):
    data = _load(args.input)
    ledger = ForecastLedger(args.database)
    rows = data.get("candidates", [])
    if not isinstance(rows, list) or not rows:
        raise ValueError("input_must_contain_nonempty_candidates_array")
    for row in rows:
        ledger.add_candidate_decision(**row)
    print(json.dumps({"logged": len(rows), "counts": ledger.counts()}, indent=2, ensure_ascii=False))


def cmd_ledger_report(args):
    ledger = ForecastLedger(args.database)
    print(json.dumps({"counts": ledger.counts(), "performance": ledger.performance_report()}, indent=2, ensure_ascii=False))


def cmd_candidate_settle(args):
    data = _load(args.input)
    rows = data.get("settlements", [])
    if not isinstance(rows, list) or not rows:
        raise ValueError("input_must_contain_nonempty_settlements_array")
    ledger = ForecastLedger(args.database)
    ids = [ledger.settle_candidate(**row) for row in rows]
    print(json.dumps({"candidate_settlement_ids": ids, "counts": ledger.counts()}, indent=2, ensure_ascii=False))


def cmd_model_evaluation_log(args):
    data = _load(args.input)
    rows = data.get("evaluations", [])
    if not isinstance(rows, list) or not rows:
        raise ValueError("input_must_contain_nonempty_evaluations_array")
    ledger = ForecastLedger(args.database)
    for row in rows:
        ledger.add_model_evaluation(**row)
    print(json.dumps({"logged": len(rows), "counts": ledger.counts()}, indent=2, ensure_ascii=False))


def cmd_pick_audit(args):
    data = _load(args.input)
    validation = data.setdefault("model_validation", {})
    if not isinstance(validation, dict):
        validation = {}
        data["model_validation"] = validation
    card_path_value = validation.get("model_card_path")
    expected_hash = str(validation.get("model_card_sha256", "")).lower()
    if card_path_value:
        card_path = Path(card_path_value)
        try:
            card_bytes = card_path.read_bytes()
            actual_hash = hashlib.sha256(card_bytes).hexdigest()
            card = json.loads(card_bytes.decode("utf-8"))
            scope = str((data.get("market") or {}).get("market_scope", ""))
            card_audit = model_card_gate(card, exact_scope=scope)
            validation["model_card_hash_verified"] = bool(expected_hash) and expected_hash == actual_hash
            validation["model_card_audit_status"] = card_audit["status"] if validation["model_card_hash_verified"] else "MODEL_NOT_APPROVED"
            validation["model_card_scope"] = (card.get("scope") or {}).get("market_scope")
            validation["model_card_sha256"] = expected_hash
            validation["status"] = card.get("status")
            validation["validated_scope"] = validation["model_card_scope"]
            validation["test_period_untouched"] = (card.get("walk_forward") or {}).get("selection_used_untouched_holdout") is False
            validation["data_leakage_audit_pass"] = bool(card_audit["status"] == "MODEL_SCOPE_VALIDATED")
            holdout = card.get("untouched_holdout") or {}
            metrics = holdout.get("metrics") or {}
            hc = metrics.get("high_confidence_subset") or {}
            hc_interval = hc.get("hit_rate_wilson_95") or []
            calibration_line = metrics.get("calibration_line") or {}
            validation["n_test_predictions"] = holdout.get("n", 0)
            validation["n_test_events"] = holdout.get("n", 0)  # loader rejects duplicate event IDs
            validation["walk_forward_splits"] = (card.get("walk_forward") or {}).get("splits", 0)
            validation["evaluation_unit"] = "unique_event_id"
            validation["brier"] = metrics.get("brier")
            validation["market_baseline_brier"] = metrics.get("market_no_vig_brier")
            validation["log_loss"] = metrics.get("log_loss")
            validation["market_baseline_log_loss"] = metrics.get("market_no_vig_log_loss")
            validation["ece"] = metrics.get("ece_10_bins")
            validation["calibration_slope"] = calibration_line.get("slope")
            validation["calibration_intercept"] = calibration_line.get("intercept")
            validation["high_confidence_subset_n"] = hc.get("n", 0)
            validation["high_confidence_hit_rate_lower95"] = hc_interval[0] if hc_interval else None
        except Exception as exc:
            validation["model_card_hash_verified"] = False
            validation["model_card_audit_status"] = "MODEL_NOT_APPROVED"
            validation["model_card_audit_error"] = f"{type(exc).__name__}:{exc}"
    else:
        validation["model_card_hash_verified"] = False
        validation["model_card_audit_status"] = "MODEL_NOT_APPROVED"
    result = evaluate_pick_gate(data, min_leg_lower_probability=args.min_leg_lower_probability,
                                min_test_predictions=args.min_test_predictions,
                                min_test_events=args.min_test_events,
                                min_walk_forward_splits=args.min_walk_forward_splits,
                                max_quote_age_minutes=args.max_quote_age_minutes)
    print(json.dumps(result, indent=2, ensure_ascii=False))
    if result["status"] != "PICK_ELIGIBLE_FOR_COMBO_SEARCH":
        args.audit_incomplete = True


def cmd_combo_audit(args):
    data = _load(args.input)
    result = evaluate_combo_gate(data, min_joint_lower_probability=args.min_joint_lower_probability,
                                 min_leg_lower_probability=args.min_leg_lower_probability)
    print(json.dumps(result, indent=2, ensure_ascii=False))
    if result["status"] != "STRICT_COMBO_ELIGIBLE_FOR_FINAL_USER_RECHECK":
        args.audit_incomplete = True


def cmd_research_audit(args):
    data = _load(args.input)
    result = audit_research_packet(data)
    print(json.dumps(result, indent=2, ensure_ascii=False))
    if result["status"] != "RESEARCH_PACKET_COMPLETE_NOT_PICK_APPROVAL":
        args.audit_incomplete = True


def main(argv=None):
    parser = argparse.ArgumentParser(prog="basketball-edge-v18", description="Basketball Edge Analyst v18: laboratorio predictivo cronológico, investigación y gates estrictos")
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("project-game", help="proyecta un partido desde históricos point-in-time")
    p.add_argument("--input", required=True); p.set_defaults(func=cmd_project)
    c = sub.add_parser("combo-optimize", help="optimiza combinadas desde escenarios conjuntos y precios exactos")
    c.add_argument("--input", required=True); c.set_defaults(func=cmd_combo)
    pp = sub.add_parser("player-prop", help="simula minutos inciertos y conteos de un jugador")
    pp.add_argument("--input", required=True); pp.set_defaults(func=cmd_player)
    j = sub.add_parser("joint-simulate", help="genera escenarios compartidos de partido y props para analizar dependencias")
    j.add_argument("--input", required=True); j.set_defaults(func=cmd_joint)
    l = sub.add_parser("ledger-init", help="inicializa/verifica la base SQLite")
    l.add_argument("--database", default="data/edge_v15.sqlite"); l.set_defaults(func=cmd_ledger)
    r = sub.add_parser("provider-status", help="muestra qué adaptadores están configurados")
    r.set_defaults(func=cmd_providers)
    ml = sub.add_parser("model-lab", help="entrena y compara modelos por competición×temporada×mercado con holdout cronológico intacto")
    ml.add_argument("--input", required=True, help="CSV point-in-time, un evento por fila")
    ml.add_argument("--config", required=True, help="JSON con scope y feature_columns explícitos")
    ml.add_argument("--output", required=True, help="ruta del model card JSON")
    ml.set_defaults(func=cmd_model_lab)
    pm = sub.add_parser("predict-model", help="inferencia con un artefacto local confiable; no aprueba apuestas")
    pm.add_argument("--artifact", required=True); pm.add_argument("--input", required=True)
    pm.set_defaults(func=cmd_predict_model)
    mc = sub.add_parser("model-card-audit", help="comprueba la aprobación de una model card en un scope exacto")
    mc.add_argument("--input", required=True); mc.add_argument("--scope", required=True)
    mc.set_defaults(func=cmd_model_card_audit)
    cl = sub.add_parser("candidate-log", help="registra decisiones aceptadas/rechazadas en ledger append-only")
    cl.add_argument("--database", default="data/edge_v18.sqlite"); cl.add_argument("--input", required=True)
    cl.set_defaults(func=cmd_candidate_log)
    cs = sub.add_parser("candidate-settle", help="liquida candidatos aceptados/rechazados sin modificar la decisión original")
    cs.add_argument("--database", default="data/edge_v18.sqlite"); cs.add_argument("--input", required=True)
    cs.set_defaults(func=cmd_candidate_settle)
    me = sub.add_parser("model-evaluation-log", help="registra métricas/versiones de model cards en el ledger append-only")
    me.add_argument("--database", default="data/edge_v18.sqlite"); me.add_argument("--input", required=True)
    me.set_defaults(func=cmd_model_evaluation_log)
    lr = sub.add_parser("ledger-report", help="informa rendimiento liquidado y decisiones por scope")
    lr.add_argument("--database", default="data/edge_v18.sqlite")
    lr.set_defaults(func=cmd_ledger_report)
    a = sub.add_parser("research-audit", help="audita integridad y cobertura documental de un paquete de investigación")
    a.add_argument("--input", required=True); a.set_defaults(func=cmd_research_audit)
    pa = sub.add_parser("pick-audit", help="gate estricto v17 de elegibilidad de una selección")
    pa.add_argument("--input", required=True)
    pa.add_argument("--min-leg-lower-probability", type=float, default=0.80)
    pa.add_argument("--min-test-predictions", type=int, default=300)
    pa.add_argument("--min-test-events", type=int, default=200)
    pa.add_argument("--min-walk-forward-splits", type=int, default=5)
    pa.add_argument("--max-quote-age-minutes", type=float, default=10.0)
    pa.set_defaults(func=cmd_pick_audit)
    ca = sub.add_parser("combo-audit", help="gate estricto v17 de probabilidad conjunta de una combinada")
    ca.add_argument("--input", required=True)
    ca.add_argument("--min-joint-lower-probability", type=float, default=0.30)
    ca.add_argument("--min-leg-lower-probability", type=float, default=0.80)
    ca.set_defaults(func=cmd_combo_audit)
    args = parser.parse_args(argv)
    try:
        args.func(args)
        if getattr(args, "audit_incomplete", False):
            return 1
    except Exception as exc:
        print(json.dumps({"error": type(exc).__name__, "message": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 2
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
