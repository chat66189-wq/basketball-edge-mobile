from __future__ import annotations

from datetime import date, datetime, timezone
from typing import Any
import math


def parse_datetime(value: str | datetime | date, *, allow_date_only: bool = False) -> datetime:
    if isinstance(value, datetime):
        dt = value
    elif isinstance(value, date):
        dt = datetime(value.year, value.month, value.day, tzinfo=timezone.utc)
    elif isinstance(value, str):
        raw = value.strip()
        if allow_date_only and len(raw) == 10:
            dt = datetime.fromisoformat(raw).replace(tzinfo=timezone.utc)
        else:
            dt = datetime.fromisoformat(raw.replace("Z", "+00:00"))
    else:
        raise TypeError("datetime value must be ISO string, date or datetime")
    if dt.tzinfo is None or dt.utcoffset() is None:
        raise ValueError("timestamps must include a timezone offset")
    return dt.astimezone(timezone.utc)


def clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def finite_number(value: Any, name: str, *, minimum: float | None = None,
                  maximum: float | None = None) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{name} must be a number")
    number = float(value)
    if not math.isfinite(number):
        raise ValueError(f"{name} must be finite")
    if minimum is not None and number < minimum:
        raise ValueError(f"{name} must be >= {minimum}")
    if maximum is not None and number > maximum:
        raise ValueError(f"{name} must be <= {maximum}")
    return number


def effective_sample_size(weights: list[float]) -> float:
    total = sum(weights)
    squares = sum(w * w for w in weights)
    return 0.0 if squares <= 0 else total * total / squares
