from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping
import math
import random

from .common import finite_number, clamp


@dataclass(frozen=True)
class PlayerRoleInput:
    player: str
    play_probability: float
    projected_minutes: float
    minutes_sd: float
    max_minutes: float
    rates_per_minute: Mapping[str, float]
    rate_cv: Mapping[str, float]

    def validate(self) -> None:
        if not self.player.strip(): raise ValueError("player is required")
        finite_number(self.play_probability, "play_probability", minimum=0, maximum=1)
        finite_number(self.projected_minutes, "projected_minutes", minimum=0)
        finite_number(self.minutes_sd, "minutes_sd", minimum=0)
        finite_number(self.max_minutes, "max_minutes", minimum=1, maximum=80)
        if self.projected_minutes > self.max_minutes:
            raise ValueError("projected_minutes exceeds max_minutes")
        if not self.rates_per_minute: raise ValueError("at least one rate is required")
        extra_cv = set(self.rate_cv) - set(self.rates_per_minute)
        if extra_cv:
            raise ValueError(f"rate_cv contains unknown stats: {sorted(extra_cv)}")
        for key, rate in self.rates_per_minute.items():
            finite_number(rate, f"rate_per_minute[{key}]", minimum=0)
            finite_number(self.rate_cv.get(key, 0.0), f"rate_cv[{key}]", minimum=0, maximum=3)


def _poisson(rng: random.Random, lam: float) -> int:
    if lam <= 0: return 0
    # Exact Knuth sampler. Basketball stat rates are normally small enough for
    # this transparent implementation; a hard cap prevents pathological loops.
    threshold = math.exp(-lam)
    product = 1.0
    count = 0
    while product > threshold:
        count += 1
        product *= rng.random()
        if count > 10000:
            raise RuntimeError("Poisson sampler safety limit exceeded")
    return count - 1


def simulate_player_stats(role: PlayerRoleInput, *, simulations: int = 50000,
                          seed: int = 20261119) -> tuple[list[dict[str, int | float | bool]], dict[str, float]]:
    role.validate()
    if not 1000 <= simulations <= 500000:
        raise ValueError("simulations must be between 1,000 and 500,000")
    rng = random.Random(seed)
    results: list[dict[str, int | float | bool]] = []
    for _ in range(simulations):
        plays = rng.random() < role.play_probability
        minutes = 0.0 if not plays else clamp(rng.gauss(role.projected_minutes, role.minutes_sd), 0.0, role.max_minutes)
        row: dict[str, int | float | bool] = {"plays": plays, "minutes": minutes}
        for stat, rate in role.rates_per_minute.items():
            cv = role.rate_cv.get(stat, 0.0)
            if minutes == 0 or rate == 0:
                row[stat] = 0
                continue
            mean_rate = rate
            if cv > 0:
                shape = 1.0 / (cv * cv)
                sampled_rate = rng.gammavariate(shape, mean_rate / shape)
            else:
                sampled_rate = mean_rate
            row[stat] = _poisson(rng, minutes * sampled_rate)
        results.append(row)
    playing_rate = sum(bool(x["plays"]) for x in results) / simulations
    minutes_mean = sum(float(x["minutes"]) for x in results) / simulations
    summary = {"play_probability_empirical": playing_rate, "minutes_mean_unconditional": minutes_mean,
               "simulation_count": simulations}
    return results, summary


def prop_probability(draws: list[dict[str, int | float | bool]], stat: str,
                     line: float, side: str) -> dict[str, float]:
    if not draws: raise ValueError("draws cannot be empty")
    if side not in {"over", "under"}: raise ValueError("side must be over or under")
    vals = [float(row[stat]) for row in draws]
    wins = sum(v > line if side == "over" else v < line for v in vals)
    pushes = sum(math.isclose(v, line, abs_tol=1e-9) for v in vals)
    n = len(vals)
    return {"p_win": wins / n, "p_push": pushes / n, "p_loss": 1 - wins / n - pushes / n,
            "mean": sum(vals) / n, "samples": n}
