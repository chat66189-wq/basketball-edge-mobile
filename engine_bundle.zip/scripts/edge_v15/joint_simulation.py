from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping, Sequence
import math
import random

from .common import clamp, finite_number
from .team_model import GameProjection
from .player_model import PlayerRoleInput, _poisson


@dataclass(frozen=True)
class PlayerInGame:
    role: PlayerRoleInput
    team_side: str  # "home" or "away"

    def validate(self) -> None:
        self.role.validate()
        if self.team_side not in {"home", "away"}:
            raise ValueError("player team_side must be home or away")


@dataclass(frozen=True)
class JointLegSpec:
    leg_id: str
    kind: str  # "game" or "player_prop"
    market: str | None = None
    side: str = ""
    line: float | None = None
    player: str | None = None
    stat: str | None = None
    overtime_rule: str = "excluded"


def simulate_joint_game_players(projection: GameProjection, players: Sequence[PlayerInGame], *,
                                simulations: int = 50000, seed: int = 20261119,
                                pace_sd: float = 3.0, ppp_sd: float = 0.075,
                                residual_correlation: float = 0.10,
                                efficiency_sensitivity: Mapping[str, float] | None = None) -> list[dict]:
    """Simulate game scores and all supplied player props in common scenarios.

    Shared pace is a common driver. Player minutes/rates remain simplified and
    need exact market-specific chronological validation before use.
    """
    if not 1000 <= simulations <= 500000:
        raise ValueError("simulations must be between 1,000 and 500,000")
    if projection.pace <= 0: raise ValueError("projection pace must be positive")
    finite_number(pace_sd, "pace_sd", minimum=0)
    finite_number(ppp_sd, "ppp_sd", minimum=0)
    finite_number(residual_correlation, "residual_correlation", minimum=-0.95, maximum=0.95)
    for p in players: p.validate()
    names = [p.role.player for p in players]
    if len(names) != len(set(names)): raise ValueError("duplicate player names")
    sensitivity = dict(efficiency_sensitivity or {"points": 1.0, "assists": 0.35})
    for stat, value in sensitivity.items():
        if not 0 <= float(value) <= 2: raise ValueError(f"invalid efficiency sensitivity for {stat}")
    rng = random.Random(seed)
    orth = math.sqrt(1 - residual_correlation ** 2)
    output: list[dict] = []
    for _ in range(simulations):
        pace = max(1.0, rng.gauss(projection.pace, pace_sd))
        z1, z2 = rng.gauss(0, 1), rng.gauss(0, 1)
        h_ppp = max(0.3, projection.home_ppp + ppp_sd * z1)
        a_ppp = max(0.3, projection.away_ppp + ppp_sd * (residual_correlation * z1 + orth * z2))
        home_score = max(0, int(math.floor(pace * h_ppp + 0.5)))
        away_score = max(0, int(math.floor(pace * a_ppp + 0.5)))
        player_draws = {}
        pace_mult = pace / projection.pace
        for p in players:
            role = p.role
            plays = rng.random() < role.play_probability
            minutes = 0.0 if not plays else clamp(rng.gauss(role.projected_minutes, role.minutes_sd), 0, role.max_minutes)
            team_ppp = h_ppp if p.team_side == "home" else a_ppp
            baseline_ppp = projection.home_ppp if p.team_side == "home" else projection.away_ppp
            eff_mult = team_ppp / baseline_ppp if baseline_ppp > 0 else 1.0
            stats = {}
            for stat, rate in role.rates_per_minute.items():
                cv = role.rate_cv.get(stat, 0.0)
                sampled_rate = rate
                if cv > 0 and rate > 0:
                    shape = 1.0 / (cv * cv)
                    sampled_rate = rng.gammavariate(shape, rate / shape)
                eff_sens = sensitivity.get(stat, 0.0)
                multiplier = pace_mult * max(0.2, 1.0 + eff_sens * (eff_mult - 1.0))
                stats[stat] = _poisson(rng, minutes * sampled_rate * multiplier) if minutes > 0 else 0
            player_draws[role.player] = {"plays": plays, "minutes": minutes, **stats}
        output.append({"home_score": home_score, "away_score": away_score, "pace": pace,
                       "home_ppp": h_ppp, "away_ppp": a_ppp, "players": player_draws})
    return output


def build_joint_scenarios(draws: Sequence[Mapping], legs: Sequence[JointLegSpec]) -> list[dict[str, bool]]:
    if not draws: raise ValueError("draws are required")
    if not legs: raise ValueError("at least one leg spec is required")
    ids = [x.leg_id for x in legs]
    if len(ids) != len(set(ids)): raise ValueError("duplicate leg_id in specs")
    scenarios: list[dict[str, bool]] = []
    for leg in legs:
        if leg.kind == "game":
            if leg.overtime_rule != "excluded":
                raise ValueError("joint simulator is regulation-only; set overtime_rule='excluded' or abstain")
            if leg.market in {"total", "home_total", "away_total", "spread"}:
                if leg.line is None: raise ValueError(f"line required for {leg.leg_id}")
                if float(leg.line).is_integer():
                    raise ValueError(f"integer line can push; only non-integer lines are supported by bool scenarios ({leg.leg_id})")
                if leg.side not in ({"over", "under"} if leg.market != "spread" else {"home", "away"}):
                    raise ValueError(f"invalid side for {leg.leg_id}")
            elif leg.market == "moneyline":
                if leg.side not in {"home", "away"}: raise ValueError("moneyline side must be home or away")
            else:
                raise ValueError(f"unsupported game market {leg.market}")
        elif leg.kind == "player_prop":
            if not leg.player or not leg.stat or leg.line is None:
                raise ValueError(f"player prop needs player/stat/line ({leg.leg_id})")
            if not float(leg.line).is_integer():
                pass
            else:
                raise ValueError(f"integer player line can push; only non-integer lines are supported ({leg.leg_id})")
            if leg.side not in {"over", "under"}: raise ValueError("player prop side must be over or under")
        else:
            raise ValueError(f"unsupported leg kind {leg.kind}")
    for draw in draws:
        row: dict[str, bool] = {}
        home = int(draw["home_score"]); away = int(draw["away_score"])
        for leg in legs:
            if leg.kind == "game":
                if leg.market == "total": value = home + away
                elif leg.market == "home_total": value = home
                elif leg.market == "away_total": value = away
                elif leg.market == "spread": value = (home - away if leg.side == "home" else away - home) + float(leg.line)
                else: value = home - away if leg.side == "home" else away - home
                if leg.market == "moneyline": won = value > 0  # regulation tie is not a win
                elif leg.market == "spread": won = value > 0
                else: won = value > float(leg.line) if leg.side == "over" else value < float(leg.line)
            else:
                player = draw.get("players", {}).get(leg.player)
                if player is None or leg.stat not in player:
                    raise ValueError(f"missing simulated player stat {leg.player}:{leg.stat}")
                value = float(player[leg.stat])
                won = value > float(leg.line) if leg.side == "over" else value < float(leg.line)
            row[leg.leg_id] = bool(won)
        scenarios.append(row)
    return scenarios
