from __future__ import annotations

import json
import math
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator


_SCHEMA = """
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS source_capture (
 id INTEGER PRIMARY KEY AUTOINCREMENT, provider TEXT NOT NULL, source_type TEXT NOT NULL,
 captured_at TEXT NOT NULL, retrieved_at TEXT NOT NULL, license_status TEXT NOT NULL,
 payload_sha256 TEXT NOT NULL, payload_json TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS odds_capture (
 id INTEGER PRIMARY KEY AUTOINCREMENT, event_id TEXT NOT NULL, operator TEXT NOT NULL,
 market TEXT NOT NULL, selection TEXT NOT NULL, line REAL, decimal_odds REAL NOT NULL CHECK(decimal_odds > 1),
 captured_at TEXT NOT NULL, status TEXT NOT NULL, rules_json TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS forecast (
 forecast_id TEXT PRIMARY KEY, event_id TEXT NOT NULL, event_at TEXT NOT NULL,
 market TEXT NOT NULL, selection TEXT NOT NULL, line REAL, probability REAL NOT NULL CHECK(probability BETWEEN 0 AND 1),
 p_low REAL, p_high REAL, model_version TEXT NOT NULL, data_cutoff TEXT NOT NULL,
 created_at TEXT NOT NULL, validation_status TEXT NOT NULL, metadata_json TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS settlement (
 id INTEGER PRIMARY KEY AUTOINCREMENT, forecast_id TEXT NOT NULL REFERENCES forecast(forecast_id),
 settled_at TEXT NOT NULL, outcome INTEGER NOT NULL CHECK(outcome IN (0,1)),
 settlement_status TEXT NOT NULL, result_json TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_forecast_event ON forecast(event_id, market);
CREATE INDEX IF NOT EXISTS idx_odds_lookup ON odds_capture(event_id, market, captured_at);
CREATE INDEX IF NOT EXISTS idx_settlement_forecast ON settlement(forecast_id);
CREATE TABLE IF NOT EXISTS candidate_decision (
 decision_id TEXT PRIMARY KEY, event_id TEXT NOT NULL, event_at TEXT NOT NULL,
 decision_at TEXT NOT NULL, competition TEXT NOT NULL, season TEXT NOT NULL,
 market_scope TEXT NOT NULL, candidate_status TEXT NOT NULL CHECK(candidate_status IN ('ACCEPTED','REJECTED','CONDITIONAL','NO_PICK')),
 probability REAL, lower_probability REAL, decimal_odds REAL, model_version TEXT NOT NULL,
 evidence_sha256 TEXT NOT NULL, reason_codes_json TEXT NOT NULL, payload_json TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS model_evaluation (
 evaluation_id TEXT PRIMARY KEY, evaluated_at TEXT NOT NULL, model_version TEXT NOT NULL,
 competition TEXT NOT NULL, season TEXT NOT NULL, market_scope TEXT NOT NULL,
 status TEXT NOT NULL, sample_size INTEGER NOT NULL, metrics_json TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS candidate_settlement (
 id INTEGER PRIMARY KEY AUTOINCREMENT, decision_id TEXT NOT NULL REFERENCES candidate_decision(decision_id),
 settled_at TEXT NOT NULL, outcome INTEGER NOT NULL CHECK(outcome IN (0,1)),
 settlement_status TEXT NOT NULL, result_json TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_candidate_scope ON candidate_decision(competition,season,market_scope,candidate_status);
CREATE INDEX IF NOT EXISTS idx_model_eval_scope ON model_evaluation(competition,season,market_scope,evaluated_at);
CREATE TRIGGER IF NOT EXISTS candidate_no_update BEFORE UPDATE ON candidate_decision BEGIN SELECT RAISE(ABORT, 'candidate decisions are append-only'); END;
CREATE TRIGGER IF NOT EXISTS candidate_no_delete BEFORE DELETE ON candidate_decision BEGIN SELECT RAISE(ABORT, 'candidate decisions are append-only'); END;
CREATE TRIGGER IF NOT EXISTS model_eval_no_update BEFORE UPDATE ON model_evaluation BEGIN SELECT RAISE(ABORT, 'model evaluations are append-only'); END;
CREATE TRIGGER IF NOT EXISTS model_eval_no_delete BEFORE DELETE ON model_evaluation BEGIN SELECT RAISE(ABORT, 'model evaluations are append-only'); END;
CREATE TRIGGER IF NOT EXISTS candidate_settlement_no_update BEFORE UPDATE ON candidate_settlement BEGIN SELECT RAISE(ABORT, 'candidate settlements are append-only'); END;
CREATE TRIGGER IF NOT EXISTS candidate_settlement_no_delete BEFORE DELETE ON candidate_settlement BEGIN SELECT RAISE(ABORT, 'candidate settlements are append-only'); END;
CREATE TRIGGER IF NOT EXISTS forecast_no_update BEFORE UPDATE ON forecast BEGIN SELECT RAISE(ABORT, 'forecast ledger is append-only'); END;
CREATE TRIGGER IF NOT EXISTS forecast_no_delete BEFORE DELETE ON forecast BEGIN SELECT RAISE(ABORT, 'forecast ledger is append-only'); END;
CREATE TRIGGER IF NOT EXISTS odds_no_update BEFORE UPDATE ON odds_capture BEGIN SELECT RAISE(ABORT, 'odds ledger is append-only'); END;
CREATE TRIGGER IF NOT EXISTS odds_no_delete BEFORE DELETE ON odds_capture BEGIN SELECT RAISE(ABORT, 'odds ledger is append-only'); END;
CREATE TRIGGER IF NOT EXISTS source_no_update BEFORE UPDATE ON source_capture BEGIN SELECT RAISE(ABORT, 'source ledger is append-only'); END;
CREATE TRIGGER IF NOT EXISTS source_no_delete BEFORE DELETE ON source_capture BEGIN SELECT RAISE(ABORT, 'source ledger is append-only'); END;
CREATE TRIGGER IF NOT EXISTS settlement_no_update BEFORE UPDATE ON settlement BEGIN SELECT RAISE(ABORT, 'settlements are append-only; add a correction row'); END;
CREATE TRIGGER IF NOT EXISTS settlement_no_delete BEFORE DELETE ON settlement BEGIN SELECT RAISE(ABORT, 'settlements are append-only'); END;
"""


class ForecastLedger:
    def __init__(self, path: str | Path):
        self.path = str(path)
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as db:
            db.executescript(_SCHEMA)

    @contextmanager
    def connect(self) -> Iterator[sqlite3.Connection]:
        db = sqlite3.connect(self.path)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA journal_mode=WAL")
        db.execute("PRAGMA foreign_keys=ON")
        try:
            yield db
            db.commit()
        except Exception:
            db.rollback()
            raise
        finally:
            db.close()

    def add_source(self, *, provider: str, source_type: str, captured_at: str, retrieved_at: str,
                   license_status: str, payload_sha256: str, payload: dict) -> int:
        with self.connect() as db:
            cur = db.execute("INSERT INTO source_capture(provider,source_type,captured_at,retrieved_at,license_status,payload_sha256,payload_json) VALUES(?,?,?,?,?,?,?)",
                             (provider, source_type, captured_at, retrieved_at, license_status,
                              payload_sha256, json.dumps(payload, sort_keys=True)))
            return int(cur.lastrowid)

    def add_odds(self, *, event_id: str, operator: str, market: str, selection: str,
                 decimal_odds: float, captured_at: str, status: str, rules: dict, line: float | None = None) -> int:
        with self.connect() as db:
            cur = db.execute("INSERT INTO odds_capture(event_id,operator,market,selection,line,decimal_odds,captured_at,status,rules_json) VALUES(?,?,?,?,?,?,?,?,?)",
                             (event_id, operator, market, selection, line, decimal_odds, captured_at,
                              status, json.dumps(rules, sort_keys=True)))
            return int(cur.lastrowid)

    def add_forecast(self, *, forecast_id: str, event_id: str, event_at: str, market: str,
                     selection: str, probability: float, model_version: str, data_cutoff: str,
                     created_at: str, validation_status: str, metadata: dict,
                     line: float | None = None, p_low: float | None = None, p_high: float | None = None) -> None:
        from .common import finite_number, parse_datetime
        from .data_quality import validate_point_in_time
        finite_number(probability, "probability", minimum=0, maximum=1)
        parse_datetime(event_at); parse_datetime(created_at); parse_datetime(data_cutoff)
        ok, errors = validate_point_in_time(event_at=event_at, forecast_created_at=created_at, data_cutoff_at=data_cutoff)
        if not ok:
            raise ValueError("forecast violates point-in-time integrity: " + ",".join(errors))
        if p_low is not None and not 0 <= p_low <= 1: raise ValueError("p_low must be in [0,1]")
        if p_high is not None and not 0 <= p_high <= 1: raise ValueError("p_high must be in [0,1]")
        if p_low is not None and p_high is not None and p_low > p_high: raise ValueError("p_low cannot exceed p_high")
        with self.connect() as db:
            db.execute("INSERT INTO forecast VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                       (forecast_id, event_id, event_at, market, selection, line, probability,
                        p_low, p_high, model_version, data_cutoff, created_at,
                        validation_status, json.dumps(metadata, sort_keys=True)))

    def settle(self, *, forecast_id: str, settled_at: str, outcome: int,
               settlement_status: str, result: dict) -> int:
        with self.connect() as db:
            cur = db.execute("INSERT INTO settlement(forecast_id,settled_at,outcome,settlement_status,result_json) VALUES(?,?,?,?,?)",
                             (forecast_id, settled_at, outcome, settlement_status, json.dumps(result, sort_keys=True)))
            return int(cur.lastrowid)

    def add_candidate_decision(self, *, decision_id: str, event_id: str, event_at: str,
                               decision_at: str, competition: str, season: str, market_scope: str,
                               candidate_status: str, model_version: str, evidence_sha256: str,
                               reason_codes: list[str], payload: dict,
                               probability: float | None = None, lower_probability: float | None = None,
                               decimal_odds: float | None = None) -> None:
        import re
        if candidate_status not in {"ACCEPTED", "REJECTED", "CONDITIONAL", "NO_PICK"}:
            raise ValueError("candidate_status_invalid")
        for name, value in (("probability", probability), ("lower_probability", lower_probability)):
            if value is not None and not 0 <= float(value) <= 1:
                raise ValueError(f"{name}_must_be_in_0_1")
        if decimal_odds is not None and float(decimal_odds) <= 1:
            raise ValueError("decimal_odds_must_be_above_1")
        if not re.fullmatch(r"[0-9a-fA-F]{64}", evidence_sha256 or ""):
            raise ValueError("evidence_sha256_must_be_64_hex_characters")
        from .common import parse_datetime
        parse_datetime(event_at); parse_datetime(decision_at)
        with self.connect() as db:
            db.execute("INSERT INTO candidate_decision VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                       (decision_id, event_id, event_at, decision_at, competition, season, market_scope,
                        candidate_status, probability, lower_probability, decimal_odds, model_version,
                        evidence_sha256.lower(), json.dumps(reason_codes, sort_keys=True), json.dumps(payload, sort_keys=True)))

    def settle_candidate(self, *, decision_id: str, settled_at: str, outcome: int,
                         settlement_status: str, result: dict) -> int:
        from .common import parse_datetime
        parse_datetime(settled_at)
        if outcome not in (0, 1):
            raise ValueError("candidate_outcome_must_be_0_or_1")
        with self.connect() as db:
            cur = db.execute("INSERT INTO candidate_settlement(decision_id,settled_at,outcome,settlement_status,result_json) VALUES(?,?,?,?,?)",
                             (decision_id, settled_at, outcome, settlement_status, json.dumps(result, sort_keys=True)))
            return int(cur.lastrowid)

    def add_model_evaluation(self, *, evaluation_id: str, evaluated_at: str, model_version: str,
                             competition: str, season: str, market_scope: str, status: str,
                             sample_size: int, metrics: dict) -> None:
        from .common import parse_datetime
        parse_datetime(evaluated_at)
        if sample_size < 0:
            raise ValueError("sample_size_must_be_nonnegative")
        with self.connect() as db:
            db.execute("INSERT INTO model_evaluation VALUES(?,?,?,?,?,?,?,?,?)",
                       (evaluation_id, evaluated_at, model_version, competition, season,
                        market_scope, status, sample_size, json.dumps(metrics, sort_keys=True)))

    def performance_report(self) -> dict[str, Any]:
        from collections import defaultdict
        with self.connect() as db:
            forecast_rows = db.execute("""SELECT f.forecast_id,f.event_id,f.market,f.probability,f.validation_status,
                f.metadata_json,s.outcome,s.settlement_status FROM forecast f JOIN settlement s
                ON f.forecast_id=s.forecast_id WHERE s.settlement_status='SETTLED'""").fetchall()
            candidate_rows = db.execute("SELECT candidate_status,COUNT(*) n FROM candidate_decision GROUP BY candidate_status").fetchall()
            scope_rows = db.execute("""SELECT competition,season,market_scope,candidate_status,COUNT(*) n
                FROM candidate_decision GROUP BY competition,season,market_scope,candidate_status""").fetchall()
            candidate_settled = db.execute("""SELECT d.competition,d.season,d.market_scope,d.candidate_status,
                d.probability,s.outcome FROM candidate_decision d JOIN candidate_settlement s
                ON d.decision_id=s.decision_id WHERE s.settlement_status='SETTLED'""").fetchall()
            eval_rows = db.execute("SELECT competition,season,market_scope,status,COUNT(*) n FROM model_evaluation GROUP BY competition,season,market_scope,status").fetchall()
        candidate_grouped = defaultdict(list)
        for row in candidate_settled:
            if row["probability"] is not None:
                key = (row["competition"], row["season"], row["market_scope"], row["candidate_status"])
                candidate_grouped[key].append((float(row["probability"]), int(row["outcome"])))
        candidate_performance = []
        for (competition, season, market_scope, status), records in sorted(candidate_grouped.items()):
            n = len(records)
            brier = sum((p-y)**2 for p,y in records)/n
            logloss = -sum(y*math.log(max(1e-12,p))+(1-y)*math.log(max(1e-12,1-p)) for p,y in records)/n
            candidate_performance.append({"competition": competition, "season": season,
                                           "market_scope": market_scope, "candidate_status": status,
                                           "settled_n": n, "hit_rate": sum(y for _,y in records)/n,
                                           "brier": brier, "log_loss": logloss})
        grouped = defaultdict(list)
        for row in forecast_rows:
            meta = json.loads(row["metadata_json"] or "{}")
            key = (meta.get("competition", "UNKNOWN"), meta.get("season", "UNKNOWN"), row["market"])
            grouped[key].append((float(row["probability"]), int(row["outcome"])))
        performance = []
        for (competition, season, market), records in sorted(grouped.items()):
            n = len(records)
            brier = sum((p-y)**2 for p,y in records)/n
            logloss = -sum(y*math.log(max(1e-12,p))+(1-y)*math.log(max(1e-12,1-p)) for p,y in records)/n
            performance.append({"competition": competition, "season": season, "market": market,
                                "settled_n": n, "hit_rate": sum(y for _,y in records)/n,
                                "brier": brier, "log_loss": logloss,
                                "warning": "Retrospective performance; compare against same-scope market baseline and include all rejected/accepted candidates in monitoring."})
        return {"settled_forecast_performance": performance,
                "candidate_decisions": {r["candidate_status"]: int(r["n"]) for r in candidate_rows},
                "candidate_decisions_by_scope": [dict(r) for r in scope_rows],
                "settled_candidate_performance": candidate_performance,
                "model_evaluations_by_scope": [dict(r) for r in eval_rows]}

    def counts(self) -> dict[str, int]:
        with self.connect() as db:
            return {table: int(db.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0])
                    for table in ("source_capture", "odds_capture", "forecast", "settlement", "candidate_decision", "candidate_settlement", "model_evaluation")}
