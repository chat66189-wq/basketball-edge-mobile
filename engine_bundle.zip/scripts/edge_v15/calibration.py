from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable
import math

from .common import finite_number


@dataclass(frozen=True)
class ForecastOutcome:
    probability: float
    outcome: int
    event_time: str | None = None
    created_at: str | None = None
    data_cutoff: str | None = None
    market: str | None = None
    competition: str | None = None

    def validate(self):
        finite_number(self.probability, "probability", minimum=0, maximum=1)
        if self.outcome not in (0, 1): raise ValueError("outcome must be 0 or 1")


def wilson_interval(successes: int, n: int, z: float = 1.96) -> tuple[float, float]:
    if n <= 0 or not 0 <= successes <= n or z <= 0:
        raise ValueError("invalid Wilson interval inputs")
    p = successes / n
    den = 1 + z * z / n
    center = (p + z * z / (2 * n)) / den
    half = z * math.sqrt((p * (1 - p) + z * z / (4 * n)) / n) / den
    return max(0.0, center - half), min(1.0, center + half)


def score_forecasts(rows: Iterable[ForecastOutcome], *, bins: int = 10) -> dict:
    items = list(rows)
    if not items: raise ValueError("at least one forecast is required")
    if bins < 2 or bins > 100: raise ValueError("bins must be in [2, 100]")
    for row in items: row.validate()
    brier = sum((r.probability - r.outcome) ** 2 for r in items) / len(items)
    eps = 1e-15
    log_loss = -sum(r.outcome * math.log(max(eps, r.probability)) +
                    (1-r.outcome) * math.log(max(eps, 1-r.probability)) for r in items) / len(items)
    bucket_rows = []
    ece = 0.0
    for i in range(bins):
        lo, hi = i / bins, (i + 1) / bins
        subset = [r for r in items if lo <= r.probability < hi or (i == bins-1 and r.probability == 1)]
        if not subset: continue
        avg_p = sum(r.probability for r in subset) / len(subset)
        observed = sum(r.outcome for r in subset) / len(subset)
        ece += len(subset) / len(items) * abs(avg_p - observed)
        ci = wilson_interval(sum(r.outcome for r in subset), len(subset))
        bucket_rows.append({"lower": lo, "upper": hi, "n": len(subset), "mean_probability": avg_p,
                            "observed_frequency": observed, "observed_wilson_95": ci})
    return {"n": len(items), "brier_score": brier, "log_loss": log_loss,
            "expected_calibration_error": ece, "reliability_bins": bucket_rows,
            "interpretation": "Retrospective scores; compare on identical untouched chronological samples."}
