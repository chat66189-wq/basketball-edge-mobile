from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol, Any
import os


@dataclass(frozen=True)
class ProviderSpec:
    provider_id: str
    display_name: str
    key_env: str | None
    base_url: str | None
    supported_data: tuple[str, ...]
    license_status: str
    official_docs: str | None = None

    def readiness(self) -> dict:
        configured = bool(os.getenv(self.key_env)) if self.key_env else True
        return {"provider_id": self.provider_id, "configured": configured,
                "license_status": self.license_status,
                "ready_to_query": configured and self.license_status in {"AUTHORIZED", "OPEN_LICENSE", "MANUAL_USER_SUPPLIED"},
                "missing_environment_variable": self.key_env if self.key_env and not configured else None}


class BasketballProvider(Protocol):
    spec: ProviderSpec

    def get_schedule(self, competition: str, start: str, end: str) -> list[dict[str, Any]]: ...
    def get_boxscore(self, event_id: str) -> dict[str, Any]: ...
    def get_player_status(self, event_id: str) -> list[dict[str, Any]]: ...
    def get_odds(self, event_id: str, operator: str) -> list[dict[str, Any]]: ...


# Deliberately no scraper or invented API endpoint is included. Users must add
# a provider client under its official API contract and configure credentials.
PROVIDER_CATALOG = (
    ProviderSpec("nba_stats", "NBA official statistics", None, "https://stats.nba.com/",
                 ("schedule", "boxscore", "play_by_play", "player_stats", "team_stats"), "UNKNOWN",
                 "https://www.nba.com/stats/"),
    ProviderSpec("wnba_official", "WNBA official data", None, "https://www.wnba.com/",
                 ("schedule", "boxscore", "player_stats", "team_stats"), "UNKNOWN",
                 "https://www.wnba.com/stats"),
    ProviderSpec("fiba_livestats", "FIBA LiveStats", None, "https://www.fiba.basketball/",
                 ("schedule", "boxscore", "play_by_play"), "UNKNOWN", "https://www.fiba.basketball/"),
    ProviderSpec("user_csv", "User-supplied CSV/JSON", None, None,
                 ("schedule", "boxscore", "player_stats", "team_stats", "odds"), "MANUAL_USER_SUPPLIED"),
)


def provider_readiness() -> list[dict]:
    return [spec.readiness() for spec in PROVIDER_CATALOG]
