from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable
import math
import random

from .common import finite_number, parse_datetime
from .calibration import ForecastOutcome, score_forecasts
from .data_quality import validate_point_in_time


@dataclass(frozen=True)
class PairedForecast:
    event_id: str
    market_scope: str
    event_time: str
    created_at: str
    data_cutoff: str
    outcome: int
    champion_probability: float
    challenger_probability: float

    def validate(self) -> None:
        if not self.event_id or not self.market_scope:
            raise ValueError("event_id and market_scope are required")
        valid, errors = validate_point_in_time(event_at=self.event_time,
                                               forecast_created_at=self.created_at,
                                               data_cutoff_at=self.data_cutoff)
        if not valid: raise ValueError("point-in-time violation: " + ",".join(errors))
        ForecastOutcome(self.champion_probability, self.outcome).validate()
        ForecastOutcome(self.challenger_probability, self.outcome).validate()


def _logloss(p: float, y: int) -> float:
    eps = 1e-15
    return -(y * math.log(max(eps, p)) + (1-y) * math.log(max(eps, 1-p)))


def _percentile(values: list[float], quantile: float) -> float:
    ordered = sorted(values)
    if not ordered: raise ValueError("empty bootstrap distribution")
    position = (len(ordered)-1) * quantile
    lo = int(math.floor(position)); hi = int(math.ceil(position))
    if lo == hi: return ordered[lo]
    return ordered[lo] * (hi-position) + ordered[hi] * (position-lo)


def compare_challenger(rows: Iterable[PairedForecast], *, min_predictions: int = 300,
                       min_events: int = 200, bootstrap_samples: int = 2000,
                       seed: int = 20261119, logloss_tolerance: float = 0.01,
                       ece_tolerance: float = 0.01) -> dict:
    items = list(rows)
    if not items: raise ValueError("paired forecasts are required")
    if min_predictions < 1 or min_events < 1: raise ValueError("minimum sample requirements must be positive")
    for row in items: row.validate()
    scopes = {r.market_scope for r in items}
    if len(scopes) != 1:
        raise ValueError("compare only one identical market/competition/season scope at a time")
    if bootstrap_samples < 500: raise ValueError("bootstrap_samples must be >= 500")
    finite_number(logloss_tolerance, "logloss_tolerance", minimum=0)
    finite_number(ece_tolerance, "ece_tolerance", minimum=0)

    # Bootstrap event groups rather than individual legs to preserve dependence
    # among repeated forecasts for the same game.
    grouped: dict[str, list[PairedForecast]] = {}
    for row in items: grouped.setdefault(row.event_id, []).append(row)
    event_deltas = []
    champ_rows = []
    chal_rows = []
    for event_id, group in grouped.items():
        brier_diffs, logloss_diffs = [], []
        for row in group:
            champ_rows.append(ForecastOutcome(row.champion_probability, row.outcome))
            chal_rows.append(ForecastOutcome(row.challenger_probability, row.outcome))
            brier_diffs.append((row.challenger_probability-row.outcome)**2 - (row.champion_probability-row.outcome)**2)
            logloss_diffs.append(_logloss(row.challenger_probability, row.outcome) - _logloss(row.champion_probability, row.outcome))
        event_deltas.append((sum(brier_diffs)/len(brier_diffs), sum(logloss_diffs)/len(logloss_diffs)))

    mean_brier_delta = sum(x[0] for x in event_deltas) / len(event_deltas)
    mean_logloss_delta = sum(x[1] for x in event_deltas) / len(event_deltas)
    rng = random.Random(seed)
    boot_brier, boot_logloss = [], []
    for _ in range(bootstrap_samples):
        sample = [event_deltas[rng.randrange(len(event_deltas))] for _ in event_deltas]
        boot_brier.append(sum(x[0] for x in sample) / len(sample))
        boot_logloss.append(sum(x[1] for x in sample) / len(sample))
    brier_ci = (_percentile(boot_brier, 0.025), _percentile(boot_brier, 0.975))
    logloss_ci = (_percentile(boot_logloss, 0.025), _percentile(boot_logloss, 0.975))
    champ_cal = score_forecasts(champ_rows)
    chal_cal = score_forecasts(chal_rows)
    sample_ok = len(items) >= min_predictions and len(grouped) >= min_events
    statistically_superior = brier_ci[1] < 0
    logloss_noninferior = logloss_ci[1] <= logloss_tolerance
    calibration_noninferior = chal_cal["expected_calibration_error"] <= champ_cal["expected_calibration_error"] + ece_tolerance
    eligible = sample_ok and statistically_superior and logloss_noninferior and calibration_noninferior
    return {
        "status": "PROMOTION_ELIGIBLE" if eligible else "DO_NOT_PROMOTE",
        "scope": next(iter(scopes)), "n_predictions": len(items), "n_unique_events": len(grouped),
        "sample_size_gate": sample_ok,
        "brier_delta_challenger_minus_champion": mean_brier_delta,
        "brier_delta_bootstrap_95": brier_ci,
        "brier_superiority_gate": statistically_superior,
        "logloss_delta_challenger_minus_champion": mean_logloss_delta,
        "logloss_delta_bootstrap_95": logloss_ci,
        "logloss_noninferiority_gate": logloss_noninferior,
        "champion_brier": champ_cal["brier_score"], "challenger_brier": chal_cal["brier_score"],
        "champion_log_loss": champ_cal["log_loss"], "challenger_log_loss": chal_cal["log_loss"],
        "champion_ece": champ_cal["expected_calibration_error"],
        "challenger_ece": chal_cal["expected_calibration_error"],
        "calibration_noninferiority_gate": calibration_noninferior,
        "bootstrap_samples": bootstrap_samples, "seed": seed,
        "warning": "Promotion eligibility is evidence from a paired retrospective sample, not proof of future profit. A separate untouched final holdout and prospective paper-trading gate remain required."
    }


def detect_degradation(baseline_rows: Iterable[ForecastOutcome], recent_rows: Iterable[ForecastOutcome], *,
                       brier_tolerance: float = 0.02, ece_tolerance: float = 0.02) -> dict:
    if brier_tolerance < 0 or ece_tolerance < 0: raise ValueError("degradation tolerances must be nonnegative")
    baseline = score_forecasts(list(baseline_rows))
    recent = score_forecasts(list(recent_rows))
    brier_delta = recent["brier_score"] - baseline["brier_score"]
    ece_delta = recent["expected_calibration_error"] - baseline["expected_calibration_error"]
    alert = brier_delta > brier_tolerance or ece_delta > ece_tolerance
    return {"status": "DRIFT_ALERT" if alert else "NO_THRESHOLD_ALERT",
            "baseline_n": baseline["n"], "recent_n": recent["n"],
            "brier_delta_recent_minus_baseline": brier_delta,
            "ece_delta_recent_minus_baseline": ece_delta,
            "brier_tolerance": brier_tolerance, "ece_tolerance": ece_tolerance,
            "warning": "Threshold monitor only; evaluate confidence intervals, sample mix and market-scope stability before retraining or rollback."}
