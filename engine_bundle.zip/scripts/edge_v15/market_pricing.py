from __future__ import annotations

from dataclasses import dataclass
from typing import Literal
import math

from .team_model import GameSimulation


@dataclass(frozen=True)
class MarketProbability:
    market: str
    side: str
    line: float | None
    p_win: float
    p_push: float
    p_loss: float
    samples: int
    model_status: str

    @property
    def p_no_loss(self) -> float:
        return self.p_win + self.p_push

    @property
    def fair_odds_no_push(self) -> float | None:
        decisive = self.p_win + self.p_loss
        return None if decisive <= 0 else decisive / self.p_win if self.p_win > 0 else math.inf


def _settlement(value: float, line: float, side: str) -> tuple[bool, bool]:
    if math.isclose(value, line, abs_tol=1e-9):
        return False, True
    if side.lower() == "over": return value > line, False
    if side.lower() == "under": return value < line, False
    raise ValueError("side must be 'over' or 'under'")


def price_game_market(sim: GameSimulation, market: str, *, side: str,
                      line: float | None = None, overtime_rule: str = "unknown") -> MarketProbability:
    if overtime_rule not in {"excluded", "included", "unknown"}:
        raise ValueError("overtime_rule must be excluded, included or unknown")
    if sim.regulation_only and overtime_rule != "excluded":
        raise ValueError("this simulator is regulation-only; overtime-included or unknown settlement is not evaluable")
    market = market.lower().strip()
    side = side.lower().strip()
    if market in {"total", "home_total", "away_total"}:
        if line is None: raise ValueError("line is required for totals")
        if side not in {"over", "under"}: raise ValueError("total side must be over or under")
        if market == "total": values = [h + a for h, a in zip(sim.home_scores, sim.away_scores)]
        elif market == "home_total": values = sim.home_scores
        else: values = sim.away_scores
        outcomes = [_settlement(v, line, side) for v in values]
    elif market == "spread":
        if line is None: raise ValueError("line is required for spread")
        if side not in {"home", "away"}: raise ValueError("spread side must be home or away")
        # line is the handicap applied to the named side.
        values = [h - a + line if side == "home" else a - h + line
                  for h, a in zip(sim.home_scores, sim.away_scores)]
        outcomes = [(v > 0, math.isclose(v, 0.0, abs_tol=1e-9)) for v in values]
    elif market == "moneyline":
        if side not in {"home", "away"}: raise ValueError("moneyline side must be home or away")
        outcomes = []
        for h, a in zip(sim.home_scores, sim.away_scores):
            diff = h - a if side == "home" else a - h
            outcomes.append((diff > 0, diff == 0))
    else:
        raise ValueError(f"unsupported market: {market}")
    wins = sum(1 for win, push in outcomes if win)
    pushes = sum(1 for win, push in outcomes if push)
    n = len(outcomes)
    p_win, p_push = wins / n, pushes / n
    return MarketProbability(market, side, line, p_win, p_push, 1.0 - p_win - p_push,
                             n, sim.projection.validation_status)


def ev_per_unit(probability: MarketProbability, decimal_odds: float) -> float:
    if decimal_odds <= 1 or not math.isfinite(decimal_odds):
        raise ValueError("decimal odds must be finite and > 1")
    # Push returns stake; win returns odds including stake; loss returns zero.
    return probability.p_win * (decimal_odds - 1.0) - probability.p_loss


def no_vig_probabilities(decimal_odds: dict[str, float], *, method: str = "proportional") -> dict[str, float]:
    """Remove overround from a complete, mutually exclusive market snapshot.

    This is not usable with incomplete sides or quotes from different capture times.
    """
    if len(decimal_odds) < 2: raise ValueError("at least two mutually exclusive outcomes are required")
    implied = {}
    for outcome, odds in decimal_odds.items():
        if not math.isfinite(float(odds)) or float(odds) <= 1:
            raise ValueError(f"invalid decimal odds for {outcome}")
        implied[outcome] = 1.0 / float(odds)
    total = sum(implied.values())
    if total <= 0: raise ValueError("invalid implied probability total")
    if method == "proportional":
        return {k: v / total for k, v in implied.items()}
    if method == "power":
        # Solve sum(q_i ** alpha) = 1 by bisection. q_i are raw implied prices.
        lo, hi = 0.01, 5.0
        for _ in range(100):
            mid = (lo + hi) / 2
            value = sum(v ** mid for v in implied.values())
            if value > 1: lo = mid
            else: hi = mid
        alpha = (lo + hi) / 2
        powered = {k: v ** alpha for k, v in implied.items()}
        norm = sum(powered.values())
        return {k: v / norm for k, v in powered.items()}
    raise ValueError("method must be proportional or power")
