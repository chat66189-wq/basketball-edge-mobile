from __future__ import annotations

from dataclasses import dataclass
from itertools import combinations
from typing import Iterable, Mapping, Sequence
import math

from .calibration import wilson_interval


@dataclass(frozen=True)
class LegCandidate:
    leg_id: str
    event_id: str
    market: str
    selection: str
    decimal_odds: float
    quote_verified: bool
    data_ready: bool
    model_validated: bool
    status: str = "EJECUTABLE"

    def validate(self) -> None:
        if not self.leg_id or not self.event_id or not self.market or not self.selection:
            raise ValueError("leg identity, event, market and selection are required")
        if not math.isfinite(self.decimal_odds) or self.decimal_odds <= 1:
            raise ValueError(f"invalid decimal odds for {self.leg_id}")


@dataclass(frozen=True)
class ComboResult:
    legs: tuple[str, ...]
    events: tuple[str, ...]
    decimal_odds: float
    price_status: str
    p_joint: float
    p_joint_mc_lower95: float
    p_joint_stress_min: float | None
    simulations: int
    robust_ev_per_unit: float
    leave_one_out: tuple[dict, ...]


def _wilson_lower(successes: int, n: int) -> float:
    return wilson_interval(successes, n)[0]


def _success_probability(leg_ids: tuple[str, ...], scenarios: Sequence[Mapping[str, bool]]) -> tuple[float, int, int]:
    wins = 0
    used = 0
    for index, row in enumerate(scenarios):
        missing = [leg for leg in leg_ids if leg not in row]
        if missing:
            raise ValueError(f"scenario[{index}] missing candidate legs: {missing}")
        invalid = [leg for leg in leg_ids if type(row[leg]) is not bool]
        if invalid:
            raise ValueError(f"scenario[{index}] has non-boolean/unknown outcomes: {invalid}")
        used += 1
        wins += int(all(row[leg] for leg in leg_ids))
    if used == 0:
        raise ValueError("no joint scenarios for candidate legs")
    return wins / used, wins, used


def _combo_price(legs: tuple[LegCandidate, ...], joint_prices: Mapping[str, float],
                 verified_joint_price_keys: set[str],
                 assume_independent_cross_event: bool) -> tuple[float | None, str]:
    key = "|".join(sorted(x.leg_id for x in legs))
    if key in joint_prices:
        price = float(joint_prices[key])
        if not math.isfinite(price) or price <= 1:
            return None, "INVALID_JOINT_PRICE"
        if key in verified_joint_price_keys:
            return price, "EXACT_OPERATOR_JOINT_PRICE_VERIFIED"
        return price, "JOINT_PRICE_SUPPLIED_NOT_INDEPENDENTLY_VERIFIED"
    events = {x.event_id for x in legs}
    if len(events) == len(legs) and assume_independent_cross_event:
        # This is only an arithmetic estimate, not a verified operator quote.
        return math.prod(x.decimal_odds for x in legs), "ESTIMATED_PRODUCT_NOT_OPERATOR_VERIFIED"
    if len(legs) == 1 and legs[0].quote_verified:
        return legs[0].decimal_odds, "SINGLE_LEG_PRICE_VERIFIED"
    return None, "JOINT_PRICE_REQUIRED_FOR_SAME_EVENT_OR_UNVERIFIED"


def optimize_combinations(candidates: Iterable[LegCandidate], scenarios: Sequence[Mapping[str, bool]], *,
                          target_odds: float, relative_band: float = 0.10,
                          min_legs: int = 2, max_legs: int = 6,
                          joint_prices: Mapping[str, float] | None = None,
                          verified_joint_price_keys: Sequence[str] = (),
                          stress_scenarios: Sequence[Sequence[Mapping[str, bool]]] = (),
                          assume_independent_cross_event: bool = False,
                          require_positive_robust_ev: bool = False,
                          max_combinations: int = 250000) -> dict:
    items = list(candidates)
    if len({x.leg_id for x in items}) != len(items):
        raise ValueError("duplicate leg_id")
    for item in items: item.validate()
    if not math.isfinite(target_odds) or target_odds <= 1:
        raise ValueError("target_odds must be finite and > 1")
    if not 0 <= relative_band <= 0.5:
        raise ValueError("relative_band must be in [0, 0.5]")
    if min_legs < 1 or max_legs < min_legs:
        raise ValueError("invalid leg count bounds")
    if not scenarios:
        raise ValueError("joint scenarios are required; marginal probabilities are insufficient")
    prices = joint_prices or {}
    verified_prices = set(verified_joint_price_keys)
    rejected = []
    eligible = []
    for leg in items:
        reasons = []
        if not leg.quote_verified: reasons.append("QUOTE_NOT_VERIFIED")
        if not leg.data_ready: reasons.append("DATA_NOT_READY")
        if not leg.model_validated: reasons.append("MODEL_NOT_VALIDATED")
        if leg.status not in {"EJECUTABLE", "APPROVED"}: reasons.append(f"STATUS_{leg.status}")
        if reasons: rejected.append({"leg_id": leg.leg_id, "reasons": reasons})
        else: eligible.append(leg)
    lower, upper = target_odds * (1-relative_band), target_odds * (1+relative_band)
    tested = 0
    scenario_failures = 0
    ranked: list[tuple[tuple, ComboResult]] = []
    for count in range(min_legs, min(max_legs, len(eligible)) + 1):
        for group in combinations(eligible, count):
            tested += 1
            if tested > max_combinations:
                raise ValueError("combination search exceeds max_combinations; reduce candidates/max_legs")
            ids = tuple(x.leg_id for x in group)
            try:
                p, wins, n = _success_probability(ids, scenarios)
            except ValueError:
                scenario_failures += 1
                continue
            price, price_status = _combo_price(group, prices, verified_prices, assume_independent_cross_event)
            if price is None or not lower <= price <= upper:
                continue
            lower95 = _wilson_lower(wins, n)
            stress_min = None
            if stress_scenarios:
                stress_values = []
                for batch in stress_scenarios:
                    try:
                        sp, sw, sn = _success_probability(ids, batch)
                        stress_values.append(_wilson_lower(sw, sn))
                    except ValueError:
                        stress_values.append(0.0)
                stress_min = min(stress_values) if stress_values else None
            robust_p = min([lower95] + ([stress_min] if stress_min is not None else []))
            robust_ev = robust_p * (price - 1.0) - (1.0 - robust_p)
            if require_positive_robust_ev and robust_ev <= 0:
                continue
            leave = []
            for removed in ids:
                remaining = tuple(x for x in ids if x != removed)
                if not remaining: continue
                rp, rw, rn = _success_probability(remaining, scenarios)
                leave.append({"removed_leg": removed, "remaining_legs": remaining,
                              "p_joint_without_leg": rp, "p_mc_lower95_without_leg": _wilson_lower(rw, rn),
                              "scenarios": rn})
            result = ComboResult(ids, tuple(sorted({x.event_id for x in group})), price, price_status,
                                 p, robust_p, stress_min, n, robust_ev, tuple(leave))
            # Maximize MC/stress lower-bound hit probability first; tie-break on
            # EV, fewer legs, and lower deviation from target odds.
            score = (robust_p, p, robust_ev, -count, -abs(price-target_odds))
            ranked.append((score, result))
    ranked.sort(key=lambda x: x[0], reverse=True)
    best = ranked[0][1] if ranked else None
    return {
        "status": ("CANDIDATES_FOUND" if best and best.price_status in {"EXACT_OPERATOR_JOINT_PRICE_VERIFIED", "SINGLE_LEG_PRICE_VERIFIED"}
                   else "CANDIDATES_FOUND_CONDITIONAL_PRICE" if best
                   else "NO_RESPONSIBLE_COMBO_IN_ODDS_BAND"),
        "objective": "maximize joint Monte Carlo lower bound; tie-break EV and complexity",
        "target_odds": target_odds, "odds_band": [lower, upper],
        "eligible_legs": [x.leg_id for x in eligible], "rejected_legs": rejected,
        "candidate_combinations_tested": tested, "scenario_integrity_failures": scenario_failures,
        "qualified_combinations": len(ranked),
        "best": None if best is None else {
            "legs": list(best.legs), "events": list(best.events), "decimal_odds": best.decimal_odds,
            "price_status": best.price_status, "p_joint_mc": best.p_joint,
            "p_joint_mc_lower95": best.p_joint_mc_lower95,
            "p_joint_stress_min": best.p_joint_stress_min, "simulation_count": best.simulations,
            "robust_ev_per_unit": best.robust_ev_per_unit,
            "leave_one_out": list(best.leave_one_out),
            "execution_status": "REQUIRES_EXTERNAL_FINAL_RECHECK"
        },
        "top_alternatives": [{"legs": list(r.legs), "odds": r.decimal_odds,
                              "p_joint_mc": r.p_joint, "p_joint_mc_lower95": r.p_joint_mc_lower95,
                              "robust_ev_per_unit": r.robust_ev_per_unit, "price_status": r.price_status}
                             for _, r in ranked[:10]],
        "warning": "Wilson bounds quantify Monte Carlo sampling error only; they do not include model, data, lineup, parameter or market uncertainty. Same-event combinations need an exact joint price from the operator; supplied prices remain unverified unless their key is explicitly listed in verified_joint_price_keys. All candidates require a final live operator recheck."
    }
