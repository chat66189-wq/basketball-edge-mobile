"""Basketball Edge Analyst quantitative core and v18 model-lab/strict decision gates."""
__version__ = "18.0.0"
