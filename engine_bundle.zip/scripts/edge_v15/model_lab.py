"""Chronological, market-benchmarked model laboratory for exact basketball scopes.

The lab only validates a model for one competition × season × market_scope.
It cannot prove source claims are true; provenance fields are audited as supplied.
"""
from __future__ import annotations

import csv
import hashlib
import json
import math
import pickle
import random
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable


FORBIDDEN_FEATURE_TOKENS = (
    "outcome", "result", "winner", "final", "settlement", "settled", "score_for",
    "score_against", "points_for", "points_against", "margin", "postgame", "post_game",
    "boxscore", "closing_odds", "close_odds", "clv", "profit", "pnl", "won", "lost",
)
REQUIRED_COLUMNS = (
    "event_id", "event_time", "forecast_created_at", "data_cutoff_at", "feature_snapshot_at",
    "competition", "season", "market_scope", "outcome", "market_odds_selected",
    "market_odds_opposite", "market_quote_captured_at", "market_quote_operator_count",
    "source_bundle_sha256", "independent_source_count", "official_source_present",
)


def _aware(value: str, field: str) -> datetime:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field}_missing")
    dt = datetime.fromisoformat(value.strip().replace("Z", "+00:00"))
    if dt.tzinfo is None or dt.utcoffset() is None:
        raise ValueError(f"{field}_must_be_timezone_aware")
    return dt


def _finite(value: Any, field: str, *, lower: float | None = None, upper: float | None = None) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError):
        raise ValueError(f"{field}_not_numeric")
    if not math.isfinite(number):
        raise ValueError(f"{field}_not_finite")
    if lower is not None and number < lower:
        raise ValueError(f"{field}_below_{lower}")
    if upper is not None and number > upper:
        raise ValueError(f"{field}_above_{upper}")
    return number


def no_vig_probability(odds_selected: float, odds_opposite: float) -> float:
    a = _finite(odds_selected, "market_odds_selected", lower=1.0000001)
    b = _finite(odds_opposite, "market_odds_opposite", lower=1.0000001)
    ia, ib = 1.0 / a, 1.0 / b
    return ia / (ia + ib)


def _logit(p: float) -> float:
    p = min(1 - 1e-8, max(1e-8, p))
    return math.log(p / (1 - p))


def _sigmoid(x: float) -> float:
    if x >= 0:
        z = math.exp(-min(x, 700))
        return 1 / (1 + z)
    z = math.exp(max(x, -700))
    return z / (1 + z)


def _metrics(y: list[int], p: list[float], market: list[float]) -> dict[str, Any]:
    if not y or len(y) != len(p) or len(y) != len(market):
        raise ValueError("metric_vectors_must_be_nonempty_and_equal_length")
    eps = 1e-12
    brier = sum((pp - yy) ** 2 for yy, pp in zip(y, p)) / len(y)
    logloss = -sum(yy * math.log(max(eps, pp)) + (1 - yy) * math.log(max(eps, 1 - pp)) for yy, pp in zip(y, p)) / len(y)
    market_brier = sum((pp - yy) ** 2 for yy, pp in zip(y, market)) / len(y)
    market_logloss = -sum(yy * math.log(max(eps, pp)) + (1 - yy) * math.log(max(eps, 1 - pp)) for yy, pp in zip(y, market)) / len(y)
    bins = []
    ece = 0.0
    for i in range(10):
        low, high = i / 10, (i + 1) / 10
        idx = [j for j, pp in enumerate(p) if low <= pp < high or (i == 9 and pp == 1)]
        if not idx:
            continue
        mean_p = sum(p[j] for j in idx) / len(idx)
        observed = sum(y[j] for j in idx) / len(idx)
        ece += len(idx) / len(y) * abs(mean_p - observed)
        bins.append({"lower": low, "upper": high, "n": len(idx), "mean_probability": mean_p,
                     "observed_frequency": observed})
    correct = sum((pp >= 0.5) == bool(yy) for yy, pp in zip(y, p))
    accuracy = correct / len(y)
    return {
        "n": len(y), "accuracy_at_0_5": accuracy, "brier": brier, "log_loss": logloss,
        "market_no_vig_brier": market_brier, "market_no_vig_log_loss": market_logloss,
        "brier_skill_vs_market": None if market_brier == 0 else 1 - brier / market_brier,
        "log_loss_delta_vs_market": logloss - market_logloss,
        "ece_10_bins": ece, "reliability_bins": bins,
    }


def _auc(y: list[int], p: list[float]) -> float | None:
    positives = sum(y)
    negatives = len(y) - positives
    if positives == 0 or negatives == 0:
        return None
    order = sorted(range(len(p)), key=lambda i: p[i])
    ranks = [0.0] * len(p)
    cursor = 0
    while cursor < len(order):
        end = cursor + 1
        while end < len(order) and p[order[end]] == p[order[cursor]]:
            end += 1
        avg_rank = ((cursor + 1) + end) / 2
        for k in range(cursor, end):
            ranks[order[k]] = avg_rank
        cursor = end
    rank_sum = sum(ranks[i] for i, yy in enumerate(y) if yy == 1)
    return (rank_sum - positives * (positives + 1) / 2) / (positives * negatives)


def _calibration_line(y: list[int], p: list[float]) -> dict[str, float | None]:
    """Estimate logistic calibration intercept/slope using sklearn if available."""
    if len(set(y)) < 2:
        return {"slope": None, "intercept": None}
    try:
        from sklearn.linear_model import LogisticRegression
        X = [[_logit(pp)] for pp in p]
        model = LogisticRegression(C=1e6, solver="lbfgs", max_iter=2000)
        model.fit(X, y)
        return {"slope": float(model.coef_[0][0]), "intercept": float(model.intercept_[0])}
    except Exception:
        return {"slope": None, "intercept": None}


@dataclass
class Row:
    raw: dict[str, str]
    features: list[float | None]
    outcome: int
    market_probability: float
    event_time: datetime


def load_dataset(csv_path: str | Path, config: dict[str, Any]) -> tuple[list[Row], list[str], dict[str, Any]]:
    feature_columns = config.get("feature_columns")
    if not isinstance(feature_columns, list) or not feature_columns:
        raise ValueError("config_feature_columns_must_be_nonempty_explicit_list")
    if len(set(feature_columns)) != len(feature_columns):
        raise ValueError("duplicate_feature_columns")
    for feature in feature_columns:
        lowered = str(feature).lower()
        if any(token in lowered for token in FORBIDDEN_FEATURE_TOKENS):
            raise ValueError(f"forbidden_post_event_or_target_feature:{feature}")
    with open(csv_path, "r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        columns = set(reader.fieldnames or [])
        missing = [c for c in (*REQUIRED_COLUMNS, *feature_columns) if c not in columns]
        if missing:
            raise ValueError("dataset_missing_columns:" + ",".join(missing))
        records = list(reader)
    if not records:
        raise ValueError("dataset_empty")

    rows: list[Row] = []
    seen_ids: set[str] = set()
    scopes, competitions, seasons = set(), set(), set()
    errors: list[str] = []
    for index, record in enumerate(records, start=2):
        try:
            event_id = record["event_id"].strip()
            if not event_id or event_id in seen_ids:
                raise ValueError("event_id_missing_or_duplicate")
            seen_ids.add(event_id)
            event_time = _aware(record["event_time"], "event_time")
            created = _aware(record["forecast_created_at"], "forecast_created_at")
            cutoff = _aware(record["data_cutoff_at"], "data_cutoff_at")
            snapshot = _aware(record["feature_snapshot_at"], "feature_snapshot_at")
            if not (cutoff <= snapshot <= created < event_time):
                raise ValueError("point_in_time_order_must_be_cutoff_le_snapshot_le_created_lt_event")
            market_quote_time = _aware(record["market_quote_captured_at"], "market_quote_captured_at")
            quote_age = (created - market_quote_time).total_seconds() / 60
            if quote_age < 0 or quote_age > float(config.get("max_market_quote_age_minutes", 10.0)):
                raise ValueError("market_quote_not_fresh_at_forecast_creation")
            quote_operators = int(record["market_quote_operator_count"])
            if quote_operators < int(config.get("min_market_operator_count", 3)):
                raise ValueError("market_baseline_has_too_few_independent_operators")
            sha = record["source_bundle_sha256"].strip().lower()
            if not re.fullmatch(r"[0-9a-f]{64}", sha):
                raise ValueError("source_bundle_sha256_invalid")
            independent = int(record["independent_source_count"])
            if independent < 2:
                raise ValueError("fewer_than_two_independent_source_groups")
            official = record["official_source_present"].strip().lower() in {"true", "1", "yes"}
            if not official:
                raise ValueError("official_source_missing")
            outcome = int(record["outcome"])
            if outcome not in (0, 1):
                raise ValueError("outcome_must_be_0_or_1")
            feats: list[float | None] = []
            for feature in feature_columns:
                val = record.get(feature, "").strip()
                feats.append(None if val == "" else _finite(val, feature))
            missing_fraction = sum(x is None for x in feats) / len(feats)
            if missing_fraction > float(config.get("max_feature_missing_fraction", 0.10)):
                raise ValueError("feature_missing_fraction_exceeds_limit")
            market_p = no_vig_probability(record["market_odds_selected"], record["market_odds_opposite"])
            if record.get("closing_odds_selected") or record.get("closing_odds_opposite"):
                if not record.get("closing_odds_selected") or not record.get("closing_odds_opposite") or not record.get("closing_quote_captured_at"):
                    raise ValueError("closing_odds_pair_or_timestamp_incomplete")
                close_time = _aware(record["closing_quote_captured_at"], "closing_quote_captured_at")
                if not (created <= close_time < event_time):
                    raise ValueError("closing_quote_must_be_after_forecast_and_before_event")
            if record.get("odds_taken"):
                if not record.get("odds_taken_captured_at") or not record.get("odds_taken_operator"):
                    raise ValueError("odds_taken_requires_operator_and_capture_timestamp")
                taken_time = _aware(record["odds_taken_captured_at"], "odds_taken_captured_at")
                if taken_time > created or (created - taken_time).total_seconds() / 60 > float(config.get("max_market_quote_age_minutes", 10.0)):
                    raise ValueError("odds_taken_quote_stale_or_after_forecast")
                _finite(record["odds_taken"], "odds_taken", lower=1.0000001)
            rows.append(Row(record, feats, outcome, market_p, event_time))
            scopes.add(record["market_scope"].strip())
            competitions.add(record["competition"].strip())
            seasons.add(record["season"].strip())
        except Exception as exc:
            errors.append(f"row_{index}:{exc}")
    if errors:
        raise ValueError("dataset_integrity_errors:" + " | ".join(errors[:25]))
    if len(scopes) != 1 or len(competitions) != 1 or len(seasons) != 1:
        raise ValueError("dataset_must_contain_exactly_one_competition_season_market_scope")
    expected = {
        "market_scope": config.get("market_scope"),
        "competition": config.get("competition"),
        "season": config.get("season"),
    }
    actual = {"market_scope": next(iter(scopes)), "competition": next(iter(competitions)), "season": next(iter(seasons))}
    for key, wanted in expected.items():
        if wanted is not None and str(wanted) != actual[key]:
            raise ValueError(f"configured_{key}_does_not_match_dataset")
    rows.sort(key=lambda r: r.event_time)
    meta = {**actual, "rows": len(rows), "feature_count": len(feature_columns),
            "dataset_sha256": _sha256_file(csv_path),
            "earliest_event": rows[0].event_time.isoformat(), "latest_event": rows[-1].event_time.isoformat()}
    return rows, [str(x) for x in feature_columns], meta


def _sha256_file(path: str | Path) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


class WeightedModelEnsemble:
    """Simple picklable soft-voting ensemble of fitted probabilistic estimators."""
    def __init__(self, estimators: list[Any], weights: list[float]):
        if not estimators or len(estimators) != len(weights) or abs(sum(weights) - 1.0) > 1e-6:
            raise ValueError("invalid_weighted_ensemble")
        self.estimators = estimators
        self.weights = weights

    def predict_proba(self, X):
        columns = [est.predict_proba(X) for est in self.estimators]
        output = []
        for i in range(len(X)):
            p1 = sum(w * float(col[i][1]) for w, col in zip(self.weights, columns))
            output.append([1.0 - p1, p1])
        return output


class CatBoostModelAdapter:
    """Keep CatBoost outside sklearn Pipeline to avoid version-specific sklearn tag APIs."""
    def __init__(self, seed: int):
        self.seed = seed
        self.imputer = None
        self.model = None

    def fit(self, X, y):
        from sklearn.impute import SimpleImputer
        from catboost import CatBoostClassifier
        self.imputer = SimpleImputer(strategy="median", add_indicator=True)
        X_ready = self.imputer.fit_transform(X)
        self.model = CatBoostClassifier(iterations=250, depth=4, learning_rate=0.03,
                                        l2_leaf_reg=5, verbose=False, thread_count=1,
                                        random_seed=self.seed, allow_writing_files=False)
        self.model.fit(X_ready, y)
        return self

    def predict_proba(self, X):
        if self.model is None or self.imputer is None:
            raise RuntimeError("catboost_adapter_not_fitted")
        return self.model.predict_proba(self.imputer.transform(X))


def _make_model(name: str, seed: int):
    try:
        from sklearn.pipeline import Pipeline
        from sklearn.impute import SimpleImputer
        from sklearn.preprocessing import StandardScaler
        from sklearn.linear_model import LogisticRegression
        from sklearn.ensemble import ExtraTreesClassifier, HistGradientBoostingClassifier, RandomForestClassifier
    except ImportError as exc:
        raise RuntimeError("scikit-learn is required for model-lab; install requirements-ml.txt") from exc
    if name == "logistic":
        return Pipeline([("imputer", SimpleImputer(strategy="median", add_indicator=True)),
                         ("scale", StandardScaler()),
                         ("model", LogisticRegression(C=0.5, max_iter=2500, solver="lbfgs", random_state=seed))])
    if name == "extra_trees":
        return Pipeline([("imputer", SimpleImputer(strategy="median", add_indicator=True)),
                         ("model", ExtraTreesClassifier(n_estimators=300, min_samples_leaf=10,
                                                         max_features=0.8, n_jobs=1, random_state=seed,
                                                         class_weight=None))])
    if name == "hist_gradient_boosting":
        return Pipeline([("imputer", SimpleImputer(strategy="median", add_indicator=True)),
                         ("model", HistGradientBoostingClassifier(max_iter=150, learning_rate=0.04,
                                                                   max_leaf_nodes=15, min_samples_leaf=20,
                                                                   l2_regularization=2.0, random_state=seed))])
    if name == "random_forest":
        return Pipeline([("imputer", SimpleImputer(strategy="median", add_indicator=True)),
                         ("model", RandomForestClassifier(n_estimators=300, min_samples_leaf=12,
                                                           max_features=0.8, n_jobs=1, random_state=seed))])
    if name == "xgboost":
        try:
            from xgboost import XGBClassifier
        except ImportError as exc:
            raise RuntimeError("xgboost_not_installed") from exc
        return Pipeline([("imputer", SimpleImputer(strategy="median", add_indicator=True)),
                         ("model", XGBClassifier(n_estimators=250, max_depth=3, learning_rate=0.03,
                                                  subsample=0.8, colsample_bytree=0.8, reg_lambda=5,
                                                  eval_metric="logloss", n_jobs=1, random_state=seed))])
    if name == "lightgbm":
        try:
            from lightgbm import LGBMClassifier
        except ImportError as exc:
            raise RuntimeError("lightgbm_not_installed") from exc
        return Pipeline([("imputer", SimpleImputer(strategy="median", add_indicator=True)),
                         ("model", LGBMClassifier(n_estimators=250, max_depth=-1, num_leaves=15,
                                                   learning_rate=0.03, min_child_samples=20,
                                                   reg_lambda=5, verbosity=-1, n_jobs=1, random_state=seed))])
    if name == "catboost":
        try:
            from catboost import CatBoostClassifier  # noqa: F401 - availability check
        except ImportError as exc:
            raise RuntimeError("catboost_not_installed") from exc
        return CatBoostModelAdapter(seed)
    raise ValueError(f"unknown_model:{name}")


def _candidate_names(config: dict[str, Any]) -> list[str]:
    names = config.get("models", ["logistic", "extra_trees", "hist_gradient_boosting"])
    if not isinstance(names, list) or not names:
        raise ValueError("models_must_be_nonempty_list")
    allowed = {"logistic", "extra_trees", "hist_gradient_boosting", "random_forest", "xgboost", "lightgbm", "catboost"}
    if any(n not in allowed for n in names) or len(set(names)) != len(names):
        raise ValueError("invalid_or_duplicate_model_name")
    return names


def _folds(n: int, n_splits: int, initial_train_fraction: float) -> list[tuple[list[int], list[int]]]:
    initial = max(100, int(n * initial_train_fraction))
    remaining = n - initial
    if remaining < n_splits:
        return []
    folds = []
    for i in range(n_splits):
        start = initial + (remaining * i) // n_splits
        end = initial + (remaining * (i + 1)) // n_splits
        if end > start:
            folds.append((list(range(start)), list(range(start, end))))
    return folds


def _fit_platt(probabilities: list[float], outcomes: list[int]):
    from sklearn.linear_model import LogisticRegression
    X = [[_logit(p)] for p in probabilities]
    calibrator = LogisticRegression(C=1e6, solver="lbfgs", max_iter=2000)
    calibrator.fit(X, outcomes)
    return calibrator


def _calibrate(calibrator, probabilities: list[float]) -> list[float]:
    X = [[_logit(p)] for p in probabilities]
    return [float(row[1]) for row in calibrator.predict_proba(X)]


def _bootstrap_metric_intervals(y: list[int], p: list[float], market: list[float], *, reps: int = 1000, seed: int = 1801) -> dict[str, Any]:
    """Event-row bootstrap intervals for metrics; not per-pick probability intervals."""
    rng = random.Random(seed)
    n = len(y)
    briers, skills = [], []
    for _ in range(reps):
        ix = [rng.randrange(n) for _ in range(n)]
        yy = [y[i] for i in ix]; pp = [p[i] for i in ix]; mm = [market[i] for i in ix]
        bm = sum((a - b) ** 2 for a, b in zip(yy, pp)) / n
        mb = sum((a - b) ** 2 for a, b in zip(yy, mm)) / n
        briers.append(bm)
        skills.append(1 - bm / mb if mb > 0 else 0.0)
    briers.sort(); skills.sort()
    def q(arr, qv):
        return arr[min(len(arr) - 1, max(0, int(qv * (len(arr) - 1))))]
    return {"method": "event-row bootstrap; confidence interval for holdout metrics only",
            "replicates": reps, "brier_95": [q(briers, .025), q(briers, .975)],
            "brier_skill_vs_market_95": [q(skills, .025), q(skills, .975)],
            "warning": "This does not create a per-pick probability interval and does not model temporal block dependence."}



def _population_stability_index(dev_rows: list[Row], test_rows: list[Row], features: list[str]) -> dict[str, float | None]:
    """Quantile-bin PSI for numeric covariate drift; descriptive, not a proof of stability."""
    result: dict[str, float] = {}
    eps = 1e-6
    for j, feature in enumerate(features):
        train_vals = sorted(r.features[j] for r in dev_rows if r.features[j] is not None)
        test_vals = [r.features[j] for r in test_rows if r.features[j] is not None]
        if len(train_vals) < 20 or not test_vals:
            result[feature] = None
            continue
        cuts = []
        for qv in (0.2, 0.4, 0.6, 0.8):
            cuts.append(train_vals[min(len(train_vals)-1, int(qv*(len(train_vals)-1)))])
        def bucket(v):
            for i, cut in enumerate(cuts):
                if v <= cut:
                    return i
            return 4
        train_b = [bucket(v) for v in train_vals]
        test_b = [bucket(v) for v in test_vals]
        n_train, n_test = len(train_b), len(test_b)
        psi = 0.0
        for b in range(5):
            pct_train = max(eps, sum(x == b for x in train_b) / n_train)
            pct_test = max(eps, sum(x == b for x in test_b) / n_test)
            psi += (pct_test - pct_train) * math.log(pct_test / pct_train)
        result[feature] = psi
    return result


def train_model_lab(csv_path: str | Path, config: dict[str, Any], output_card: str | Path) -> dict[str, Any]:
    rows, features, dataset_meta = load_dataset(csv_path, config)
    n = len(rows)
    holdout_fraction = float(config.get("holdout_fraction", 0.20))
    if not 0.10 <= holdout_fraction <= 0.35:
        raise ValueError("holdout_fraction_must_be_between_0_10_and_0_35")
    min_holdout = int(config.get("min_holdout_rows", 300))
    holdout_n = max(min_holdout, math.ceil(n * holdout_fraction))
    dev_n = n - holdout_n
    if dev_n < 250 or holdout_n < min_holdout:
        report = {"status": "INSUFFICIENT_DATA_FOR_STRICT_VALIDATION", "dataset": dataset_meta,
                  "n_development": dev_n, "n_untouched_holdout": holdout_n,
                  "required_holdout_rows": min_holdout,
                  "message": "No model is promoted. Supply more chronological, point-in-time, exact-scope historical events."}
        Path(output_card).parent.mkdir(parents=True, exist_ok=True)
        Path(output_card).write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
        report["model_card_sha256"] = _sha256_file(output_card)
        return report

    dev, holdout = rows[:dev_n], rows[dev_n:]
    split_count = int(config.get("walk_forward_splits", 5))
    min_splits = int(config.get("min_walk_forward_splits", 5))
    folds = _folds(len(dev), split_count, float(config.get("initial_train_fraction", 0.50)))
    if len(folds) < min_splits:
        raise ValueError("insufficient_walk_forward_splits")
    min_oos = int(config.get("min_oos_predictions", 300))
    min_events = int(config.get("min_unique_test_events", 200))
    models = _candidate_names(config)
    seed = int(config.get("seed", 1801))

    candidate_results = []
    candidate_oof: dict[str, tuple[list[int], list[float], list[float], dict[str, Any]]] = {}
    champion_info = None
    champion_oof = None
    for model_name in models:
        oof_y: list[int] = []
        oof_p: list[float] = []
        oof_market: list[float] = []
        fold_reports = []
        failed = None
        for fold_i, (train_idx, test_idx) in enumerate(folds):
            try:
                estimator = _make_model(model_name, seed + fold_i)
                X_train = [dev[i].features for i in train_idx]
                y_train = [dev[i].outcome for i in train_idx]
                X_test = [dev[i].features for i in test_idx]
                estimator.fit(X_train, y_train)
                probs = [float(row[1]) for row in estimator.predict_proba(X_test)]
                yy = [dev[i].outcome for i in test_idx]
                mm = [dev[i].market_probability for i in test_idx]
                oof_y.extend(yy); oof_p.extend(probs); oof_market.extend(mm)
                fold_reports.append({"fold": fold_i + 1, "n_train": len(train_idx), "n_test": len(test_idx),
                                     "test_start": dev[test_idx[0]].event_time.isoformat(),
                                     "test_end": dev[test_idx[-1]].event_time.isoformat(),
                                     "metrics": _metrics(yy, probs, mm)})
            except Exception as exc:
                failed = f"{type(exc).__name__}:{exc}"
                break
        if failed:
            candidate_results.append({"model": model_name, "status": "FAILED", "error": failed})
            continue
        metrics = _metrics(oof_y, oof_p, oof_market)
        auc = _auc(oof_y, oof_p)
        candidate = {"model": model_name, "status": "WALK_FORWARD_EVALUATED", "metrics": metrics,
                     "auc": auc, "folds": fold_reports, "n_walk_forward_oos": len(oof_y)}
        candidate_results.append(candidate)
        candidate_oof[model_name] = (oof_y[:], oof_p[:], oof_market[:], metrics)
        # Champion choice is made only on the development walk-forward OOS data.
        market_improvement = metrics["brier_skill_vs_market"] is not None and metrics["brier_skill_vs_market"] > 0
        logloss_ok = metrics["log_loss_delta_vs_market"] <= float(config.get("max_log_loss_degradation", 0.0))
        if market_improvement and logloss_ok:
            rank = metrics["brier"] + max(0, metrics["log_loss_delta_vs_market"]) * 0.25
            if champion_info is None or rank < champion_info["rank"]:
                champion_info = {"model": model_name, "rank": rank, "metrics": metrics}
                champion_oof = (oof_y, oof_p, oof_market)

    # A development-only weighted soft-voting challenger. Its weights are fixed
    # from inverse Brier scores on walk-forward OOS predictions; final holdout
    # remains untouched and decides whether the ensemble is actually retained.
    eligible_names = [name for name, (_, _, _, m) in candidate_oof.items()
                      if (m.get("brier_skill_vs_market") or 0) > 0
                      and m.get("log_loss_delta_vs_market", 1) <= float(config.get("max_log_loss_degradation", 0.0))]
    ensemble_names: list[str] = []
    ensemble_weights: list[float] = []
    if len(eligible_names) >= 2:
        inv = [1.0 / max(candidate_oof[name][3]["brier"], 1e-8) for name in eligible_names]
        total_inv = sum(inv)
        ensemble_weights = [x / total_inv for x in inv]
        ensemble_names = eligible_names
        ens_y = candidate_oof[ensemble_names[0]][0]
        ens_market = candidate_oof[ensemble_names[0]][2]
        ens_p = [sum(w * candidate_oof[name][1][i] for name, w in zip(ensemble_names, ensemble_weights))
                 for i in range(len(ens_y))]
        ens_metrics = _metrics(ens_y, ens_p, ens_market)
        candidate_oof["weighted_ensemble"] = (ens_y[:], ens_p, ens_market[:], ens_metrics)
        candidate_results.append({"model": "weighted_ensemble", "status": "WALK_FORWARD_EVALUATED",
                                  "components": ensemble_names, "weights": ensemble_weights,
                                  "metrics": ens_metrics, "auc": _auc(ens_y, ens_p),
                                  "n_walk_forward_oos": len(ens_y),
                                  "selection_note": "weights fixed from inverse development walk-forward Brier; untouched holdout remains final check"})
        if (ens_metrics.get("brier_skill_vs_market") or 0) > 0 and ens_metrics["log_loss_delta_vs_market"] <= float(config.get("max_log_loss_degradation", 0.0)):
            ens_rank = ens_metrics["brier"] + max(0, ens_metrics["log_loss_delta_vs_market"]) * 0.25
            if champion_info is None or ens_rank < champion_info["rank"]:
                champion_info = {"model": "weighted_ensemble", "rank": ens_rank, "metrics": ens_metrics,
                                 "components": ensemble_names, "weights": ensemble_weights}
                champion_oof = (ens_y[:], ens_p[:], ens_market[:])

    base = {
        "version": "18.0.0", "created_at_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "scope": dataset_meta, "feature_columns": features, "models": candidate_results,
        "walk_forward": {"splits": len(folds), "chronological": True, "selection_used_untouched_holdout": False},
    }
    if champion_info is None or champion_oof is None:
        report = {**base, "status": "NO_MODEL_BEATS_MARKET_IN_WALK_FORWARD", "champion": None,
                  "message": "No candidate consistently beat the no-vig market benchmark in development walk-forward data. Do not issue picks from this run."}
        Path(output_card).parent.mkdir(parents=True, exist_ok=True)
        Path(output_card).write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
        report["model_card_sha256"] = _sha256_file(output_card)
        return report

    # Fit calibration only on development walk-forward out-of-sample predictions.
    oof_y, oof_p, _ = champion_oof
    if len(oof_y) < int(config.get("min_calibration_rows", 200)) or len(set(oof_y)) < 2:
        raise ValueError("insufficient_oof_rows_for_calibration")
    calibrator = _fit_platt(oof_p, oof_y)

    # Refit champion on all development data; the untouched holdout is evaluated once.
    if champion_info["model"] == "weighted_ensemble":
        final_estimators = []
        for i, name in enumerate(champion_info["components"]):
            estimator = _make_model(name, seed + 9999 + i)
            estimator.fit([r.features for r in dev], [r.outcome for r in dev])
            final_estimators.append(estimator)
        final_model = WeightedModelEnsemble(final_estimators, champion_info["weights"])
    else:
        final_model = _make_model(champion_info["model"], seed + 9999)
        final_model.fit([r.features for r in dev], [r.outcome for r in dev])
    holdout_raw = [float(row[1]) for row in final_model.predict_proba([r.features for r in holdout])]
    holdout_p = _calibrate(calibrator, holdout_raw)
    holdout_y = [r.outcome for r in holdout]
    holdout_m = [r.market_probability for r in holdout]
    holdout_metrics = _metrics(holdout_y, holdout_p, holdout_m)
    holdout_metrics["auc"] = _auc(holdout_y, holdout_p)
    holdout_metrics["calibration_line"] = _calibration_line(holdout_y, holdout_p)
    bootstrap = _bootstrap_metric_intervals(holdout_y, holdout_p, holdout_m,
                                            reps=int(config.get("bootstrap_metric_replicates", 1000)), seed=seed)
    # Optional closing-line and execution diagnostics are reported, never used as features.
    optional_cols = set(holdout[0].raw.keys())
    if {"closing_odds_selected", "closing_odds_opposite"}.issubset(optional_cols):
        close_probs = [no_vig_probability(r.raw["closing_odds_selected"], r.raw["closing_odds_opposite"]) for r in holdout]
        clv = [cp - mp for cp, mp in zip(close_probs, holdout_m)]
        holdout_metrics["closing_line_value"] = {"mean_no_vig_probability_delta": sum(clv) / len(clv),
                                                   "positive_fraction": sum(x > 0 for x in clv) / len(clv),
                                                   "n": len(clv),
                                                   "warning": "Closing prices are evaluation-only and must never be included as model features."}
    if "odds_taken" in optional_cols:
        taken = [_finite(r.raw["odds_taken"], "odds_taken", lower=1.0000001) for r in holdout]
        returns = [(odds - 1.0) if y == 1 else -1.0 for odds, y in zip(taken, holdout_y)]
        holdout_metrics["flat_stake_roi_at_captured_odds"] = sum(returns) / len(returns)
    high_cut = float(config.get("high_confidence_cutoff", 0.80))
    high_idx = [i for i, pp in enumerate(holdout_p) if pp >= high_cut]
    high_confidence_lower = None
    if high_idx:
        successes = sum(holdout_y[i] for i in high_idx)
        # Wilson interval is an empirical hit-rate interval for this subset, not a future-pick interval.
        z = 1.96; nn = len(high_idx); phat = successes / nn; den = 1 + z*z/nn
        center = (phat + z*z/(2*nn))/den
        half = z*math.sqrt((phat*(1-phat)+z*z/(4*nn))/nn)/den
        high_confidence_lower = max(0, center-half)
        holdout_metrics["high_confidence_subset"] = {"cutoff": high_cut, "n": nn, "hit_rate": phat,
                                                       "hit_rate_wilson_95": [high_confidence_lower, min(1, center+half)],
                                                       "warning": "Observed historical subset frequency; not a guarantee or individual pick interval."}
    else:
        holdout_metrics["high_confidence_subset"] = {"cutoff": high_cut, "n": 0, "hit_rate": None,
                                                       "hit_rate_wilson_95": None,
                                                       "warning": "No holdout predictions reached this cutoff."}
    min_holdout_unique = int(config.get("min_unique_test_events", 200))
    feature_psi = _population_stability_index(dev, holdout, features)
    psi_values = [v for v in feature_psi.values() if v is not None]
    max_psi = max(psi_values) if psi_values else 0.0
    psi_complete = len(psi_values) == len(feature_psi) and bool(feature_psi)
    gates = {
        "minimum_holdout_predictions": len(holdout) >= min_oos,
        "minimum_unique_holdout_events": len({r.raw["event_id"] for r in holdout}) >= min_holdout_unique,
        "brier_beats_market": holdout_metrics["brier"] < holdout_metrics["market_no_vig_brier"],
        "log_loss_not_materially_worse": holdout_metrics["log_loss_delta_vs_market"] <= float(config.get("max_log_loss_degradation", 0.0)),
        "ece_within_limit": holdout_metrics["ece_10_bins"] <= float(config.get("max_ece", 0.03)),
        "calibration_slope_within_limit": holdout_metrics["calibration_line"]["slope"] is not None and float(config.get("calibration_slope_min", 0.80)) <= holdout_metrics["calibration_line"]["slope"] <= float(config.get("calibration_slope_max", 1.20)),
        "calibration_intercept_within_limit": holdout_metrics["calibration_line"]["intercept"] is not None and abs(holdout_metrics["calibration_line"]["intercept"]) <= float(config.get("max_abs_calibration_intercept", 0.10)),
        "market_brier_skill_ci_lower_positive": bootstrap["brier_skill_vs_market_95"][0] > 0,
        "all_required_walk_forward_splits": len(folds) >= min_splits,
        "feature_drift_within_limit": psi_complete and max_psi <= float(config.get("max_feature_psi", 0.25)),
        "minimum_high_confidence_subset_predictions": len(high_idx) >= int(config.get("min_high_confidence_rows", 100)),
        "high_confidence_subset_hit_rate_lower95": high_confidence_lower is not None and high_confidence_lower >= float(config.get("min_high_confidence_hit_rate_lower95", 0.80)),
    }
    validated = all(gates.values())
    # Optional bootstrap ensemble for epistemic model-sample variation on future inference.
    # This is deliberately kept separate from full lineup/data/structural uncertainty.
    bootstrap_models = []
    n_boot_models = int(config.get("bootstrap_model_replicates", 20))
    if validated and n_boot_models > 0:
        rng = random.Random(seed + 4242)
        for rep in range(n_boot_models):
            sample = [dev[rng.randrange(len(dev))] for _ in range(len(dev))]
            if champion_info["model"] == "weighted_ensemble":
                estimators = []
                for i, name in enumerate(champion_info["components"]):
                    est = _make_model(name, seed + 20000 + rep * 10 + i)
                    est.fit([r.features for r in sample], [r.outcome for r in sample])
                    estimators.append(est)
                bootstrap_models.append(WeightedModelEnsemble(estimators, champion_info["weights"]))
            else:
                est = _make_model(champion_info["model"], seed + 20000 + rep)
                est.fit([r.features for r in sample], [r.outcome for r in sample])
                bootstrap_models.append(est)

    report = {
        **base,
        "status": "VALIDATED_ON_UNTOUCHED_HOLDOUT_FOR_THIS_EXACT_SCOPE" if validated else "NOT_VALIDATED_HOLDOUT_GATES_FAILED",
        "champion": {"model": champion_info["model"], "components": champion_info.get("components", []),
                     "weights": champion_info.get("weights", []),
                     "development_walk_forward_metrics": champion_info["metrics"]},
        "calibration": {"method": "Platt scaling trained only on development walk-forward out-of-sample predictions",
                        "n_calibration_rows": len(oof_y)},
        "untouched_holdout": {"n": len(holdout), "start": holdout[0].event_time.isoformat(),
                              "end": holdout[-1].event_time.isoformat(), "metrics": holdout_metrics,
                              "bootstrap_metric_uncertainty": bootstrap,
                              "feature_population_stability_index": feature_psi},
        "gates": gates,
        "limitations": [
            "Validation applies only to the exact competition, season, market_scope and feature pipeline in this card.",
            "Dataset provenance fields are checked for presence and consistency but the lab cannot independently prove the source data are truthful or licensed.",
            "A historical holdout is not a guarantee of future performance; drift and structural changes remain possible.",
            "Bootstrap intervals quantify holdout metric uncertainty, not an individual pick's full predictive interval.",
            "The model is not automatically updated. Retrain only with new settled, point-in-time rows and repeat all gates.",
        ],
    }
    Path(output_card).parent.mkdir(parents=True, exist_ok=True)
    Path(output_card).write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    if validated:
        bundle_path = Path(output_card).with_suffix(".model.pkl")
        bundle = {"version": "18.0.0", "scope": dataset_meta, "feature_columns": features,
                  "model_name": champion_info["model"], "components": champion_info.get("components", []),
                  "weights": champion_info.get("weights", []), "estimator": final_model, "calibrator": calibrator,
                  "bootstrap_estimators": bootstrap_models,
                  "warning": "Only load model artifacts generated locally by this trusted skill package; pickle is not safe for untrusted files."}
        report["model_artifact"] = str(bundle_path)
        Path(output_card).write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
        bundle["model_card_sha256"] = _sha256_file(output_card)
        with open(bundle_path, "wb") as handle:
            pickle.dump(bundle, handle, protocol=pickle.HIGHEST_PROTOCOL)
    report["model_card_sha256"] = _sha256_file(output_card)
    return report


def predict_from_bundle(bundle_path: str | Path, input_csv: str | Path) -> dict[str, Any]:
    """Predict rows from a trusted locally-created pickle bundle; no source data fetch."""
    with open(bundle_path, "rb") as handle:
        bundle = pickle.load(handle)  # nosec: only trusted local artifacts are supported
    features = bundle["feature_columns"]
    with open(input_csv, "r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        columns = set(reader.fieldnames or [])
        missing = [x for x in features if x not in columns]
        if missing:
            raise ValueError("prediction_csv_missing_features:" + ",".join(missing))
        rows = list(reader)
    if not rows:
        raise ValueError("prediction_csv_empty")
    results = []
    for index, row in enumerate(rows, start=2):
        event_time = _aware(row.get("event_time", ""), "event_time")
        created = _aware(row.get("forecast_created_at", ""), "forecast_created_at")
        cutoff = _aware(row.get("data_cutoff_at", ""), "data_cutoff_at")
        snapshot = _aware(row.get("feature_snapshot_at", ""), "feature_snapshot_at")
        if not (cutoff <= snapshot <= created < event_time):
            raise ValueError(f"prediction_row_{index}_point_in_time_order_invalid")
        if row.get("competition") != bundle["scope"]["competition"] or row.get("season") != bundle["scope"]["season"] or row.get("market_scope") != bundle["scope"]["market_scope"]:
            raise ValueError(f"prediction_row_{index}_scope_mismatch")
        x = []
        for feature in features:
            value = row.get(feature, "").strip()
            x.append(None if value == "" else _finite(value, feature))
        raw = float(bundle["estimator"].predict_proba([x])[0][1])
        p = float(_calibrate(bundle["calibrator"], [raw])[0])
        boot_p = []
        for estimator in bundle.get("bootstrap_estimators", []):
            bp_raw = float(estimator.predict_proba([x])[0][1])
            boot_p.append(float(_calibrate(bundle["calibrator"], [bp_raw])[0]))
        if boot_p:
            sorted_p = sorted(boot_p)
            low = sorted_p[max(0, int(0.025 * (len(sorted_p)-1)))]
            high = sorted_p[min(len(sorted_p)-1, int(0.975 * (len(sorted_p)-1)))]
            boot_mean = sum(boot_p) / len(boot_p)
        else:
            low = high = boot_mean = None
        results.append({"event_id": row.get("event_id"), "p_model": p,
                        "p_bootstrap_mean": boot_mean, "p_bootstrap_sample_interval_95": [low, high] if boot_p else None,
                        "bootstrap_replicates": len(boot_p),
                        "validation_scope": bundle["scope"], "model_name": bundle["model_name"],
                        "warning": "Bootstrap interval covers training-sample variation only; it is NOT a full predictive lower bound. It omits lineup, source, parameter, model-family, regime-shift and stress uncertainty. Apply strict pick gate before any selection."})
    return {"status": "MODEL_INFERENCE_ONLY_NOT_PICK_APPROVAL", "predictions": results}


def model_card_gate(card: dict[str, Any], *, exact_scope: str) -> dict[str, Any]:
    errors = []
    if card.get("status") != "VALIDATED_ON_UNTOUCHED_HOLDOUT_FOR_THIS_EXACT_SCOPE":
        errors.append("model_card_not_validated_on_untouched_holdout")
    if (card.get("scope") or {}).get("market_scope") != exact_scope:
        errors.append("model_card_market_scope_mismatch")
    if not all((card.get("gates") or {}).values()):
        errors.append("one_or_more_holdout_gates_failed")
    return {"status": "MODEL_SCOPE_VALIDATED" if not errors else "MODEL_NOT_APPROVED", "errors": errors,
            "meaning": "This is evidence for model performance on a past exact-scope holdout, not a claim that a particular future pick will win."}
