# Validation report — Basketball Edge Analyst v20.0.0

Date: 2026-11-20

## Software checks performed in this build session

- `python -m unittest discover -s tests -q`: **87 tests passed** (existing v15/v17/v18/v19 suites plus 6 v20 tests).
- `python -m compileall -q scripts tests`: passed.
- `python -m scripts.edge_v20 --help`: passed.
- SQLite smoke test: initialized a temporary local database and ran `audit-db`; passed.
- Smoke audit reported zero imported events, zero model runs and zero provider connections, as expected for a clean offline package.

## v20 tests added

- Empty database audit and explicit offline status.
- Manual game CSV import.
- Rejection of timestamps without timezone.
- Rejection of forecast feature timestamps after forecast creation (look-ahead).
- Append-only prediction enforcement.
- Rejection of decimal odds <= 1.

## Scope and limitations

This report validates software behavior only. It does **not** validate predictive accuracy, probability calibration, ROI, bookmaker price availability, data completeness, or any competition/market model. No real basketball dataset was supplied or imported in the build session. No provider/API is configured. The new local database schema is empty by design. Predictive model promotion remains subject to the exact v18/v19 walk-forward, holdout, calibration, sample-size, model-card and strict-decision gates.
