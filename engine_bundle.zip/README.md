# Basketball Edge Analyst v20.0.0

Motor cuantitativo de básquet con arquitectura acumulativa v15-v19 y una capa v20 offline-first para uso gratuito, sin APIs, con almacenamiento local y operación asistida.

## Límites

- No hay picks ni resultados garantizados.
- Pasar tests de software no demuestra precisión predictiva ni rentabilidad.
- Esta distribución no contiene proveedores configurados, endpoints, credenciales, feeds, resultados ni cuotas precargadas.
- La ingesta v20 es manual por CSV; la licencia, atribución, definición y calidad de cada fuente deben verificarse por el usuario.
- Los modelos y simuladores conservan los gates exactos por competición × temporada × market_scope; sin evidencia suficiente se abstienen.
- No hay automatización programada ni reentrenamiento automático.

## Requisitos y pruebas

Python 3.10+; núcleo con biblioteca estándar. Desde la raíz:

```bash
python -m unittest discover -s tests -v
pytest -q
python -m scripts.edge_v20 --help
python -m scripts.edge_v19 --help
python -m scripts.edge_v15 --help
```

## v20 local

```bash
python -m scripts.edge_v20 init-db
python -m scripts.edge_v20 register-source --source-id manual_01 --name "Fuente manual" --license MANUAL_USER_SUPPLIED --terms-confirmed
python -m scripts.edge_v20 import-csv --dataset games --file ruta/games.csv --source-id manual_01
python -m scripts.edge_v20 import-csv --dataset team_stats --file ruta/team_stats.csv --source-id manual_01
python -m scripts.edge_v20 import-csv --dataset odds --file ruta/odds.csv --source-id manual_01
python -m scripts.edge_v20 audit-db
```

La base por defecto se crea en `data/basketball_edge_v20.sqlite3`. Ver `references/v20/offline-first-operations.md` y los esquemas de `examples/v20/`. Los CSV de ejemplo solo contienen encabezados; el JSON de predicción contiene placeholders.

## v19 existente

Los comandos de `scripts.edge_v19` permanecen disponibles para feature snapshots, market audit, possession simulation, lineup scenarios, provider fetch (solo si se configura explícitamente), monitoring y settlement.
